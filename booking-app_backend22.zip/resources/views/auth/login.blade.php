<!DOCTYPE html>
<html lang="ar" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>تسجيل الدخول - منصة حجوزات السودان</title>

        <!-- Google Fonts - Cairo -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">

        <!-- Bootstrap 5 RTL CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

        <style>
            body {
                font-family: 'Cairo', sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }
            
            .login-container {
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 40px 20px;
            }
            
            .login-card {
                background: white;
                border-radius: 20px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                overflow: hidden;
                max-width: 450px;
                width: 100%;
            }
            
            .login-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 40px 30px;
                text-align: center;
            }
            
            .login-header h2 {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 10px;
            }
            
            .login-header p {
                font-size: 1rem;
                opacity: 0.9;
                margin: 0;
            }
            
            .login-body {
                padding: 40px 30px;
            }
            
            .form-label {
                font-weight: 600;
                color: #333;
                margin-bottom: 8px;
            }
            
            .form-control {
                padding: 12px 15px;
                border-radius: 10px;
                border: 2px solid #e0e0e0;
                transition: all 0.3s ease;
            }
            
            .form-control:focus {
                border-color: #667eea;
                box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
            }
            
            .btn-login {
                width: 100%;
                padding: 14px;
                border-radius: 10px;
                font-weight: 600;
                font-size: 1.1rem;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border: none;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            
            .btn-login:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
            }
            
            .divider {
                text-align: center;
                margin: 25px 0;
                position: relative;
            }
            
            .divider::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                height: 1px;
                background: #e0e0e0;
            }
            
            .divider span {
                background: white;
                padding: 0 15px;
                position: relative;
                color: #999;
                font-size: 0.9rem;
            }
            
            .navbar {
                background: rgba(255, 255, 255, 0.95) !important;
                backdrop-filter: blur(10px);
            }
            
            footer {
                background: rgba(0, 0, 0, 0.2);
                color: white;
                padding: 20px 0;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <!-- Header / Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
            <div class="container">
                <a class="navbar-brand fw-bold fs-4" href="/">منصة حجوزات السودان</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item me-2">
                            <a class="btn btn-outline-primary" href="/">الرئيسية</a>
                        </li>
                        @if (Route::has('register'))
                            <li class="nav-item">
                                <a class="btn btn-primary" href="{{ route('register') }}">إنشاء حساب</a>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Login Container -->
        <div class="login-container">
            <div class="login-card">
                <div class="login-header">
                    <h2>مرحباً بك</h2>
                    <p>سجل دخولك للوصول إلى حسابك</p>
                </div>
                
                <div class="login-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <!-- Email Field -->
                        <div class="mb-4">
                            <label for="email" class="form-label">البريد الإلكتروني</label>
                            <input id="email" 
                                   type="email" 
                                   class="form-control @error('email') is-invalid @enderror" 
                                   name="email" 
                                   value="{{ old('email') }}" 
                                   required 
                                   autocomplete="email" 
                                   autofocus
                                   placeholder="أدخل بريدك الإلكتروني">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Password Field -->
                        <div class="mb-4">
                            <label for="password" class="form-label">كلمة المرور</label>
                            <input id="password" 
                                   type="password" 
                                   class="form-control @error('password') is-invalid @enderror" 
                                   name="password" 
                                   required 
                                   autocomplete="current-password"
                                   placeholder="أدخل كلمة المرور">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <!-- Remember Me -->
                        <div class="mb-4">
                            <div class="form-check">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="remember" 
                                       id="remember" 
                                       {{ old('remember') ? 'checked' : '' }}>
                                <label class="form-check-label" for="remember">
                                    تذكرني
                                </label>
                            </div>
                        </div>

                        <!-- Login Button -->
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary btn-login">
                                تسجيل الدخول
                            </button>
                        </div>

                        <!-- Forgot Password -->
                        @if (Route::has('password.request'))
                            <div class="text-center">
                                <a href="{{ route('password.request') }}" class="text-decoration-none">
                                    نسيت كلمة المرور؟
                                </a>
                            </div>
                        @endif

                        <!-- Register Link -->
                        @if (Route::has('register'))
                            <div class="divider">
                                <span>أو</span>
                            </div>
                            
                            <div class="text-center">
                                <p class="mb-0">ليس لديك حساب؟ 
                                    <a href="{{ route('register') }}" class="text-decoration-none fw-bold">
                                        سجل الآن
                                    </a>
                                </p>
                            </div>
                        @endif
                    </form>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer>
            <div class="container">
                <p class="mb-0">&copy; {{ date('Y') }} منصة حجوزات السودان. جميع الحقوق محفوظة.</p>
            </div>
        </footer>

        <!-- Bootstrap 5 JS Bundle -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
