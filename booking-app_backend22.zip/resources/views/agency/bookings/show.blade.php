@extends('layouts.agency')

@section('title', __('Booking Details'))
@section('header', __('Booking Details'))

@section('content')
@php
    $service = $booking->serviceable;
    if ($service instanceof \App\Models\Flight) {
        $flightType = $service->flight_type ?? 'air';
        $label = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
    } elseif ($service instanceof \App\Models\CargoService) {
        $label = __('Cargo');
    } else {
        $label = __('Service');
    }
@endphp

<div class="row">
    <div class="col-lg-8">
        <!-- معلومات الحجز -->
        <div class="card shadow-sm mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>معلومات الحجز</h5>
            </div>
            <div class="card-body">
                <div class="row mb-2">
                    <div class="col-md-6">
                        <strong>{{ __('Booking ID') }}:</strong> #{{ $booking->id }}
                    </div>
                    <div class="col-md-6">
                        <strong>نوع الخدمة:</strong>
                        @if($service instanceof \App\Models\Flight)
                            @if($flightType === 'sea')
                                <span class="badge bg-primary"><i class="fas fa-ship me-1"></i>رحلة بحرية</span>
                            @else
                                <span class="badge bg-info"><i class="fas fa-plane me-1"></i>رحلة طيران</span>
                            @endif
                        @else
                            <span class="badge bg-warning"><i class="fas fa-box me-1"></i>شحن</span>
                        @endif
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6">
                        <strong>{{ __('Status') }}:</strong> 
                        <span class="badge bg-{{ 
                            $booking->status === 'completed' ? 'success' : 
                            ($booking->status === 'paid' ? 'info' : 
                            ($booking->status === 'pending' ? 'warning' : 'danger')) 
                        }}">
                            {{ __(strtolower($booking->status)) }}
                        </span>
                    </div>
                    <div class="col-md-6">
                        <strong>{{ __('Customer') }}:</strong> {{ $booking->user->name ?? __('N/A') }}
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6">
                        <strong>{{ __('Total') }}:</strong> 
                        <span class="text-primary fw-bold fs-5">${{ number_format($booking->total_price, 2) }}</span>
                    </div>
                    <div class="col-md-6">
                        <strong>طريقة الدفع:</strong>
                        @if($booking->payment_method === 'cash_on_delivery')
                            <span class="badge bg-warning text-dark">
                                <i class="fas fa-money-bill-wave me-1"></i>الدفع عند الاستلام
                            </span>
                        @elseif($booking->payment_method === 'manual_receipt')
                            <span class="badge bg-info">
                                <i class="fas fa-receipt me-1"></i>إيصال تحويل بنكي
                            </span>
                        @else
                            <span class="badge bg-secondary">
                                {{ $booking->payment_method ?? 'غير محدد' }}
                            </span>
                        @endif
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6">
                        <strong>حالة الدفع:</strong>
                        @if($booking->payment_status === 'paid')
                            <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>مدفوع</span>
                        @elseif($booking->payment_status === 'pending_cod')
                            <span class="badge bg-warning text-dark"><i class="fas fa-truck me-1"></i>في انتظار الدفع عند الاستلام</span>
                        @elseif($booking->payment_status === 'pending_verification')
                            <span class="badge bg-info"><i class="fas fa-hourglass-half me-1"></i>في انتظار التحقق</span>
                        @elseif($booking->payment_status === 'rejected')
                            <span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i>مرفوض</span>
                        @else
                            <span class="badge bg-danger"><i class="fas fa-clock me-1"></i>غير مدفوع</span>
                        @endif
                    </div>
                    <div class="col-md-6">
                        <strong>{{ __('Created At') }}:</strong> {{ $booking->created_at->format('Y-m-d H:i') }}
                    </div>
                </div>
                
                @if($booking->status === 'rejected' && $booking->rejection_reason)
                    <div class="alert alert-danger mt-3">
                        <strong>{{ __('Rejection Reason') }}:</strong> {{ $booking->rejection_reason }}
                    </div>
                @endif

                {{-- Payment Rejection Reason --}}
                @if($booking->payment_status === 'rejected' && $booking->payment_rejection_reason)
                    <div class="alert alert-danger mt-3">
                        <strong><i class="fas fa-ban me-2"></i>سبب رفض الإيصال:</strong> {{ $booking->payment_rejection_reason }}
                    </div>
                @endif
            </div>
        </div>

        {{-- Payment Receipt Card for Agency --}}
        @if($booking->payment_method === 'manual_receipt' && $booking->payment_proof_image)
        <div class="card shadow-sm mb-3">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-receipt me-2"></i>إيصال الدفع</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <label class="text-muted small">حالة التحقق</label>
                        <p>
                            @if($booking->payment_status === 'paid')
                                <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>تم التحقق والموافقة</span>
                            @elseif($booking->payment_status === 'pending_verification')
                                <span class="badge bg-warning text-dark"><i class="fas fa-hourglass-half me-1"></i>في انتظار مراجعة الإدارة</span>
                            @elseif($booking->payment_status === 'rejected')
                                <span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i>مرفوض</span>
                            @endif
                        </p>
                    </div>
                    <div class="col-md-6">
                        <label class="text-muted small">المبلغ</label>
                        <p class="fw-bold text-primary">${{ number_format($booking->total_price, 2) }}</p>
                    </div>
                </div>
                <div class="mt-3">
                    <label class="text-muted small d-block mb-2">صورة الإيصال</label>
                    <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" target="_blank">
                        <img src="{{ asset('storage/' . $booking->payment_proof_image) }}" 
                             alt="إيصال الدفع" 
                             class="img-fluid rounded shadow-sm" 
                             style="max-height: 300px;">
                    </a>
                </div>
            </div>
        </div>
        @endif
        
        <!-- تفاصيل الخدمة -->
        <div class="card shadow-sm mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>تفاصيل {{ $label }}</h5>
            </div>
            <div class="card-body">
                @if($service instanceof \App\Models\Flight)
                    @php
                        $flightType = $service->flight_type ?? 'air';
                    @endphp
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الرحلة</label>
                            <p class="fw-bold">{{ $service->flight_number }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">نوع الرحلة</label>
                            <p>
                                @if($flightType === 'sea')
                                    <span class="badge bg-primary"><i class="fas fa-ship"></i> بحري</span>
                                @else
                                    <span class="badge bg-info"><i class="fas fa-plane"></i> جوي</span>
                                @endif
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                @if($flightType === 'sea')
                                    <i class="fas fa-anchor me-1"></i>ميناء المغادرة
                                @else
                                    <i class="fas fa-plane-departure me-1"></i>مطار المغادرة
                                @endif
                            </label>
                            <p class="fw-bold">{{ $service->origin }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                @if($flightType === 'sea')
                                    <i class="fas fa-anchor me-1"></i>ميناء الوصول
                                @else
                                    <i class="fas fa-plane-arrival me-1"></i>مطار الوصول
                                @endif
                            </label>
                            <p class="fw-bold">{{ $service->destination }}</p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i>وقت المغادرة</label>
                            <p>{{ $service->departure_time->format('Y-m-d H:i') }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i>وقت الوصول</label>
                            <p>{{ $service->arrival_time->format('Y-m-d H:i') }}</p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">عدد المقاعد المحجوزة</label>
                            <p><i class="fas fa-chair me-1"></i>{{ $booking->seats_count ?? 1 }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">حالة الرحلة</label>
                            <p>
                                <span class="badge bg-{{ 
                                    $service->status === 'active' ? 'success' : 
                                    ($service->status === 'pending' ? 'warning' : 'danger') 
                                }}">
                                    {{ __(strtolower($service->status)) }}
                                </span>
                            </p>
                        </div>
                        
                        @if($booking->selected_baggage_weight)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">الأمتعة</label>
                                <p><i class="fas fa-suitcase me-1"></i>{{ $booking->selected_baggage_weight }} كجم</p>
                            </div>
                        @endif
                    </div>
                    
                @elseif($service instanceof \App\Models\CargoService)
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الشحنة</label>
                            <p class="fw-bold">#{{ $service->id }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">نوع الشحن</label>
                            <p>{{ $service->type ?? 'عادي' }}</p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>من</label>
                            <p class="fw-bold">{{ $service->route_from }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>إلى</label>
                            <p class="fw-bold">{{ $service->route_to }}</p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">السعر لكل كجم</label>
                            <p class="text-success fw-bold">${{ number_format($service->price_per_kg, 2) }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الوزن</label>
                            <p><i class="fas fa-weight me-1"></i>{{ $booking->weight }} كجم</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">التكلفة</label>
                            <p class="text-primary fw-bold">${{ number_format($booking->total_price, 2) }}</p>
                        </div>
                        
                        @if($service->estimated_days)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">مدة التوصيل</label>
                                <p><i class="fas fa-clock me-1"></i>{{ $service->estimated_days }} يوم</p>
                            </div>
                        @endif
                        
                        @if($service->tracking_status)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">حالة التتبع</label>
                                <p><span class="badge bg-warning">{{ $service->tracking_status }}</span></p>
                            </div>
                        @endif
                        
                        @if($service->contents_description)
                            <div class="col-12 mb-3">
                                <label class="text-muted small">وصف المحتويات</label>
                                <p class="border-start border-3 border-info ps-3">{{ $service->contents_description }}</p>
                            </div>
                        @endif
                    </div>
                @else
                    <p class="text-muted">تفاصيل الخدمة غير متوفرة</p>
                @endif
            </div>
        </div>
        
        <!-- معلومات المسافر (للرحلات فقط) -->
        @if($service instanceof \App\Models\Flight && $booking->passenger_first_name)
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-user me-2"></i>معلومات المسافر</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">الاسم الكامل</label>
                            <p class="fw-bold">
                                {{ $booking->passenger_title ?? '' }} 
                                {{ $booking->passenger_first_name }} 
                                {{ $booking->passenger_middle_name ?? '' }} 
                                {{ $booking->passenger_last_name ?? '' }}
                            </p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">نوع المسافر</label>
                            <p>
                                <span class="badge bg-{{ $booking->passenger_type === 'adult' ? 'primary' : 'info' }}">
                                    {{ $booking->passenger_type === 'adult' ? 'بالغ' : 'طفل' }}
                                </span>
                            </p>
                        </div>
                        
                        @if($booking->passenger_date_of_birth)
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">تاريخ الميلاد</label>
                                <p><i class="fas fa-birthday-cake me-1"></i>{{ $booking->passenger_date_of_birth->format('Y-m-d') }}</p>
                            </div>
                        @endif
                        
                        @if($booking->passenger_nationality)
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">الجنسية</label>
                                <p><i class="fas fa-flag me-1"></i>{{ $booking->passenger_nationality }}</p>
                            </div>
                        @endif
                        
                        @if($booking->passenger_phone)
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">الهاتف</label>
                                <p><i class="fas fa-phone me-1"></i>{{ $booking->passenger_phone }}</p>
                            </div>
                        @endif
                        
                        @if($booking->passport_number)
                            <div class="col-12"><hr></div>
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">رقم الجواز</label>
                                <p class="fw-bold">{{ $booking->passport_number }}</p>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">دولة الإصدار</label>
                                <p>{{ $booking->passport_issuing_country ?? __('N/A') }}</p>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-muted small">تاريخ الانتهاء</label>
                                <p>
                                    @if($booking->passport_expiry_date)
                                        {{ $booking->passport_expiry_date->format('Y-m-d') }}
                                    @else
                                        {{ __('N/A') }}
                                    @endif
                                </p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @endif
    </div>
    
    <div class="col-lg-4">
        <!-- معلومات العميل -->
        <div class="card shadow-sm mb-3">
            <div class="card-header">
                <h6 class="mb-0">معلومات العميل</h6>
            </div>
            <div class="card-body">
                @if($booking->user)
                    <div class="text-center mb-3">
                        <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center" 
                             style="width: 60px; height: 60px; font-size: 24px;">
                            {{ strtoupper(substr($booking->user->name, 0, 1)) }}
                        </div>
                    </div>
                    <h6 class="text-center">{{ $booking->user->name }}</h6>
                    <p class="text-center text-muted small">{{ $booking->user->email }}</p>
                    @if($booking->user->phone)
                        <p class="text-center text-muted small">
                            <i class="fas fa-phone me-1"></i>{{ $booking->user->phone }}
                        </p>
                    @endif
                @else
                    <p class="text-muted">غير متوفر</p>
                @endif
            </div>
        </div>
    </div>
</div>

<a href="{{ route('agency.bookings.index') }}" class="btn btn-secondary">
    <i class="fas fa-arrow-right me-2"></i>{{ __('Back') }}
</a>
@endsection
