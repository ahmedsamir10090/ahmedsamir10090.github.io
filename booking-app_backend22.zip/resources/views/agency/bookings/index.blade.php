@extends('layouts.agency')

@section('title', 'الحجوزات')
@section('header', 'الحجوزات الواردة')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">قائمة الحجوزات</h5>
    <a href="{{ route('agency.bookings.create') }}" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>إضافة حجز جديد
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>العميل</th>
                        <th>الخدمة</th>
                        <th>الحالة</th>
                        <th>الإجمالي</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($bookings as $booking)
                        <tr>
                            <td>{{ $booking->id }}</td>
                            <td>{{ $booking->user->name ?? 'غير متوفر' }}</td>
                            <td>
                                @php
                                    $service = $booking->serviceable;
                                    if ($service instanceof \App\Models\Flight) {
                                        $flightType = $service->flight_type ?? 'air';
                                        $label = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
                                        $icon = $flightType === 'sea' ? 'fa-ship' : 'fa-plane';
                                        $badgeColor = $flightType === 'sea' ? 'bg-primary' : 'bg-info';
                                    } elseif ($service instanceof \App\Models\CargoService) {
                                        $label = __('Cargo');
                                        $icon = 'fa-box';
                                        $badgeColor = 'bg-warning';
                                    } else {
                                        $label = __('Service');
                                        $icon = 'fa-question';
                                        $badgeColor = 'bg-secondary';
                                    }
                                @endphp
                                <span class="badge {{ $badgeColor }}">
                                    <i class="fas {{ $icon }} me-1"></i>{{ $label }}
                                </span>
                                @if($service instanceof \App\Models\Flight)
                                    <br><small class="text-muted">{{ $service->flight_number }}</small>
                                    <br><small class="text-muted">{{ $service->origin }} → {{ $service->destination }}</small>
                                @elseif($service instanceof \App\Models\CargoService)
                                    <br><small class="text-muted">{{ $service->route_from }} → {{ $service->route_to }}</small>
                                @endif
                            </td>
                            <td><span class="badge bg-secondary">{{ __(strtolower($booking->status)) }}</span></td>
                            <td>${{ number_format($booking->total_price, 2) }}</td>
                            <td>{{ $booking->created_at }}</td>
                            <td class="d-flex gap-2">
                                <a href="{{ route('agency.bookings.show', $booking) }}" class="btn btn-sm btn-outline-secondary">{{ __('View') }}</a>
                                <form action="{{ route('agency.bookings.updateStatus', $booking->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    <input type="hidden" name="status" value="accepted">
                                    <button type="submit" class="btn btn-sm btn-success">{{ __('Accept') }}</button>
                                </form>
                                <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal" data-booking-id="{{ $booking->id }}">{{ __('Reject') }}</button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted">{{ __('No bookings found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $bookings->links() }}
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="rejectForm">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('Reject Booking') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="status" value="rejected">
                    <div class="mb-3">
                        <label class="form-label">{{ __('Reason') }}</label>
                        <textarea name="reason" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                    <button type="submit" class="btn btn-danger">{{ __('Reject') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const rejectModal = document.getElementById('rejectModal');
    rejectModal.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const bookingId = button.getAttribute('data-booking-id');
        const form = document.getElementById('rejectForm');
        form.action = `{{ url('agency/bookings') }}/${bookingId}/status`;
    });
</script>
@endpush
