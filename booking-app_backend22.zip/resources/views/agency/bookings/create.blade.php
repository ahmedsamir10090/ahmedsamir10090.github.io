@extends('layouts.agency')

@section('title', 'إضافة حجز جديد')
@section('header', 'إضافة حجز جديد')

@push('styles')
<style>
    .gradient-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 8px 8px 0 0;
    }
    .section-header {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
        padding: 0.75rem 1rem;
        border-radius: 6px;
        margin-bottom: 1rem;
    }
</style>
@endpush

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0">
                <div class="gradient-header">
                    <h4 class="mb-1"><i class="fas fa-ticket-alt me-2"></i>إضافة حجز جديد</h4>
                    <p class="mb-0 small opacity-75">املأ جميع البيانات المطلوبة لإنشاء الحجز</p>
                </div>
                
                <div class="card-body p-4">
                    @if($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>يوجد أخطاء في النموذج:</strong>
                            <ul class="mb-0 mt-2">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif
                    
                    <form action="{{ route('agency.bookings.store') }}" method="POST" enctype="multipart/form-data" id="bookingForm">
                        @csrf
                        
                        <!-- معلومات المستخدم والرحلة -->
                        <div class="section-header">
                            <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>معلومات الحجز الأساسية</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="user_id" class="form-label">العميل <span class="text-danger">*</span></label>
                                <select class="form-select @error('user_id') is-invalid @enderror" 
                                        id="user_id" 
                                        name="user_id" 
                                        required>
                                    <option value="">اختر العميل</option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                                            {{ $user->name }} ({{ $user->email }})
                                        </option>
                                    @endforeach
                                </select>
                                @error('user_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="service_id" class="form-label">الرحلة <span class="text-danger">*</span></label>
                                <select class="form-select @error('service_id') is-invalid @enderror" 
                                        id="service_id" 
                                        name="service_id" 
                                        required>
                                    <option value="">اختر الرحلة</option>
                                    @foreach($flights as $flight)
                                        <option value="{{ $flight->id }}" 
                                                data-adult-price="{{ $flight->adult_price }}"
                                                data-child-price="{{ $flight->child_price }}"
                                                data-baggage-prices="{{ json_encode($flight->baggage_prices ?? []) }}"
                                                {{ old('service_id') == $flight->id ? 'selected' : '' }}>
                                            {{ $flight->flight_number }} - {{ $flight->origin }} → {{ $flight->destination }} 
                                            ({{ $flight->departure_time->format('Y-m-d H:i') }})
                                        </option>
                                    @endforeach
                                </select>
                                @error('service_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <input type="hidden" name="service_type" value="flight">
                            </div>
                        </div>
                        
                        <!-- معلومات المسافر الشخصية -->
                        <div class="section-header mt-4">
                            <h5 class="mb-0"><i class="fas fa-user me-2"></i>معلومات المسافر</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="passenger_title" class="form-label">اللقب <span class="text-danger">*</span></label>
                                <select class="form-select @error('passenger_title') is-invalid @enderror" 
                                        id="passenger_title" 
                                        name="passenger_title" 
                                        required>
                                    <option value="">اختر</option>
                                    <option value="mr" {{ old('passenger_title') == 'mr' ? 'selected' : '' }}>السيد</option>
                                    <option value="ms" {{ old('passenger_title') == 'ms' ? 'selected' : '' }}>الآنسة</option>
                                    <option value="mrs" {{ old('passenger_title') == 'mrs' ? 'selected' : '' }}>السيدة</option>
                                </select>
                                @error('passenger_title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_first_name" class="form-label">الاسم الأول <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('passenger_first_name') is-invalid @enderror" 
                                       id="passenger_first_name" 
                                       name="passenger_first_name" 
                                       value="{{ old('passenger_first_name') }}" 
                                       required>
                                @error('passenger_first_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_middle_name" class="form-label">الاسم الأوسط</label>
                                <input type="text" 
                                       class="form-control @error('passenger_middle_name') is-invalid @enderror" 
                                       id="passenger_middle_name" 
                                       name="passenger_middle_name" 
                                       value="{{ old('passenger_middle_name') }}">
                                @error('passenger_middle_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_last_name" class="form-label">اسم العائلة <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('passenger_last_name') is-invalid @enderror" 
                                       id="passenger_last_name" 
                                       name="passenger_last_name" 
                                       value="{{ old('passenger_last_name') }}" 
                                       required>
                                @error('passenger_last_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="passenger_date_of_birth" class="form-label">تاريخ الميلاد <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control @error('passenger_date_of_birth') is-invalid @enderror" 
                                       id="passenger_date_of_birth" 
                                       name="passenger_date_of_birth" 
                                       value="{{ old('passenger_date_of_birth') }}" 
                                       required>
                                @error('passenger_date_of_birth')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passenger_nationality" class="form-label">الجنسية <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('passenger_nationality') is-invalid @enderror" 
                                       id="passenger_nationality" 
                                       name="passenger_nationality" 
                                       value="{{ old('passenger_nationality') }}" 
                                       required>
                                @error('passenger_nationality')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passenger_type" class="form-label">نوع المسافر <span class="text-danger">*</span></label>
                                <select class="form-select @error('passenger_type') is-invalid @enderror" 
                                        id="passenger_type" 
                                        name="passenger_type" 
                                        required>
                                    <option value="">اختر النوع</option>
                                    <option value="adult" {{ old('passenger_type') == 'adult' ? 'selected' : '' }}>بالغ</option>
                                    <option value="child" {{ old('passenger_type') == 'child' ? 'selected' : '' }}>طفل</option>
                                </select>
                                @error('passenger_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <!-- بيانات الاتصال -->
                        <div class="section-header mt-4">
                            <h5 class="mb-0"><i class="fas fa-phone me-2"></i>بيانات الاتصال</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="passenger_phone" class="form-label">رقم الجوال <span class="text-danger">*</span></label>
                                <input type="tel" 
                                       class="form-control @error('passenger_phone') is-invalid @enderror" 
                                       id="passenger_phone" 
                                       name="passenger_phone" 
                                       value="{{ old('passenger_phone') }}" 
                                       required>
                                @error('passenger_phone')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="passenger_whatsapp" class="form-label">رقم الواتساب</label>
                                <input type="tel" 
                                       class="form-control @error('passenger_whatsapp') is-invalid @enderror" 
                                       id="passenger_whatsapp" 
                                       name="passenger_whatsapp" 
                                       value="{{ old('passenger_whatsapp') }}">
                                @error('passenger_whatsapp')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <!-- وثائق السفر -->
                        <div class="section-header mt-4">
                            <h5 class="mb-0"><i class="fas fa-passport me-2"></i>وثائق السفر</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="passport_number" class="form-label">رقم الجواز <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('passport_number') is-invalid @enderror" 
                                       id="passport_number" 
                                       name="passport_number" 
                                       value="{{ old('passport_number') }}" 
                                       required>
                                @error('passport_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passport_issuing_country" class="form-label">بلد الإصدار <span class="text-danger">*</span></label>
                                <input type="text" 
                                       class="form-control @error('passport_issuing_country') is-invalid @enderror" 
                                       id="passport_issuing_country" 
                                       name="passport_issuing_country" 
                                       value="{{ old('passport_issuing_country') }}" 
                                       required>
                                @error('passport_issuing_country')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passport_expiry_date" class="form-label">تاريخ انتهاء الجواز <span class="text-danger">*</span></label>
                                <input type="date" 
                                       class="form-control @error('passport_expiry_date') is-invalid @enderror" 
                                       id="passport_expiry_date" 
                                       name="passport_expiry_date" 
                                       value="{{ old('passport_expiry_date') }}" 
                                       required>
                                @error('passport_expiry_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="passport_image" class="form-label">صورة الجواز</label>
                                <input type="file" 
                                       class="form-control @error('passport_image') is-invalid @enderror" 
                                       id="passport_image" 
                                       name="passport_image" 
                                       accept="image/jpeg,image/png,image/jpg">
                                <small class="text-muted">اختياري - الحد الأقصى 2 ميجابايت</small>
                                @error('passport_image')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <!-- الأمتعة والتسعير -->
                        <div class="section-header mt-4">
                            <h5 class="mb-0"><i class="fas fa-suitcase me-2"></i>الأمتعة والتسعير</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="seats_count" class="form-label">عدد المقاعد <span class="text-danger">*</span></label>
                                <input type="number" 
                                       class="form-control @error('seats_count') is-invalid @enderror" 
                                       id="seats_count" 
                                       name="seats_count" 
                                       value="{{ old('seats_count', 1) }}" 
                                       min="1" 
                                       required>
                                @error('seats_count')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="selected_baggage_weight" class="form-label">وزن الأمتعة</label>
                                <select class="form-select @error('selected_baggage_weight') is-invalid @enderror" 
                                        id="selected_baggage_weight" 
                                        name="selected_baggage_weight">
                                    <option value="">بدون أمتعة</option>
                                </select>
                                @error('selected_baggage_weight')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">السعر الإجمالي</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-success text-white">$</span>
                                    <input type="text" 
                                           class="form-control form-control-lg fw-bold text-success" 
                                           id="total_price_display" 
                                           readonly 
                                           value="0.00">
                                </div>
                                <input type="hidden" name="total_price" id="total_price" value="0">
                            </div>
                        </div>
                        
                        <!-- حالة الحجز والدفع -->
                        <div class="section-header mt-4">
                            <h5 class="mb-0"><i class="fas fa-cog me-2"></i>حالة الحجز</h5>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">حالة الحجز <span class="text-danger">*</span></label>
                                <select class="form-select @error('status') is-invalid @enderror" 
                                        id="status" 
                                        name="status" 
                                        required>
                                    <option value="pending" {{ old('status') == 'pending' ? 'selected' : '' }}>قيد الانتظار</option>
                                    <option value="accepted" {{ old('status') == 'accepted' ? 'selected' : '' }}>مقبول</option>
                                    <option value="completed" {{ old('status') == 'completed' ? 'selected' : '' }}>مكتمل</option>
                                    <option value="rejected" {{ old('status') == 'rejected' ? 'selected' : '' }}>مرفوض</option>
                                    <option value="cancelled" {{ old('status') == 'cancelled' ? 'selected' : '' }}>ملغي</option>
                                </select>
                                @error('status')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="payment_method" class="form-label">طريقة الدفع <span class="text-danger">*</span></label>
                                <select class="form-select @error('payment_method') is-invalid @enderror" 
                                        id="payment_method" 
                                        name="payment_method" 
                                        required>
                                    <option value="wallet" {{ old('payment_method') == 'wallet' ? 'selected' : '' }}>محفظة</option>
                                    <option value="stripe" {{ old('payment_method') == 'stripe' ? 'selected' : '' }}>بطاقة ائتمان</option>
                                    <option value="manual_receipt" {{ old('payment_method') == 'manual_receipt' ? 'selected' : '' }}>إيصال يدوي</option>
                                </select>
                                @error('payment_method')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <!-- أزرار الإرسال -->
                        <div class="mt-4 pt-3 border-top">
                            <button type="submit" class="btn btn-primary btn-lg px-5">
                                <i class="fas fa-save me-2"></i>إضافة الحجز
                            </button>
                            <a href="{{ route('agency.bookings.index') }}" class="btn btn-secondary btn-lg px-4">
                                <i class="fas fa-times me-2"></i>إلغاء
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const flightSelect = document.getElementById('service_id');
    const passengerTypeSelect = document.getElementById('passenger_type');
    const baggageWeightSelect = document.getElementById('selected_baggage_weight');
    const seatsCountInput = document.getElementById('seats_count');
    const totalPriceDisplay = document.getElementById('total_price_display');
    const totalPriceInput = document.getElementById('total_price');
    
    function updateBaggageOptions() {
        const selectedOption = flightSelect.options[flightSelect.selectedIndex];
        if (!selectedOption.value) {
            baggageWeightSelect.innerHTML = '<option value="">بدون أمتعة</option>';
            return;
        }
        
        const baggagePrices = JSON.parse(selectedOption.dataset.baggagePrices || '{}');
        
        baggageWeightSelect.innerHTML = '<option value="">بدون أمتعة</option>';
        
        Object.keys(baggagePrices).forEach(weight => {
            const price = baggagePrices[weight];
            const option = document.createElement('option');
            option.value = weight;
            option.textContent = `${weight} كجم (+$${parseFloat(price).toFixed(2)})`;
            baggageWeightSelect.appendChild(option);
        });
    }
    
    function calculateTotalPrice() {
        const selectedFlight = flightSelect.options[flightSelect.selectedIndex];
        if (!selectedFlight.value || !passengerTypeSelect.value) {
            totalPriceDisplay.value = '0.00';
            totalPriceInput.value = '0';
            return;
        }
        
        // Get base price (adult or child)
        const basePrice = passengerTypeSelect.value === 'adult' 
            ? parseFloat(selectedFlight.dataset.adultPrice || 0)
            : parseFloat(selectedFlight.dataset.childPrice || 0);
        
        // Get baggage price
        let baggagePrice = 0;
        if (baggageWeightSelect.value) {
            const baggagePrices = JSON.parse(selectedFlight.dataset.baggagePrices || '{}');
            baggagePrice = parseFloat(baggagePrices[baggageWeightSelect.value] || 0);
        }
        
        // Calculate total
        const seatsCount = parseInt(seatsCountInput.value) || 1;
        const totalPrice = (basePrice + baggagePrice) * seatsCount;
        
        totalPriceDisplay.value = totalPrice.toFixed(2);
        totalPriceInput.value = totalPrice.toFixed(2);
    }
    
    // Event listeners
    flightSelect.addEventListener('change', function() {
        updateBaggageOptions();
        calculateTotalPrice();
    });
    
    passengerTypeSelect.addEventListener('change', calculateTotalPrice);
    baggageWeightSelect.addEventListener('change', calculateTotalPrice);
    seatsCountInput.addEventListener('input', calculateTotalPrice);
    
    // Initialize on page load
    if (flightSelect.value) {
        updateBaggageOptions();
        calculateTotalPrice();
    }
});
</script>
@endpush
