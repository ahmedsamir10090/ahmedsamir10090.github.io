@extends('layouts.agency')

@section('title', __('Edit Flight'))
@section('header', __('Edit Flight'))

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
@endpush

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <form action="{{ route('agency.flights.update', $flight) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">{{ __('Flight Number') }}</label>
                    <input type="text" name="flight_number" class="form-control" value="{{ old('flight_number', $flight->flight_number) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Flight Type') }}</label>
                    <select name="flight_type" class="form-select" required>
                        <option value="air" {{ old('flight_type', $flight->flight_type ?? 'air') === 'air' ? 'selected' : '' }}>{{ __('Air Flight') }}</option>
                        <option value="sea" {{ old('flight_type', $flight->flight_type) === 'sea' ? 'selected' : '' }}>{{ __('Sea Travel') }}</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Status') }}</label>
                    <select name="status" class="form-select" required>
                        @foreach(['pending','active','cancelled'] as $status)
                            <option value="{{ $status }}" {{ old('status', $flight->status) === $status ? 'selected' : '' }}>{{ __(strtolower($status)) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6"></div>
                
                <!-- حقول المطارات (رحلات طيران) -->
                <div class="col-md-6 airports-section">
                    <label class="form-label">{{ __('Origin Airport') }}</label>
                    <select name="origin_airport_id" id="origin_airport_id" class="form-select select2">
                        <option value="">{{ __('Select Origin Airport') }}</option>
                        @foreach($countries as $country)
                            <optgroup label="{{ $country->name }}">
                                @foreach($country->airports as $airport)
                                    <option value="{{ $airport->id }}" {{ old('origin_airport_id', $flight->origin_airport_id) == $airport->id ? 'selected' : '' }}>
                                        {{ $airport->name }} ({{ $airport->iata_code }})
                                    </option>
                                @endforeach
                            </optgroup>
                        @endforeach
                    </select>
                </div>
                
                <!-- حقول الموانئ (رحلات بحرية) -->
                <div class="col-md-6 ports-section" style="display: none;">
                    <label class="form-label">ميناء المغادرة</label>
                    <select name="origin_port_id" id="origin_port_id" class="form-select select2">
                        <option value="">اختر ميناء المغادرة</option>
                        @foreach($countries as $country)
                            @if($country->ports->count() > 0)
                                <optgroup label="{{ $country->name }}">
                                    @foreach($country->ports as $port)
                                        <option value="{{ $port->id }}" {{ old('origin_port_id', $flight->origin_port_id) == $port->id ? 'selected' : '' }}>
                                            {{ $port->name }} ({{ $port->code }})
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        @endforeach
                    </select>
                </div>
                
                <div class="col-md-6 airports-section">
                    <label class="form-label">{{ __('Destination Airport') }}</label>
                    <select name="destination_airport_id" id="destination_airport_id" class="form-select select2">
                        <option value="">{{ __('Select Destination Airport') }}</option>
                        @foreach($countries as $country)
                            <optgroup label="{{ $country->name }}">
                                @foreach($country->airports as $airport)
                                    <option value="{{ $airport->id }}" {{ old('destination_airport_id', $flight->destination_airport_id) == $airport->id ? 'selected' : '' }}>
                                        {{ $airport->name }} ({{ $airport->iata_code }})
                                    </option>
                                @endforeach
                            </optgroup>
                        @endforeach
                    </select>
                </div>
                
                <div class="col-md-6 ports-section" style="display: none;">
                    <label class="form-label">ميناء الوصول</label>
                    <select name="destination_port_id" id="destination_port_id" class="form-select select2">
                        <option value="">اختر ميناء الوصول</option>
                        @foreach($countries as $country)
                            @if($country->ports->count() > 0)
                                <optgroup label="{{ $country->name }}">
                                    @foreach($country->ports as $port)
                                        <option value="{{ $port->id }}" {{ old('destination_port_id', $flight->destination_port_id) == $port->id ? 'selected' : '' }}>
                                            {{ $port->name }} ({{ $port->code }})
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Departure Time') }}</label>
                    <input type="datetime-local" name="departure_time" class="form-control" value="{{ old('departure_time', $flight->departure_time?->format('Y-m-d\TH:i')) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Arrival Time') }}</label>
                    <input type="datetime-local" name="arrival_time" class="form-control" value="{{ old('arrival_time', $flight->arrival_time?->format('Y-m-d\TH:i')) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Price') }}</label>
                    <input type="number" step="0.01" min="0" name="price" class="form-control" value="{{ old('price', $flight->price) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Available Seats') }}</label>
                    <input type="number" min="0" name="available_seats" class="form-control" value="{{ old('available_seats', $flight->available_seats) }}" required>
                </div>
            </div>
            <div class="mt-4 d-flex justify-content-between">
                <a href="{{ route('agency.flights.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Update Flight') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: '100%',
            dir: '{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}',
            language: {
                noResults: function() {
                    return '{{ __('No results found') }}';
                },
                searching: function() {
                    return '{{ __('Searching...') }}';
                }
            }
        });
    });
</script>
@endpush