@extends('layouts.agency')

@section('title', __('Flights'))
@section('header', __('My Flights'))

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">{{ __('Flights') }}</h5>
    <a href="{{ route('agency.flights.create') }}" class="btn btn-primary btn-sm">{{ __('Add Flight') }}</a>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>{{ __('Flight') }}</th>
                        <th>{{ __('Route') }}</th>
                        <th>{{ __('Departure') }}</th>
                        <th>{{ __('Arrival') }}</th>
                        <th class="text-end">{{ __('Price') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th class="text-end">{{ __('Seats') }}</th>
                        <th>{{ __('Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($flights as $flight)
                        <tr>
                            <td>{{ $flight->id }}</td>
                            <td>{{ $flight->flight_number }}</td>
                            <td>{{ $flight->origin }} &rarr; {{ $flight->destination }}</td>
                            <td>{{ $flight->departure_time }}</td>
                            <td>{{ $flight->arrival_time }}</td>
                            <td class="text-end">${{ number_format($flight->price, 2) }}</td>
                            <td><span class="badge bg-secondary">{{ __(strtolower($flight->status)) }}</span></td>
                            <td class="text-end">{{ $flight->available_seats }}</td>
                            <td>
                                <a href="{{ route('agency.flights.edit', $flight) }}" class="btn btn-sm btn-outline-secondary">{{ __('Edit') }}</a>
                                <form action="{{ route('agency.flights.destroy', $flight) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Delete this flight?') }}');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="text-center text-muted">{{ __('No flights found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $flights->links() }}
    </div>
</div>
@endsection
