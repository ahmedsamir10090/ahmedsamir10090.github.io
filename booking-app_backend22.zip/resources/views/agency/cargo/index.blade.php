@extends('layouts.agency')

@section('title', __('Cargo Services'))
@section('header', __('My Cargo Services'))

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">{{ __('Cargo Services') }}</h5>
    <a href="{{ route('agency.cargo.create') }}" class="btn btn-primary btn-sm">{{ __('Add Service') }}</a>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>{{ __('Type') }}</th>
                        <th class="text-end">{{ __('Price / Kg') }}</th>
                        <th class="text-end">{{ __('Min Weight') }}</th>
                        <th>{{ __('Delivery ETA') }}</th>
                        <th>{{ __('Route') }}</th>
                        <th>{{ __('Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($services as $service)
                        <tr>
                            <td>{{ $service->id }}</td>
                            <td>{{ __(strtolower($service->type)) }}</td>
                            <td class="text-end">${{ number_format($service->price_per_kg, 2) }}</td>
                            <td class="text-end">{{ number_format($service->min_weight, 2) }} {{ __('kg') }}</td>
                            <td>{{ $service->delivery_time_estimate ?? __('N/A') }}</td>
                            <td>{{ $service->route_from }} &rarr; {{ $service->route_to }}</td>
                            <td>
                                <a href="{{ route('agency.cargo.edit', $service) }}" class="btn btn-sm btn-outline-secondary">{{ __('Edit') }}</a>
                                <form action="{{ route('agency.cargo.destroy', $service) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Delete this service?') }}');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted">{{ __('No cargo services found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $services->links() }}
    </div>
</div>
@endsection
