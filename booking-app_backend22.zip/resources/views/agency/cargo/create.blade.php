@extends('layouts.agency')

@section('title', __('Create Cargo Service'))
@section('header', __('Create Cargo Service'))

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <form action="{{ route('agency.cargo.store') }}" method="POST">
            @csrf
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">{{ __('Service Type') }}</label>
                    <select name="type" class="form-select" required>
                        <option value="" disabled {{ old('type') ? '' : 'selected' }}>{{ __('Select Type') }}</option>
                        <option value="air" {{ old('type') == 'air' ? 'selected' : '' }}>{{ __('Air') }}</option>
                        <option value="sea" {{ old('type') == 'sea' ? 'selected' : '' }}>{{ __('Sea') }}</option>
                        <option value="land" {{ old('type') == 'land' ? 'selected' : '' }}>{{ __('Land') }}</option>
                    </select>
                    @error('type')
                        <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('Estimated Delivery Days') }}</label>
                    <input type="number" name="delivery_time_estimate" class="form-control" value="{{ old('delivery_time_estimate', 7) }}" placeholder="{{ __('e.g. 3-5 days') }}">
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('From Country') }} <span class="text-danger">*</span></label>
                    <select class="form-select @error('route_from') is-invalid @enderror" name="route_from" required>
                        <option value="">{{ __('Select Country') }}</option>
                        @foreach($countries as $country)
                            <option value="{{ strtolower(str_replace(' ', '_', $country->name_en)) }}" {{ old('route_from') == strtolower(str_replace(' ', '_', $country->name_en)) ? 'selected' : '' }}>
                                {{ $country->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('route_from')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-6">
                    <label class="form-label">{{ __('To Country') }} <span class="text-danger">*</span></label>
                    <select class="form-select @error('route_to') is-invalid @enderror" name="route_to" required>
                        <option value="">{{ __('Select Country') }}</option>
                        @foreach($countries as $country)
                            <option value="{{ strtolower(str_replace(' ', '_', $country->name_en)) }}" {{ old('route_to') == strtolower(str_replace(' ', '_', $country->name_en)) ? 'selected' : '' }}>
                                {{ $country->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('route_to')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">{{ __('Minimum Weight (kg)') }} <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" min="0" name="min_weight" class="form-control" value="{{ old('min_weight', 30) }}" required>
                    @error('min_weight')<div class="text-danger mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">{{ __('Maximum Weight (kg)') }} <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" min="0" name="max_weight" class="form-control" value="{{ old('max_weight', 100) }}" required>
                    @error('max_weight')<div class="text-danger mt-1">{{ $message }}</div>@enderror
                </div>
                <div class="col-md-4">
                    <label class="form-label">{{ __('Price per Kg') }} <span class="text-danger">*</span></label>
                    <input type="number" step="0.01" min="0" name="price_per_kg" class="form-control" value="{{ old('price_per_kg', 20) }}" required>
                    @error('price_per_kg')<div class="text-danger mt-1">{{ $message }}</div>@enderror
                </div>
            </div>
            <div class="mt-4 d-flex justify-content-between">
                <a href="{{ route('agency.cargo.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Save Service') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection