@extends('layouts.agency')

@section('title', __('Wallet'))
@section('header', __('My Wallet & Payouts'))

@section('content')
@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card text-white bg-success h-100 shadow-sm">
            <div class="card-body">
                <p class="mb-1 text-uppercase small">{{ __('Current Balance') }}</p>
                <h2 class="mb-0">${{ number_format($agency->current_balance, 2) }}</h2>
                <small class="text-white-50">{{ __('Available funds') }}</small>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card text-white bg-primary h-100 shadow-sm">
            <div class="card-body">
                <p class="mb-1 text-uppercase small">{{ __('Total Lifetime Earnings') }}</p>
                <h2 class="mb-0">${{ number_format($agency->total_lifetime_earnings, 2) }}</h2>
                <small class="text-white-50">{{ __('All-time revenue') }}</small>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div>
            <h5 class="mb-0">{{ __('Transaction History') }}</h5>
            <small class="text-muted">{{ __('Latest 20 transactions') }}</small>
        </div>
        <form action="{{ route('agency.wallet.payoutRequest') }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-hand-holding-dollar me-2"></i>{{ __('Request Payout') }}
            </button>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th class="text-end">{{ __('Amount') }}</th>
                        <th>{{ __('Description') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $transaction)
                        <tr>
                            <td>{{ $transaction->created_at?->format('M d, Y H:i') }}</td>
                            <td>
                                <span class="badge bg-{{ $transaction->type === 'earning' ? 'success' : 'warning' }}">
                                    {{ __(strtolower($transaction->type)) }}
                                </span>
                            </td>
                            <td class="text-end {{ $transaction->amount >= 0 ? 'text-success' : 'text-danger' }}">
                                {{ $transaction->amount >= 0 ? '+' : '-' }}${{ number_format(abs($transaction->amount), 2) }}
                            </td>
                            <td>{{ $transaction->description ?? __('N/A') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted py-3">{{ __('No transactions found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
