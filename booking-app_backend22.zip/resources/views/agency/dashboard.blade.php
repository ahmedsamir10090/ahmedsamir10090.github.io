@extends('layouts.agency')

@section('title', __('Dashboard'))
@section('header', __('Agency Dashboard'))

@section('content')
<div class="container-fluid">
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="card text-white bg-success h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 text-uppercase small">{{ __('My Total Revenue') }}</p>
                            <h4 class="mb-0">${{ number_format($stats['my_total_revenue'], 2) }}</h4>
                        </div>
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card text-white bg-warning h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 text-uppercase small">{{ __('Pending Bookings') }}</p>
                            <h4 class="mb-0">{{ $stats['my_pending_bookings'] }}</h4>
                        </div>
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card text-white bg-primary h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 text-uppercase small">{{ __('Completed Bookings') }}</p>
                            <h4 class="mb-0">{{ $stats['my_completed_bookings'] }}</h4>
                        </div>
                        <i class="fas fa-check-circle fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card text-white bg-info h-100 shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 text-uppercase small">{{ __('Active Flights') }}</p>
                            <h4 class="mb-0">{{ $stats['my_active_flights'] }}</h4>
                        </div>
                        <i class="fas fa-plane fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0">{{ __('Recent Bookings') }}</h5>
            <small class="text-muted">{{ __('Latest 5 bookings for your agency') }}</small>
        </div>
        <div class="card-body">
            @if($latestBookings->count())
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>{{ __('ID') }}</th>
                                <th>{{ __('Customer') }}</th>
                                <th class="text-end">{{ __('Amount') }}</th>
                                <th>{{ __('Status') }}</th>
                                <th>{{ __('Created At') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($latestBookings as $booking)
                                <tr>
                                    <td>{{ $booking->id }}</td>
                                    <td>{{ $booking->user->name ?? __('N/A') }}</td>
                                    <td class="text-end">${{ number_format($booking->total_price, 2) }}</td>
                                    <td>
                                        <span class="badge bg-{{
                                            $booking->status === 'completed' ? 'success' :
                                            ($booking->status === 'pending' ? 'warning' :
                                            ($booking->status === 'accepted' ? 'info' : 'secondary'))
                                        }}">{{ __(strtolower($booking->status)) }}</span>
                                    </td>
                                    <td>{{ $booking->created_at->format('M j, Y H:i') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <p class="text-muted mb-0">{{ __('No bookings found for your agency yet.') }}</p>
            @endif
        </div>
    </div>
</div>
@endsection
