@extends('layouts.agency')

@section('title', __('Add Staff'))
@section('header', __('Add Staff Member'))

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="{{ route('agency.staff.store') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label">{{ __('Name') }}</label>
                <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">{{ __('Email') }}</label>
                <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">{{ __('Password') }}</label>
                <input type="password" name="password" class="form-control" required>
                <small class="text-muted">{{ __('Minimum 8 characters.') }}</small>
            </div>
            <div class="d-flex justify-content-between">
                <a href="{{ route('agency.staff.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Create Staff') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
