@extends('layouts.agency')

@section('title', __('Staff Management'))
@section('header', __('Staff Management'))

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">{{ __('Staff Members') }}</h4>
    <a href="{{ route('agency.staff.create') }}" class="btn btn-primary">{{ __('Add Staff') }}</a>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>{{ __('Name') }}</th>
                        <th>{{ __('Email') }}</th>
                        <th class="text-end">{{ __('Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($staff as $member)
                        <tr>
                            <td>{{ $member->name }}</td>
                            <td>{{ $member->email }}</td>
                            <td class="text-end">
                                <a href="{{ route('agency.staff.edit', $member) }}" class="btn btn-sm btn-outline-secondary">{{ __('Edit') }}</a>
                                <form action="{{ route('agency.staff.destroy', $member) }}" method="POST" class="d-inline" onsubmit="return confirm('{{ __('Delete this staff member?') }}');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">{{ __('Delete') }}</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="text-center py-3 text-muted">{{ __('No staff members found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer">
        {{ $staff->links() }}
    </div>
</div>
@endsection
