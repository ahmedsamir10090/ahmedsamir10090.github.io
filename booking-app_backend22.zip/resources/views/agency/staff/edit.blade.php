@extends('layouts.agency')

@section('title', __('Edit Staff'))
@section('header', __('Edit Staff Member'))

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="{{ route('agency.staff.update', $staff) }}">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label class="form-label">{{ __('Name') }}</label>
                <input type="text" name="name" class="form-control" value="{{ old('name', $staff->name) }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">{{ __('Email') }}</label>
                <input type="email" name="email" class="form-control" value="{{ old('email', $staff->email) }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">{{ __('New Password (optional)') }}</label>
                <input type="password" name="password" class="form-control" placeholder="{{ __('Leave blank to keep current') }}">
                <small class="text-muted">{{ __('Minimum 8 characters if set.') }}</small>
            </div>
            <div class="d-flex justify-content-between">
                <a href="{{ route('agency.staff.index') }}" class="btn btn-secondary">{{ __('Cancel') }}</a>
                <button type="submit" class="btn btn-primary">{{ __('Update Staff') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection
