@extends('layouts.admin')

@section('title', __('Create Agency'))
@section('header', __('Create New Agency'))

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Agency Information') }}</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.agencies.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    
                    <!-- Agency Details -->
                    <h6 class="text-primary mb-3">{{ __('Agency Details') }}</h6>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">{{ __('Agency Name') }} *</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" value="{{ old('name') }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="license_number" class="form-label">{{ __('License Number') }}</label>
                            <input type="text" class="form-control @error('license_number') is-invalid @enderror" 
                                   id="license_number" name="license_number" value="{{ old('license_number') }}">
                            @error('license_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="logo" class="form-label">{{ __('Logo (Image)') }}</label>
                            <input type="file" class="form-control @error('logo') is-invalid @enderror" 
                                   id="logo" name="logo" accept="image/*">
                            @error('logo')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">{{ __('Status') }} *</label>
                            <select class="form-select @error('status') is-invalid @enderror" 
                                    id="status" name="status" required>
                                <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>{{ __('Active') }}</option>
                                <option value="suspended" {{ old('status') == 'suspended' ? 'selected' : '' }}>{{ __('Suspended') }}</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">{{ __('Phone') }}</label>
                            <input type="text" class="form-control @error('phone') is-invalid @enderror"
                                   id="phone" name="phone" value="{{ old('phone') }}">
                            @error('phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="commission_rate" class="form-label">{{ __('Commission Rate (%)') }}</label>
                            <input type="number" step="0.01" min="0" max="100" class="form-control @error('commission_rate') is-invalid @enderror"
                                   id="commission_rate" name="commission_rate" value="{{ old('commission_rate') }}">
                            @error('commission_rate')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <hr class="my-4">
                    
                    <!-- Manager Details -->
                    <h6 class="text-primary mb-3">{{ __('Agency Manager Details') }}</h6>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="manager_name" class="form-label">{{ __('Manager Name') }} *</label>
                            <input type="text" class="form-control @error('manager_name') is-invalid @enderror" 
                                   id="manager_name" name="manager_name" value="{{ old('manager_name') }}" required>
                            @error('manager_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="manager_email" class="form-label">{{ __('Manager Email') }} *</label>
                            <input type="email" class="form-control @error('manager_email') is-invalid @enderror" 
                                   id="manager_email" name="manager_email" value="{{ old('manager_email') }}" required>
                            @error('manager_email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="manager_password" class="form-label">{{ __('Manager Password') }} *</label>
                            <input type="password" class="form-control @error('manager_password') is-invalid @enderror" 
                                   id="manager_password" name="manager_password" required>
                            @error('manager_password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <!-- Form Actions -->
                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.agencies.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Agencies') }}
                        </a>
                        <div>
                            <button type="reset" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-undo me-2"></i>{{ __('Reset') }}
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>{{ __('Create Agency') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
