@extends('layouts.admin')

@section('title', __('Edit Agency'))
@section('header', __('Edit Agency'))

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Edit Agency') }}: {{ $agency->name }}</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.agencies.update', $agency->id) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    
                    <!-- Agency Details -->
                    <h6 class="text-primary mb-3">{{ __('Agency Details') }}</h6>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">{{ __('Agency Name') }} *</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" value="{{ old('name', $agency->name) }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="license_number" class="form-label">{{ __('License Number') }}</label>
                            <input type="text" class="form-control @error('license_number') is-invalid @enderror" 
                                   id="license_number" name="license_number" value="{{ old('license_number', $agency->license_number) }}">
                            @error('license_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="logo" class="form-label">{{ __('Logo (Image)') }}</label>
                            <input type="file" class="form-control @error('logo') is-invalid @enderror" 
                                   id="logo" name="logo" accept="image/*">
                            @error('logo')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            @if($agency->logo)
                                <div class="mt-2">
                                    <img src="{{ asset('storage/' . $agency->logo) }}" alt="{{ $agency->name }} logo" class="rounded" width="72" height="72">
                                </div>
                            @endif
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">{{ __('Status') }} *</label>
                            <select class="form-select @error('status') is-invalid @enderror" 
                                    id="status" name="status" required>
                                <option value="active" {{ old('status', $agency->status) == 'active' ? 'selected' : '' }}>{{ __('Active') }}</option>
                                <option value="suspended" {{ old('status', $agency->status) == 'suspended' ? 'selected' : '' }}>{{ __('Suspended') }}</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">{{ __('Phone') }}</label>
                            <input type="text" class="form-control @error('phone') is-invalid @enderror"
                                   id="phone" name="phone" value="{{ old('phone', $agency->phone) }}">
                            @error('phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="commission_rate" class="form-label">{{ __('Commission Rate (%)') }}</label>
                            <input type="number" step="0.01" min="0" max="100" class="form-control @error('commission_rate') is-invalid @enderror"
                                   id="commission_rate" name="commission_rate" value="{{ old('commission_rate', $agency->commission_rate) }}">
                            @error('commission_rate')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    
                    <hr class="my-4">
                    
                    <!-- Current Manager Info -->
                    <h6 class="text-primary mb-3">{{ __('Current Agency Manager') }}</h6>
                    
                    @if($agency->users->first())
                        <div class="alert alert-info">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>{{ __('Name') }}:</strong> {{ $agency->users->first()->name }}
                                </div>
                                <div class="col-md-6">
                                    <strong>{{ __('Email') }}:</strong> {{ $agency->users->first()->email }}
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>{{ __('Status') }}:</strong> 
                                    <span class="badge bg-{{ $agency->users->first()->is_active ? 'success' : 'danger' }}">
                                        {{ $agency->users->first()->is_active ? __('Active') : __('Inactive') }}
                                    </span>
                                </div>
                            </div>
                            <small class="text-muted d-block mt-2">
                                {{ __('Note: Manager account status is linked to agency status.') }}
                            </small>
                        </div>
                    @else
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            {{ __('No manager account is currently assigned to this agency.') }}
                        </div>
                    @endif
                    
                    <!-- Form Actions -->
                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.agencies.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Agencies') }}
                        </a>
                        <div>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>{{ __('Update Agency') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
