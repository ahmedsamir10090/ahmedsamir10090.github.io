@extends('layouts.admin')

@section('title', __('Agency Details'))
@section('header', __('Agency Details'))

@section('content')
<div class="d-flex justify-content-between align-items-start flex-wrap mb-4">
    <div class="d-flex align-items-center">
        @if($agency->logo)
            <img src="{{ asset('storage/' . $agency->logo) }}" alt="{{ $agency->name }}" class="rounded-circle me-3" width="64" height="64">
        @else
            <div class="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center me-3" style="width: 64px; height: 64px;">
                <i class="fas fa-building fa-lg"></i>
            </div>
        @endif
        <div>
            <h4 class="mb-1">{{ $agency->name }}</h4>
            <div class="text-muted">{{ __('License') }}: {{ $agency->license_number ?? __('N/A') }}</div>
            <span class="badge bg-{{ $agency->status === 'active' ? 'success' : 'danger' }} mt-2">
                {{ __(strtolower($agency->status)) }}
            </span>
        </div>
    </div>
    <div class="mt-3 mt-md-0">
        <a href="{{ route('admin.agencies.edit', $agency->id) }}" class="btn btn-primary me-2">
            <i class="fas fa-edit me-2"></i>{{ __('Edit Agency') }}
        </a>
        <form action="{{ route('admin.agencies.updateStatus', $agency->id) }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn btn-{{ $agency->status === 'active' ? 'warning' : 'success' }}"
                    onclick="return confirm('{{ __('Are you sure you want to :action this agency?', ['action' => $agency->status === 'active' ? __('suspend') : __('activate')]) }}')">
                {{ $agency->status === 'active' ? __('Suspend') : __('Activate') }}
            </button>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="text-muted">{{ __('Manager Info') }}</h6>
                <div class="fw-semibold">{{ $manager?->name ?? __('N/A') }}</div>
                <div class="text-muted">{{ $manager?->email ?? __('N/A') }}</div>
                <div class="text-muted">{{ $manager?->phone ?? __('N/A') }}</div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="text-muted">{{ __('Current Balance') }}</h6>
                <div class="display-6 fw-bold">${{ number_format($currentBalance, 2) }}</div>
                <div class="text-muted">{{ __('Commission') }}: {{ number_format($agency->commission_rate, 2) }}%</div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="text-muted">{{ __('Total Lifetime Earnings') }}</h6>
                <div class="display-6 fw-bold">${{ number_format($totalLifetimeEarnings, 2) }}</div>
                <div class="text-muted">{{ __('All-time revenue') }}</div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card h-100">
            <div class="card-body">
                <h6 class="text-muted">{{ __('Performance') }}</h6>
                <div class="fw-semibold">{{ __('Completed Bookings') }}: {{ $totalCompletedBookings }}</div>
                <div class="text-muted">{{ __('Active Flights') }}: {{ $activeFlightsCount }}</div>
                <div class="text-muted">{{ __('Rating') }}: {{ $agency->rating ?? __('N/A') }}</div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-end mb-4">
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#payoutModal">
        <i class="fas fa-hand-holding-dollar me-2"></i>{{ __('Make Payout') }}
    </button>
</div>

<ul class="nav nav-tabs" id="agencyTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="flights-tab" data-bs-toggle="tab" data-bs-target="#flights" type="button" role="tab">
            {{ __('Flights') }}
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="cargo-tab" data-bs-toggle="tab" data-bs-target="#cargo" type="button" role="tab">
            {{ __('Cargo Services') }}
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="bookings-tab" data-bs-toggle="tab" data-bs-target="#bookings" type="button" role="tab">
            {{ __('Recent Bookings') }}
        </button>
    </li>
</ul>

<div class="tab-content pt-3">
    <div class="tab-pane fade show active" id="flights" role="tabpanel">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ __('Route') }}</th>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('Price') }}</th>
                        <th>{{ __('Status') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($activeFlights as $flight)
                        <tr>
                            <td>{{ $flight->origin }} &rarr; {{ $flight->destination }}</td>
                            <td>{{ optional($flight->departure_time)->format('M d, Y H:i') }}</td>
                            <td>${{ number_format($flight->price, 2) }}</td>
                            <td>
                                <span class="badge bg-{{ $flight->status === 'active' ? 'success' : 'secondary' }}">
                                    {{ __(strtolower($flight->status)) }}
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted">{{ __('No active flights.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div class="tab-pane fade" id="cargo" role="tabpanel">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Route') }}</th>
                        <th>{{ __('Price / Kg') }}</th>
                        <th>{{ __('Min Weight') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($cargoServices as $service)
                        <tr>
                            <td>{{ __(strtolower($service->type)) }}</td>
                            <td>{{ $service->route_from }} &rarr; {{ $service->route_to }}</td>
                            <td>${{ number_format($service->price_per_kg, 2) }}</td>
                            <td>{{ number_format($service->min_weight, 2) }} {{ __('kg') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted">{{ __('No cargo services found.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div class="tab-pane fade" id="bookings" role="tabpanel">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ __('Customer') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Price') }}</th>
                        <th>{{ __('Created') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recentBookings as $booking)
                        <tr>
                            <td>{{ $booking->user->name ?? __('N/A') }}</td>
                            <td>
                                <span class="badge bg-{{ $booking->status === 'completed' ? 'success' : ($booking->status === 'pending' ? 'warning' : 'secondary') }}">
                                    {{ __(strtolower($booking->status)) }}
                                </span>
                            </td>
                            <td>${{ number_format($booking->total_price, 2) }}</td>
                            <td>{{ $booking->created_at->format('M d, Y') }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center text-muted">{{ __('No recent bookings.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0">{{ __('Transaction History') }}</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{{ __('Date') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Amount') }}</th>
                        <th>{{ __('Method') }}</th>
                        <th>{{ __('Admin') }}</th>
                        <th>{{ __('Proof') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $transaction)
                        <tr>
                            <td>{{ $transaction->created_at->format('M d, Y') }}</td>
                            <td>
                                <span class="badge bg-{{ $transaction->type === 'earning' ? 'success' : 'warning' }}">
                                    {{ __(strtolower($transaction->type)) }}
                                </span>
                            </td>
                            <td class="{{ $transaction->amount >= 0 ? 'text-success' : 'text-danger' }}">
                                {{ $transaction->amount >= 0 ? '+' : '-' }}${{ number_format(abs($transaction->amount), 2) }}
                            </td>
                            <td>{{ $transaction->payment_method ?? __('N/A') }}</td>
                            <td>{{ $transaction->admin?->name ?? __('System') }}</td>
                            <td>
                                @if($transaction->proof_image)
                                    <a href="{{ asset('storage/' . $transaction->proof_image) }}" target="_blank">{{ __('View') }}</a>
                                @else
                                    <span class="text-muted">{{ __('N/A') }}</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted">{{ __('No transactions yet.') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="payoutModal" tabindex="-1" aria-labelledby="payoutModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.agencies.payout', $agency->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="payoutModalLabel">{{ __('Make Payout') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="amount" class="form-label">{{ __('Amount') }}</label>
                        <input type="number" step="0.01" min="1" max="{{ $currentBalance }}" class="form-control" id="amount" name="amount" required>
                        <small class="text-muted">{{ __('Max') }}: ${{ number_format($currentBalance, 2) }}</small>
                    </div>
                    <div class="mb-3">
                        <label for="payment_method" class="form-label">{{ __('Payment Method') }}</label>
                        <input type="text" class="form-control" id="payment_method" name="payment_method" placeholder="{{ __('InstaPay, PayPal, Bank Transfer') }}" required>
                    </div>
                    <div class="mb-3">
                        <label for="proof_image" class="form-label">{{ __('Proof of Payment') }}</label>
                        <input type="file" class="form-control" id="proof_image" name="proof_image" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">{{ __('Description (optional)') }}</label>
                        <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                    <button type="submit" class="btn btn-success" onclick="return confirm('{{ __('Are you sure you want to payout :amount to this agency? This action cannot be undone.', ['amount' => '$']) }}' + document.getElementById('amount').value)">{{ __('Submit Payout') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
