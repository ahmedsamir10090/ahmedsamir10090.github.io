@extends('layouts.admin')

@section('title', __('Manage Agencies'))
@section('header', __('Manage Agencies'))

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
    <div>
        <h4 class="mb-0">{{ __('Agencies') }}</h4>
        <small class="text-muted">{{ __('Manage travel agencies and their status') }}</small>
    </div>
    <div>
        <a href="{{ route('admin.agencies.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>{{ __('Add New Agency') }}
        </a>
    </div>
</div>

<!-- Success Message -->
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<!-- Agencies Table -->
<div class="card shadow">
    <div class="card-body">
        @if($agencies->count() > 0)
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>{{ __('ID') }}</th>
                            <th>{{ __('Logo') }}</th>
                            <th>{{ __('Name') }}</th>
                            <th>{{ __('License Number') }}</th>
                            <th>{{ __('Manager Email') }}</th>
                            <th>{{ __('Status') }}</th>
                            <th>{{ __('Balance') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($agencies as $agency)
                            <tr>
                                <td>{{ $agency->id }}</td>
                                <td>
                                    @if($agency->logo)
                                        <img src="{{ asset('storage/' . $agency->logo) }}" alt="{{ $agency->name }}" 
                                             class="rounded-circle" width="40" height="40">
                                    @else
                                        <div class="rounded-circle bg-secondary d-inline-flex align-items-center justify-content-center" 
                                             style="width: 40px; height: 40px;">
                                            <i class="fas fa-building text-white"></i>      
                                        </div>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('admin.agencies.show', $agency->id) }}" class="text-primary fw-bold text-decoration-none">
                                        {{ $agency->name }}
                                    </a>
                                </td>
                                <td>{{ $agency->license_number ?: __('N/A') }}</td>
                                <td>
                                    @if($agency->users->first())
                                        {{ $agency->users->first()->email }}
                                    @else
                                        <span class="text-muted">{{ __('No manager assigned') }}</span>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge bg-{{ $agency->status === 'active' ? 'success' : 'danger' }}">
                                        {{ __(strtolower($agency->status)) }}
                                    </span>
                                </td>
                                <td>${{ number_format($agency->current_balance, 2) }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <!-- Toggle Status Button -->
                                        <form action="{{ route('admin.agencies.updateStatus', $agency->id) }}" 
                                              method="POST" class="d-inline">
                                            @csrf
                                            <button type="submit" 
                                                    class="btn btn-sm btn-{{ $agency->status === 'active' ? 'warning' : 'success' }}"
                                                    onclick="return confirm('{{ __('Are you sure you want to :action this agency?', ['action' => $agency->status === 'active' ? __('suspend') : __('activate')]) }}')">
                                                <i class="fas fa-{{ $agency->status === 'active' ? 'pause' : 'play' }}"></i>    {{ $agency->status === 'active' ? __('Suspend') : __('Activate') }}
                                            </button>
                                        </form>
                                        
                                        <!-- Edit Button -->
                                        <a href="{{ route('admin.agencies.edit', $agency->id) }}" 
                                           class="btn btn-sm btn-info">
                                            <i class="fas fa-edit"></i> {{ __('Edit') }}
                                        </a>
                                        
                                        <!-- Delete Button -->
                                        <form action="{{ route('admin.agencies.destroy', $agency->id) }}" 
                                              method="POST" class="d-inline"
                                              onsubmit="return confirm('{{ __('Are you sure you want to delete this agency? This action cannot be undone.') }}')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>    {{ __('Delete') }}
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                {{ $agencies->links() }}
            </div>
        @else
            <div class="text-center py-5">
                <i class="fas fa-building fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">{{ __('No agencies found') }}</h5>
                <p class="text-muted">{{ __('Get started by creating your first agency.') }}</p>
                <a href="{{ route('admin.agencies.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>{{ __('Add New Agency') }}
                </a>
            </div>
        @endif
    </div>
</div>
@endsection

@push('styles')
<style>
    .table th {
        border-top: none;
        font-weight: 600;
        color: #5a5c69;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .btn-group form {
        display: inline-block;
    }
    
    .rounded-circle {
        object-fit: cover;
    }
</style>
@endpush
