@extends('layouts.admin')

@section('title', 'المدفوعات المعلقة')
@section('header', 'المدفوعات المعلقة للتحقق')

@section('content')
<div class="card shadow">
    <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="fas fa-hourglass-half me-2"></i>
            إيصالات الدفع في انتظار المراجعة
        </h5>
        <span class="badge bg-dark">{{ $bookings->total() }} حجز</span>
    </div>
    <div class="card-body">
        @if($bookings->count() > 0)
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>العميل</th>
                            <th>نوع الخدمة</th>
                            <th>المبلغ</th>
                            <th>الإيصال</th>
                            <th>تاريخ الحجز</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($bookings as $booking)
                            <tr>
                                <td>
                                    <a href="{{ route('admin.bookings.show', $booking->id) }}" class="fw-bold">
                                        #{{ $booking->id }}
                                    </a>
                                </td>
                                <td>
                                    <div>
                                        <strong>{{ $booking->user->name ?? 'غير معروف' }}</strong>
                                    </div>
                                    <small class="text-muted">{{ $booking->user->email ?? '' }}</small>
                                </td>
                                <td>
                                    @if($booking->serviceable_type === \App\Models\Flight::class)
                                        @php
                                            $flightType = $booking->serviceable->flight_type ?? 'air';
                                        @endphp
                                        @if($flightType === 'sea')
                                            <span class="badge bg-primary"><i class="fas fa-ship me-1"></i>رحلة بحرية</span>
                                        @else
                                            <span class="badge bg-info"><i class="fas fa-plane me-1"></i>رحلة طيران</span>
                                        @endif
                                    @else
                                        <span class="badge bg-warning"><i class="fas fa-box me-1"></i>شحن</span>
                                    @endif
                                </td>
                                <td>
                                    <span class="fw-bold text-primary">${{ number_format($booking->total_price, 2) }}</span>
                                </td>
                                <td>
                                    @if($booking->payment_proof_image)
                                        <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" 
                                           target="_blank" 
                                           class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-image me-1"></i>عرض
                                        </a>
                                    @else
                                        <span class="text-muted">لا يوجد</span>
                                    @endif
                                </td>
                                <td>
                                    <small>{{ $booking->created_at->format('Y-m-d') }}</small>
                                    <br>
                                    <small class="text-muted">{{ $booking->created_at->diffForHumans() }}</small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="{{ route('admin.bookings.show', $booking->id) }}" 
                                           class="btn btn-info" 
                                           title="عرض التفاصيل">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="{{ route('admin.bookings.approve-payment', $booking->id) }}" 
                                              method="POST" 
                                              class="d-inline">
                                            @csrf
                                            <button type="submit" 
                                                    class="btn btn-success" 
                                                    title="قبول"
                                                    onclick="return confirm('هل أنت متأكد من الموافقة على الدفع؟')">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                        <button type="button" 
                                                class="btn btn-danger" 
                                                title="رفض"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#rejectModal{{ $booking->id }}">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <!-- Reject Modal for each booking -->
                            <div class="modal fade" id="rejectModal{{ $booking->id }}" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">رفض إيصال الحجز #{{ $booking->id }}</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form action="{{ route('admin.bookings.reject-payment', $booking->id) }}" method="POST">
                                            @csrf
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">سبب الرفض <span class="text-danger">*</span></label>
                                                    <textarea class="form-control" 
                                                              name="rejection_reason" 
                                                              rows="3" 
                                                              required
                                                              placeholder="مثال: الإيصال غير واضح، المبلغ غير صحيح..."></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fas fa-times me-1"></i>رفض وإرسال إشعار
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex justify-content-center mt-3">
                {{ $bookings->links() }}
            </div>
        @else
            <div class="text-center py-5">
                <i class="fas fa-check-circle text-success fa-4x mb-3"></i>
                <h5 class="text-muted">لا توجد إيصالات معلقة للمراجعة</h5>
                <p class="text-muted">جميع المدفوعات تمت مراجعتها</p>
            </div>
        @endif
    </div>
</div>
@endsection
