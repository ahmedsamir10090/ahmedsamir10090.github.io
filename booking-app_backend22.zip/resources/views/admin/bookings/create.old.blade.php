@extends('layouts.admin')

@section('title', __('Create Booking'))
@section('header', __('Create Booking'))

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Create Booking') }}</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.bookings.store') }}" method="POST" id="booking-form">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="user_id">{{ __('Customer') }}</label>
                            <select class="form-select select @error('user_id') is-invalid @enderror" id="user_id" name="user_id" required>
                                <option value="" disabled selected hidden>{{ __('Select customer') }}</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                                        {{ $user->name }} ({{ $user->email }})
                                    </option>
                                @endforeach
                            </select>
                            @error('user_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
<div class="col-md-6 mb-3">
    <label class="form-label" for="agency_id">{{ __('Agency') }}</label>
    <select class="form-select select @error('agency_id') is-invalid @enderror" id="agency_id" name="agency_id" required>
        
        {{-- التعديل تم هنا: أضفنا disabled selected hidden --}}
        <option value="" disabled selected hidden>{{ __('Select agency') }}</option>

        @foreach($agencies as $agency)
            <option value="{{ $agency->id }}" {{ old('agency_id') == $agency->id ? 'selected' : '' }}>
                {{ $agency->name }}
            </option>
        @endforeach
    </select>
    @error('agency_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
</div>

                    </div>

                    <div class="mb-3">
                        <label class="form-label d-block">{{ __('Service Type') }}</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="service_type" id="service_type_flight" value="flight"
                                   {{ old('service_type') === 'flight' ? 'checked' : '' }}>
                            <label class="form-check-label" for="service_type_flight">{{ __('Flight') }}</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="service_type" id="service_type_cargo" value="cargo"
                                   {{ old('service_type') === 'cargo' ? 'checked' : '' }}>
                            <label class="form-check-label" for="service_type_cargo">{{ __('Cargo') }}</label>
                        </div>
                        @error('service_type')<div class="text-danger small">{{ $message }}</div>@enderror
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="service_id">{{ __('Service') }}</label>
                            <select class="form-select select @error('service_id') is-invalid @enderror" id="service_id" name="service_id" required>
                                <option value="" disabled selected hidden>{{ __('Select service') }}</option>
                            </select>
                            @error('service_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            <small id="price-info" class="text-muted"></small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="total_price">{{ __('Total Price') }}</label>
                            <input type="number" step="0.01" class="form-control @error('total_price') is-invalid @enderror" id="total_price" name="total_price" value="{{ old('total_price') }}" required readonly>
                            @error('total_price')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            <small class="text-muted">{{ __('Auto-filled based on selected service.') }}</small>
                        </div>
                    </div>

                    <div class="row d-none" id="seats-group">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="seats_count">{{ __('Seats Count') }}</label>
                            <input type="number" min="1" class="form-control @error('seats_count') is-invalid @enderror" id="seats_count" name="seats_count" value="{{ old('seats_count') ?? 1 }}">
                            @error('seats_count')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            <small class="text-muted">{{ __('Number of seats to book.') }}</small>
                        </div>
                    </div>

                    <div class="row d-none" id="weight-group">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="weight">{{ __('Weight (Kg)') }}</label>
                            <input type="number" step="0.01" min="0" class="form-control @error('weight') is-invalid @enderror" id="weight" name="weight" value="{{ old('weight') }}">
                            @error('weight')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="status">{{ __('Status') }}</label>
                            <select class="form-select @error('status') is-invalid @enderror" id="status" name="status" required>
                                <option value="pending" {{ old('status') === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                <option value="accepted" {{ old('status') === 'accepted' ? 'selected' : '' }}>{{ __('Accepted') }}</option>
                                <option value="rejected" {{ old('status') === 'rejected' ? 'selected' : '' }}>{{ __('Rejected') }}</option>
                                <option value="completed" {{ old('status') === 'completed' ? 'selected' : '' }}>{{ __('Completed') }}</option>
                                <option value="cancelled" {{ old('status') === 'cancelled' ? 'selected' : '' }}>{{ __('Cancelled') }}</option>
                            </select>
                            @error('status')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="payment_method">{{ __('Payment Method') }}</label>
                            <select class="form-select @error('payment_method') is-invalid @enderror" id="payment_method" name="payment_method" required>
                                <option value="wallet" {{ old('payment_method') === 'wallet' ? 'selected' : '' }}>{{ __('Wallet') }}</option>
                                <option value="stripe" {{ old('payment_method') === 'stripe' ? 'selected' : '' }}>{{ __('Stripe') }}</option>
                                <option value="manual_receipt" {{ old('payment_method') === 'manual_receipt' ? 'selected' : '' }}>{{ __('Manual Receipt') }}</option>
                            </select>
                            @error('payment_method')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Bookings') }}
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>{{ __('Create Booking') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container .select2-selection--single {
        height: 38px;
        padding: 4px 10px;
        border: 1px solid #ced4da;
        border-radius: 0.375rem;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 36px;
    }
</style>
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(function () {
        $('.select2').select2({ width: '100%' });

        const $agency = $('#agency_id');
        const $serviceType = $('input[name="service_type"]');
        const $serviceSelect = $('#service_id');
        const $price = $('#total_price');
        const $weightGroup = $('#weight-group');
        const $weight = $('#weight');
        const $seatsGroup = $('#seats-group');
        const $seatsCount = $('#seats_count');
        const $priceInfo = $('#price-info');

        let selectedPricePerKg = null;
        let selectedMinWeight = null;
        let selectedFlightPrice = null;

        const texts = {
            selectService: @json(__('Select service')),
            pricePerKg: @json(__('Price per Kg')),
            minWeight: @json(__('Min Weight')),
            kg: @json(__('kg'))
        };

        function resetServices() {
            $serviceSelect.empty().append(new Option(texts.selectService, ''));
            $serviceSelect.val('').trigger('change');
            $price.val('');
            $priceInfo.text('');
            $weight.val('');
            $seatsCount.val(1);
            selectedPricePerKg = null;
            selectedMinWeight = null;
            selectedFlightPrice = null;
        }

        function loadServices() {
            const agencyId = $agency.val();
            const type = $serviceType.filter(':checked').val();

            if (!agencyId || !type) {
                resetServices();
                $weightGroup.addClass('d-none');
                $seatsGroup.addClass('d-none');
                return;
            }

            resetServices();
            $serviceSelect.prop('disabled', true);
            if (type === 'cargo') {
                $weightGroup.removeClass('d-none');
                $seatsGroup.addClass('d-none');
            } else {
                $weightGroup.addClass('d-none');
                $seatsGroup.removeClass('d-none');
            }

            $.get("{{ route('admin.bookings.services', ['agencyId' => '__AGENCY__', 'type' => '__TYPE__']) }}"
                .replace('__AGENCY__', agencyId)
                .replace('__TYPE__', type)
            ).done(function (services) {
                services.forEach(function (service) {
                    const option = new Option(service.label, service.id, false, false);
                    $(option).attr('data-price', service.price);
                    if (service.price_per_kg !== undefined) {
                        $(option).attr('data-price-per-kg', service.price_per_kg);
                        $(option).attr('data-min-weight', service.min_weight);
                    }
                    $serviceSelect.append(option);
                });
                $serviceSelect.prop('disabled', false).trigger('change');
            }).fail(function () {
                $serviceSelect.prop('disabled', false);
            });
        }

        $agency.on('change', loadServices);
        $serviceType.on('change', loadServices);

        $serviceSelect.on('change', function () {
            const selected = $(this).find('option:selected');
            const type = $serviceType.filter(':checked').val();

            if (type === 'cargo') {
                selectedPricePerKg = parseFloat(selected.data('price-per-kg')) || null;
                selectedMinWeight = parseFloat(selected.data('min-weight')) || null;

                if (selectedPricePerKg !== null) {
                    $priceInfo.text(`${texts.pricePerKg}: $${selectedPricePerKg} | ${texts.minWeight}: ${selectedMinWeight ?? 0} ${texts.kg}`);
                    $weight.attr('min', selectedMinWeight ?? 0);
                } else {
                    $priceInfo.text('');
                }

                $price.val('');
                if ($weight.val()) {
                    $weight.trigger('input');
                }
            } else {
                selectedFlightPrice = parseFloat(selected.data('price')) || null;
                if (selectedFlightPrice !== null) {
                    updateFlightPrice();
                }
                $priceInfo.text('');
            }
        });

        $seatsCount.on('input', updateFlightPrice);

        function updateFlightPrice() {
            const seats = parseInt($seatsCount.val()) || 1;
            if (selectedFlightPrice !== null) {
                const total = seats * selectedFlightPrice;
                $price.val(total.toFixed(2));
            }
        }

        $weight.on('input', function () {
            const weightValue = parseFloat($(this).val());
            if (!selectedPricePerKg || isNaN(weightValue)) {
                $price.val('');
                return;
            }

            const total = weightValue * selectedPricePerKg;
            $price.val(total.toFixed(2));
        });

        $weightGroup.addClass('d-none');
        $seatsGroup.addClass('d-none');
        loadServices();
    });
</script>
@endpush
