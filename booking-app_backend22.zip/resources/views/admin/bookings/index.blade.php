@extends('layouts.admin')

@section('title', __('Manage Bookings'))
@section('header', __('Manage Bookings'))

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0">{{ __('Bookings') }}</h5>
        <small class="text-muted">{{ __('Manage customer bookings') }}</small>
    </div>
    <div>
        <a href="{{ route('admin.cargo.bookings.create') }}" class="btn btn-success me-2">
            <i class="fas fa-box me-2"></i>{{ __('Book Cargo Shipment') }}
        </a>
        <a href="{{ route('admin.bookings.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>حجز رحلة
        </a>
    </div>
</div>
<!-- Success/Error Messages -->
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    {{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<!-- Bookings Table -->
<div class="card shadow">
    <div class="card-body">
        @if($bookings->count() > 0)
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>{{ __('ID') }}</th>
                            <th>{{ __('User') }}</th>
                            <th>{{ __('Agency') }}</th>
                            <th>{{ __('Type') }}</th>
                            <th>{{ __('Details') }}</th>
                            <th>{{ __('Price') }}</th>
                            <th>{{ __('Payment Method') }}</th>
                            <th>{{ __('Status') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($bookings as $booking)
                            <tr>
                                <td>{{ $booking->id }}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center me-2" 
                                             style="width: 32px; height: 32px; font-size: 12px;">
                                            {{ strtoupper(substr($booking->user->name ?? 'U', 0, 1)) }}
                                        </div>
                                        <div>
                                            <div class="fw-bold">{{ $booking->user->name ?? __('N/A') }}</div>
                                            <small class="text-muted">{{ $booking->user->email ?? __('N/A') }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                    @if($booking->agency)
                                        @if($booking->agency->logo)
                                            <img src="{{ asset('storage/' . $booking->agency->logo) }}" alt="{{ $booking->agency->name }}" 
                                                 class="rounded-circle" width="40" height="40">
                                        @else
                                            <div class="rounded-circle bg-secondary d-inline-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="fas fa-building text-white"></i>
                                            </div>
                                        @endif
                                        <div class="ms-2">
                                            <div class="fw-bold">{{ $booking->agency->name }}</div>
                                        </div>
                                    @else
                                        <div class="text-muted">
                                            <i class="fas fa-minus-circle me-1"></i>غير محدد
                                        </div>
                                    @endif
                                    </div>
                                </td>
                                <td>
                                    @php
                                        if ($booking->serviceable_type === \App\Models\Flight::class) {
                                            $flightType = $booking->serviceable->flight_type ?? 'air';
                                            $typeLabel = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
                                            $badgeColor = $flightType === 'sea' ? 'bg-primary' : 'bg-info';
                                        } else {
                                            $typeLabel = __('Cargo Service');
                                            $badgeColor = 'bg-warning';
                                        }
                                    @endphp
                                    <span class="badge {{ $badgeColor }}">
                                        {{ $typeLabel }}
                                    </span>
                                </td>
                                <td>
                                    @if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->serviceable)
                                        @php
                                            $flight = $booking->serviceable;
                                            $flightType = $flight->flight_type ?? 'air';
                                        @endphp
                                        <div>
                                            <strong>{{ $flight->flight_number ?? __('N/A') }}</strong>
                                            @if($flightType === 'sea')
                                                <span class="badge bg-primary bg-opacity-25 text-primary">بحري</span>
                                            @else
                                                <span class="badge bg-info bg-opacity-25 text-info">جوي</span>
                                            @endif
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i>
                                                {{ $flight->origin ?? __('N/A') }} &rarr; {{ $flight->destination ?? __('N/A') }}
                                            </small>
                                        </div>
                                    @elseif($booking->serviceable_type === 'App\\Models\\CargoService' && $booking->serviceable)
                                        @php
                                            $cargo = $booking->serviceable;
                                        @endphp
                                        <div>
                                            <strong>{{ __('Cargo Service') }} #{{ $cargo->id }}</strong><br>
                                            <small class="text-muted">
                                                <i class="fas fa-box me-1"></i>
                                                {{ $cargo->route_from ?? __('N/A') }} &rarr; {{ $cargo->route_to ?? __('N/A') }}
                                            </small><br>
                                            <small class="text-muted">
                                                <i class="fas fa-weight me-1"></i>
                                                الوزن: {{ $booking->weight ?? 0 }} كجم
                                            </small>
                                        </div>
                                    @else
                                        <span class="text-muted">{{ __('N/A') }}</span>
                                    @endif
                                </td>
                                <td>
                                    <strong>${{ number_format($booking->total_price, 2) }}</strong>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        {{ __(strtolower(str_replace('_', ' ', $booking->payment_method))) }}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-{{ 
                                        $booking->status === 'completed' ? 'success' : 
                                        ($booking->status === 'paid' ? 'info' : 
                                        ($booking->status === 'pending' ? 'warning' : 'danger')) 
                                    }}">
                                        {{ __(strtolower($booking->status)) }}
                                    </span>
                                    @if($booking->rejection_reason)
                                        <i class="fas fa-info-circle text-danger ms-1" 
                                           data-bs-toggle="tooltip" 
                                           title="{{ $booking->rejection_reason }}"></i>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <!-- Edit Button -->
                                        {{-- <a href="{{ route('admin.bookings.edit', $booking->id) }}" 
                                           class="btn btn-sm btn-outline-warning" title="{{ __('Edit Booking') }}">
                                            <i class="fas fa-edit"></i>
                                        </a> --}}
<a href="{{ route('admin.bookings.edit', $booking->id) }}" 
   class="btn btn-sm btn-outline-warning" 
   title="{{ __('Edit Booking') }}">
    
    {{-- الحل: أضف الأيقونة والنص هنا --}}
    <i class="fas fa-edit"></i> {{ __('Edit') }}

</a>
                                    
                                        
<a href="{{ route('admin.bookings.show', $booking->id) }}" 
                                           class="btn btn-sm btn-outline-primary" title="{{ __('View Details') }}">

    
    {{-- الحل: أضف الأيقونة والنص هنا --}}
        <i class="fas fa-eye"></i> {{ __('View Details') }}

</a>

                                        <!-- Cargo Tracking Button -->
                                        @if($booking->serviceable_type === \App\Models\CargoService::class)
                                            <a href="{{ route('admin.cargo.bookings.tracking', $booking->id) }}" 
                                               class="btn btn-sm btn-outline-info" title="{{ __('View Tracking') }}">
                                                <i class="fas fa-map-marker-alt"></i> {{ __('View Tracking') }}
                                            </a>
                                        @endif

                                        @if($booking->status === 'pending')
                                            <!-- Accept Button -->
                                            <form action="{{ route('admin.bookings.accept', $booking->id) }}" 
                                                  method="POST" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-success" 
                                                        onclick="return confirm('{{ __('Are you sure you want to accept this booking?') }}')"
                                                        title="{{ __('Accept Booking') }}">
                                                    <i class="fas fa-check"></i>{{ __('Accept Booking') }}
                                                </button>
                                            </form>
                                            
                                            <!-- Reject Button (Triggers Modal) -->
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#rejectModal{{ $booking->id }}"
                                                    title="{{ __('Reject Booking') }}">
                                                <i class="fas fa-times"></i>    {{ __('Reject Booking') }}
                                            </button>
                                        @endif
                                        
                                        @if($booking->status === 'cancelled' || $booking->status === 'pending')
                                            <!-- Delete Button -->
                                            <form action="{{ route('admin.bookings.destroy', $booking->id) }}" 
                                                  method="POST" class="d-inline"
                                                  onsubmit="return confirm('{{ __('Are you sure you want to delete this booking?') }}')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                        title="{{ __('Delete Booking') }}">
                                                    <i class="fas fa-trash"></i>    {{ __('Delete Booking') }}
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                {{ $bookings->links() }}
            </div>
        @else
            <div class="text-center py-5">
                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">{{ __('No bookings found') }}</h5>
                <p class="text-muted">{{ __('When users make bookings, they will appear here.') }}</p>
            </div>
        @endif
    </div>
</div>

<!-- Reject Modals -->
@foreach($bookings as $booking)
    @if($booking->status === 'pending')
        <div class="modal fade" id="rejectModal{{ $booking->id }}" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ __('Reject Booking') }} #{{ $booking->id }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form action="{{ route('admin.bookings.reject', $booking->id) }}" method="POST">
                        @csrf
                        <div class="modal-body">
                            @php
                                $typeLabel = $booking->serviceable_type === \App\Models\Flight::class
                                    ? __('Flight')
                                    : __('Cargo Service');
                            @endphp
                            <div class="mb-3">
                                <label for="rejection_reason{{ $booking->id }}" class="form-label">
                                    {{ __('Rejection Reason') }} <span class="text-danger">*</span>
                                </label>
                                <textarea class="form-control" 
                                          id="rejection_reason{{ $booking->id }}" 
                                          name="rejection_reason" 
                                          rows="4" 
                                          placeholder="{{ __('Please provide a reason for rejecting this booking...') }}"
                                          required></textarea>
                                <small class="form-text text-muted">
                                    {{ __('This reason will be visible to the customer.') }}
                                </small>
                            </div>
                            
                            <!-- Booking Summary -->
                            <div class="alert alert-light">
                                <h6 class="mb-2">{{ __('Booking Details') }}:</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>{{ __('User') }}:</strong> {{ $booking->user->name ?? __('N/A') }}<br>
                                        <strong>{{ __('Agency') }}:</strong> {{ $booking->agency->name ?? __('N/A') }}
                                    </div>
                                    <div class="col-md-6">
                                        <strong>{{ __('Amount') }}:</strong> ${{ number_format($booking->total_price, 2) }}<br>
                                        <strong>{{ __('Type') }}:</strong> {{ $typeLabel }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                {{ __('Cancel') }}
                            </button>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-times me-2"></i>{{ __('Reject Booking') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif
@endforeach
@endsection

@push('styles')
<style>
    .table th {
        border-top: none;
        font-weight: 600;
        color: #5a5c69;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .btn-group form {
        display: inline-block;
    }
    
    .rounded-circle {
        object-fit: cover;
    }
</style>
@endpush

@push('scripts')
<script>
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
</script>
@endpush
