@extends('layouts.admin')

@section('title', __('Edit Booking'))

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">{{ __('Edit Booking') }}</h1>
                <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> {{ __('Back to Bookings') }}
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">{{ __('Edit Booking Details') }}</h5>
                </div>
                <div class="card-body">
                    @if($booking->status === 'completed')
                        <div class="alert alert-warning d-flex align-items-center" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <div>
                                {{ __('This booking is marked as Completed and earnings have been transferred to the Agency. Status cannot be changed to prevent financial discrepancies.') }}
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('admin.bookings.update', $booking->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="user_id" class="form-label">{{ __('Customer') }}</label>
                                <select name="user_id" id="user_id" class="form-select" required disabled>
                                    <option value="">{{ __('Select customer') }}</option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->id }}" {{ $booking->user_id == $user->id ? 'selected' : '' }}>
                                            {{ $user->name }} ({{ $user->email }})
                                        </option>
                                    @endforeach
                                </select>
                                <div class="form-text">{{ __('Customer cannot be changed after booking creation.') }}</div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="agency_id" class="form-label">{{ __('Agency') }}</label>
                                <select name="agency_id" id="agency_id" class="form-select" required disabled>
                                    <option value="">{{ __('Select agency') }}</option>
                                    @foreach($agencies as $agency)
                                        <option value="{{ $agency->id }}" {{ $booking->agency_id == $agency->id ? 'selected' : '' }}>
                                            {{ $agency->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="form-text">{{ __('Agency cannot be changed after booking creation.') }}</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="service_type" class="form-label">{{ __('Service Type') }}</label>
                                <select name="service_type" id="service_type" class="form-select" required disabled>
                                    <option value="">{{ __('Select service type') }}</option>
                                    <option value="flight" {{ $booking->serviceable_type === 'App\\Models\\Flight' ? 'selected' : '' }}>{{ __('Flight') }}</option>
                                    <option value="cargo" {{ $booking->serviceable_type === 'App\\Models\\CargoService' ? 'selected' : '' }}>{{ __('Cargo') }}</option>
                                </select>
                                <div class="form-text">{{ __('Service type cannot be changed after booking creation.') }}</div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="serviceable_id" class="form-label">{{ __('Service') }}</label>
                                <select name="serviceable_id" id="serviceable_id" class="form-select" required disabled>
                                    <option value="">{{ __('Select service') }}</option>
                                </select>
                                <div class="form-text">{{ __('Service cannot be changed after booking creation.') }}</div>
                            </div>
                        </div>

                        @if($booking->serviceable_type === 'App\\Models\\CargoService')
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="weight" class="form-label">{{ __('Weight (Kg)') }}</label>
                                    <input type="number" step="0.01" min="0" name="weight" id="weight" class="form-control" value="{{ $booking->weight ?? '' }}" readonly>
                                    <div class="form-text">{{ __('Weight cannot be changed after booking creation.') }}</div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="price_info" class="form-label">{{ __('Price Information') }}</label>
                                    <input type="text" id="price_info" class="form-control" readonly>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="total_price" class="form-label">{{ __('Total Price') }}</label>
                                <input type="number" step="0.01" min="0" name="total_price" id="total_price" class="form-control" value="{{ $booking->total_price }}" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="seats_count" class="form-label">{{ __('Seats Count') }}</label>
                                <input type="number" min="1" name="seats_count" id="seats_count" class="form-control" value="{{ $booking->seats_count ?? 1 }}" @if($booking->serviceable_type !== 'App\\Models\\Flight') readonly @endif>
                                @if($booking->serviceable_type !== 'App\\Models\\Flight')
                                    <div class="form-text">{{ __('Seats count only applies to flight bookings.') }}</div>
                                @endif
                            </div>
                        </div>

                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">{{ __('Status') }}</label>
                                @if($booking->status === 'completed')
                                    <input type="hidden" name="status" value="completed">
                                    <select name="status_disabled" id="status" class="form-select" disabled>
                                        <option value="pending" {{ $booking->status === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                        <option value="accepted" {{ $booking->status === 'accepted' ? 'selected' : '' }}>{{ __('Accepted') }}</option>
                                        <option value="rejected" {{ $booking->status === 'rejected' ? 'selected' : '' }}>{{ __('Rejected') }}</option>
                                        <option value="completed" {{ $booking->status === 'completed' ? 'selected' : '' }}>{{ __('Completed') }}</option>
                                        <option value="cancelled" {{ $booking->status === 'cancelled' ? 'selected' : '' }}>{{ __('Cancelled') }}</option>
                                    </select>
                                    <div class="form-text">{{ __('Status cannot be changed for completed bookings.') }}</div>
                                @else
                                    <select name="status" id="status" class="form-select" required>
                                        <option value="pending" {{ $booking->status === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                        <option value="accepted" {{ $booking->status === 'accepted' ? 'selected' : '' }}>{{ __('Accepted') }}</option>
                                        <option value="rejected" {{ $booking->status === 'rejected' ? 'selected' : '' }}>{{ __('Rejected') }}</option>
                                        <option value="completed" {{ $booking->status === 'completed' ? 'selected' : '' }}>{{ __('Completed') }}</option>
                                        <option value="cancelled" {{ $booking->status === 'cancelled' ? 'selected' : '' }}>{{ __('Cancelled') }}</option>
                                    </select>
                                @endif
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="payment_status" class="form-label">{{ __('Payment Status') }}</label>
                                <select name="payment_status" id="payment_status" class="form-select" required>
                                    <option value="pending" {{ $booking->payment_status === 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                    <option value="paid" {{ $booking->payment_status === 'paid' ? 'selected' : '' }}>{{ __('Paid') }}</option>
                                    <option value="failed" {{ $booking->payment_status === 'failed' ? 'selected' : '' }}>{{ __('Failed') }}</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="payment_method" class="form-label">{{ __('Payment Method') }}</label>
                                <select name="payment_method" id="payment_method" class="form-select">
                                    <option value="">{{ __('Select payment method') }}</option>
                                    <option value="wallet" {{ $booking->payment_method === 'wallet' ? 'selected' : '' }}>{{ __('Wallet') }}</option>
                                    <option value="stripe" {{ $booking->payment_method === 'stripe' ? 'selected' : '' }}>{{ __('Stripe') }}</option>
                                    <option value="manual_receipt" {{ $booking->payment_method === 'manual_receipt' ? 'selected' : '' }}>{{ __('Manual Receipt') }}</option>
                                </select>
                            </div>
                        </div>

                        @if($booking->payment_proof_image)
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label class="form-label">{{ __('Current Payment Proof') }}</label>
                                    <div>
                                        <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i> {{ __('View Proof') }}
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> {{ __('Update Booking') }}
                                </button>
                                <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> {{ __('Cancel') }}
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
    const texts = {
        selectService: @json(__('Select service')),
        to: @json(__('to')),
        min: @json(__('Min')),
        kg: @json(__('kg'))
    };
    // Load services based on agency and service type
    function loadServices() {
        var agencyId = $('#agency_id').val();
        var serviceType = $('#service_type').val();
        
        if (!agencyId || !serviceType) {
            $('#serviceable_id').html('<option value="">' + texts.selectService + '</option>');
            return;
        }

        $.ajax({
            url: `{{ route('admin.bookings.services', ['agencyId' => ':agencyId', 'type' => ':type']) }}`.replace(':agencyId', agencyId).replace(':type', serviceType),
            method: 'GET',
            success: function(response) {
                var options = '<option value="">' + texts.selectService + '</option>';
                
                if (serviceType === 'flight') {
                    $.each(response.flights, function(index, flight) {
                        options += '<option value="' + flight.id + '">' + flight.flight_number + ' - ' + flight.origin + ' ' + texts.to + ' ' + flight.destination + ' ($' + flight.price + ')</option>';
                    });
                } else if (serviceType === 'cargo') {
                    $.each(response.cargo, function(index, cargo) {
                        options += '<option value="' + cargo.id + '">' + cargo.type + ' - ' + cargo.route_from + ' ' + texts.to + ' ' + cargo.route_to + ' ($' + cargo.price_per_kg + '/' + texts.kg + ', ' + texts.min + ': ' + cargo.min_weight + texts.kg + ')</option>';
                    });
                }
                
                $('#serviceable_id').html(options);
                
                // Set current service
                $('#serviceable_id').val('{{ $booking->serviceable_id }}');
                
                // Update price info for cargo
                if (serviceType === 'cargo') {
                    updatePriceInfo();
                }
            }
        });
    }

    // Update price information for cargo
    function updatePriceInfo() {
        var serviceId = $('#serviceable_id').val();
        var weight = parseFloat($('#weight').val()) || 0;
        
        if (!serviceId || !weight) {
            $('#price_info').val('');
            return;
        }

        $.ajax({
            url: `{{ route('admin.bookings.services', ['agencyId' => ':agencyId', 'type' => 'cargo']) }}`.replace(':agencyId', agencyId),
            method: 'GET',
            success: function(response) {
                var cargo = response.cargo.find(function(item) {
                    return item.id == serviceId;
                });
                
                if (cargo) {
                    var totalPrice = (weight * cargo.price_per_kg).toFixed(2);
                    $('#price_info').val(weight + ' ' + texts.kg + ' x $' + cargo.price_per_kg + '/' + texts.kg + ' = $' + totalPrice);
                    $('#total_price').val(totalPrice);
                }
            }
        });
    }

    // Initialize
    loadServices();
});
</script>
@endsection
