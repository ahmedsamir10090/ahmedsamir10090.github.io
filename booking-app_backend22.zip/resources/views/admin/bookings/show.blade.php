@extends('layouts.admin')

@section('title', __('Booking Details'))
@section('header', __('Booking Details') . ' #' . $booking->id)

@section('content')
@php
    if ($booking->serviceable_type === \App\Models\Flight::class) {
        $flightType = $booking->serviceable->flight_type ?? 'air';
        $typeLabel = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
    } else {
        $typeLabel = __('Cargo Service');
    }
@endphp
<div class="row">
    <div class="col-lg-8">
        <!-- Booking Details Card -->
        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-ticket-alt me-2"></i>{{ __('Booking Information') }}</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Booking ID') }}</label>
                        <p class="fw-bold">#{{ $booking->id }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Service Type') }}</label>
                        <p>
                            @if($booking->serviceable_type === \App\Models\Flight::class)
                                @php
                                    $flightType = $booking->serviceable->flight_type ?? 'air';
                                @endphp
                                @if($flightType === 'sea')
                                    <span class="badge bg-primary"><i class="fas fa-ship me-1"></i>رحلة بحرية</span>
                                @else
                                    <span class="badge bg-info"><i class="fas fa-plane me-1"></i>{{ __('Flight') }}</span>
                                @endif
                            @else
                                <span class="badge bg-warning"><i class="fas fa-box me-1"></i>{{ __('Cargo Service') }}</span>
                            @endif
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Status') }}</label>
                        <p>
                            <span class="badge bg-{{ 
                                $booking->status === 'completed' ? 'success' : 
                                ($booking->status === 'paid' ? 'info' : 
                                ($booking->status === 'pending' ? 'warning' : 'danger')) 
                            }}">
                                {{ __(strtolower($booking->status)) }}
                            </span>
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Total Price') }}</label>
                        <p class="fw-bold text-primary fs-4">${{ number_format($booking->total_price, 2) }}</p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Payment Method') }}</label>
                        <p>
                            @if($booking->payment_method === 'cash_on_delivery')
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-money-bill-wave me-1"></i>
                                    الدفع عند الاستلام
                                </span>
                            @elseif($booking->payment_method === 'manual_receipt')
                                <span class="badge bg-info">
                                    <i class="fas fa-receipt me-1"></i>
                                    إيصال تحويل بنكي
                                </span>
                            @elseif($booking->payment_method === 'wallet')
                                <span class="badge bg-success">
                                    <i class="fas fa-wallet me-1"></i>
                                    المحفظة
                                </span>
                            @elseif($booking->payment_method === 'stripe')
                                <span class="badge bg-primary">
                                    <i class="fab fa-stripe me-1"></i>
                                    Stripe
                                </span>
                            @else
                                <span class="badge bg-secondary">
                                    <i class="fas fa-credit-card me-1"></i>
                                    {{ $booking->payment_method ?? 'غير محدد' }}
                                </span>
                            @endif
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Payment Status') }}</label>
                        <p>
                            @if($booking->payment_status === 'paid')
                                <span class="badge bg-success">
                                    <i class="fas fa-check-circle me-1"></i>مدفوع
                                </span>
                            @elseif($booking->payment_status === 'pending_cod')
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-truck me-1"></i>في انتظار الدفع عند الاستلام
                                </span>
                            @elseif($booking->payment_status === 'pending_verification')
                                <span class="badge bg-info">
                                    <i class="fas fa-hourglass-half me-1"></i>في انتظار التحقق من الإيصال
                                </span>
                            @elseif($booking->payment_status === 'rejected')
                                <span class="badge bg-danger">
                                    <i class="fas fa-times-circle me-1"></i>مرفوض
                                </span>
                            @elseif($booking->payment_status === 'refunded')
                                <span class="badge bg-secondary">
                                    <i class="fas fa-undo me-1"></i>مسترد
                                </span>
                            @else
                                <span class="badge bg-danger">
                                    <i class="fas fa-clock me-1"></i>غير مدفوع
                                </span>
                            @endif
                        </p>
                    </div>
                    
                    @if($booking->serviceable_type === \App\Models\Flight::class)
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">عدد المقاعد</label>
                            <p><i class="fas fa-chair me-1"></i>{{ $booking->seats_count ?? 1 }} مقعد</p>
                        </div>
                        @if($booking->selected_baggage_weight)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">الأمتعة المختارة</label>
                                <p><i class="fas fa-suitcase me-1"></i>{{ $booking->selected_baggage_weight }} كجم</p>
                            </div>
                        @endif
                    @endif
                    
                    @if($booking->serviceable_type === \App\Models\CargoService::class && $booking->weight)
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">وزن الشحنة</label>
                            <p><i class="fas fa-weight me-1"></i>{{ $booking->weight }} كجم</p>
                        </div>
                    @endif
                    
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">{{ __('Created At') }}</label>
                        <p><i class="fas fa-calendar me-1"></i>{{ $booking->created_at->format('M d, Y H:i A') }}</p>
                    </div>
                </div>
                
                @if($booking->rejection_reason)
                    <div class="alert alert-danger">
                        <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>{{ __('Rejection Reason') }}</h6>
                        <p class="mb-0">{{ $booking->rejection_reason }}</p>
                    </div>
                @endif
            </div>
        </div>

        <!-- Payment Management Card -->
        @if($booking->payment_method === 'cash_on_delivery' || $booking->payment_method === 'manual_receipt')
        <div class="card shadow mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="fas fa-credit-card me-2"></i>إدارة الدفع</h5>
            </div>
            <div class="card-body">
                {{-- Cash on Delivery Section --}}
                @if($booking->payment_method === 'cash_on_delivery')
                    <div class="alert alert-info mb-4">
                        <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i>الدفع عند الاستلام</h6>
                        <p class="mb-0">العميل اختار الدفع نقداً عند استلام التذكرة/الخدمة.</p>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="text-muted small">حالة الدفع الحالية</label>
                            <p>
                                @if($booking->payment_status === 'paid')
                                    <span class="badge bg-success fs-6"><i class="fas fa-check-circle me-1"></i>تم استلام المبلغ</span>
                                @elseif($booking->payment_status === 'pending_cod')
                                    <span class="badge bg-warning text-dark fs-6"><i class="fas fa-truck me-1"></i>في انتظار الاستلام والدفع</span>
                                @else
                                    <span class="badge bg-secondary fs-6">{{ $booking->payment_status }}</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">المبلغ المطلوب</label>
                            <p class="fw-bold text-primary fs-4">${{ number_format($booking->total_price, 2) }}</p>
                        </div>
                    </div>
                    
                    @if($booking->payment_status === 'pending_cod')
                        <hr>
                        <h6 class="mb-3"><i class="fas fa-check-double me-2"></i>تأكيد استلام المبلغ</h6>
                        <form action="{{ route('admin.bookings.approve-payment', $booking->id) }}" method="POST" class="d-inline">
                            @csrf
                            <button type="submit" class="btn btn-success" 
                                    onclick="return confirm('هل تم استلام المبلغ نقداً من العميل؟')">
                                <i class="fas fa-check me-2"></i>تأكيد استلام المبلغ
                            </button>
                        </form>
                        <small class="text-muted d-block mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            سيتم تغيير حالة الدفع إلى "مدفوع" وإرسال إشعار للعميل
                        </small>
                    @endif
                @endif

                {{-- Manual Receipt / Bank Transfer Section --}}
                @if($booking->payment_method === 'manual_receipt')
                    <div class="alert alert-info mb-4">
                        <h6 class="alert-heading"><i class="fas fa-university me-2"></i>تحويل بنكي</h6>
                        <p class="mb-0">العميل قام بتحويل المبلغ ورفع إيصال الدفع للمراجعة.</p>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="text-muted small">حالة التحقق من الدفع</label>
                            <p>
                                @if($booking->payment_status === 'paid')
                                    <span class="badge bg-success fs-6"><i class="fas fa-check-circle me-1"></i>تم التحقق والموافقة</span>
                                    @if($booking->payment_verified_at)
                                        <br><small class="text-muted">تم التحقق في: {{ $booking->payment_verified_at->format('Y-m-d H:i') }}</small>
                                    @endif
                                @elseif($booking->payment_status === 'pending_verification')
                                    <span class="badge bg-warning text-dark fs-6"><i class="fas fa-hourglass-half me-1"></i>في انتظار المراجعة</span>
                                @elseif($booking->payment_status === 'rejected')
                                    <span class="badge bg-danger fs-6"><i class="fas fa-times-circle me-1"></i>تم رفض الإيصال</span>
                                @else
                                    <span class="badge bg-secondary fs-6">{{ $booking->payment_status }}</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">المبلغ المطلوب</label>
                            <p class="fw-bold text-primary fs-4">${{ number_format($booking->total_price, 2) }}</p>
                        </div>
                    </div>

                    {{-- Payment Receipt Image --}}
                    @if($booking->payment_proof_image)
                        <div class="mb-4">
                            <label class="text-muted small d-block mb-2"><i class="fas fa-image me-1"></i>إيصال الدفع المرفق</label>
                            <div class="border rounded p-3 bg-light">
                                <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" target="_blank" class="d-block">
                                    <img src="{{ asset('storage/' . $booking->payment_proof_image) }}" 
                                         alt="إيصال الدفع" 
                                         class="img-fluid rounded shadow-sm" 
                                         style="max-height: 400px; cursor: pointer;">
                                </a>
                                <div class="mt-2">
                                    <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" 
                                       target="_blank" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-external-link-alt me-1"></i>فتح في نافذة جديدة
                                    </a>
                                    <a href="{{ asset('storage/' . $booking->payment_proof_image) }}" 
                                       download 
                                       class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-download me-1"></i>تحميل
                                    </a>
                                </div>
                            </div>
                        </div>
                    @else
                        <div class="alert alert-warning mb-4">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            لم يتم رفع إيصال الدفع بعد
                            
                            {{-- Admin can upload receipt manually --}}
                            @if($booking->payment_status !== 'paid')
                                <hr>
                                <form action="{{ route('admin.bookings.upload-receipt', $booking->id) }}" 
                                      method="POST" 
                                      enctype="multipart/form-data"
                                      class="mt-2">
                                    @csrf
                                    <label class="form-label fw-bold">رفع الإيصال يدوياً:</label>
                                    <div class="input-group">
                                        <input type="file" 
                                               class="form-control" 
                                               name="payment_proof_image" 
                                               accept="image/*" 
                                               required>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-upload me-1"></i>رفع
                                        </button>
                                    </div>
                                    <small class="text-muted">يمكنك رفع الإيصال هنا إذا استلمته من العميل بطريقة أخرى</small>
                                </form>
                            @endif
                        </div>
                    @endif

                    {{-- Payment Rejection Reason --}}
                    @if($booking->payment_status === 'rejected' && $booking->payment_rejection_reason)
                        <div class="alert alert-danger mb-4">
                            <h6 class="alert-heading"><i class="fas fa-ban me-2"></i>سبب رفض الإيصال</h6>
                            <p class="mb-0">{{ $booking->payment_rejection_reason }}</p>
                        </div>
                    @endif

                    {{-- Action Buttons for Pending Verification --}}
                    @if($booking->payment_status === 'pending_verification' && $booking->payment_proof_image)
                        <hr>
                        <h6 class="mb-3"><i class="fas fa-tasks me-2"></i>مراجعة إيصال الدفع</h6>
                        <div class="d-flex gap-2 flex-wrap">
                            <form action="{{ route('admin.bookings.approve-payment', $booking->id) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-success" 
                                        onclick="return confirm('هل أنت متأكد من الموافقة على إيصال الدفع؟ سيتم تأكيد الحجز وإرسال إشعار للعميل.')">
                                    <i class="fas fa-check-circle me-2"></i>قبول الإيصال وتأكيد الدفع
                                </button>
                            </form>
                            
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectPaymentModal">
                                <i class="fas fa-times-circle me-2"></i>رفض الإيصال
                            </button>
                        </div>
                        <small class="text-muted d-block mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            تأكد من صحة الإيصال والمبلغ المحول قبل الموافقة
                        </small>
                    @endif
                @endif
            </div>
        </div>
        @endif

        <!-- Service Details Card -->
        <div class="card shadow mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>{{ $typeLabel }} {{ __('Details') }}</h5>
            </div>
            <div class="card-body">
                @if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->serviceable)
                    @php
                        $flight = $booking->serviceable;
                        $flightType = $flight->flight_type ?? 'air';
                    @endphp
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الرحلة</label>
                            <p class="fw-bold fs-5">
                                {{ $flight->flight_number }}
                                @if($flightType === 'sea')
                                    <span class="badge bg-primary"><i class="fas fa-ship"></i> بحري</span>
                                @else
                                    <span class="badge bg-info"><i class="fas fa-plane"></i> جوي</span>
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">حالة الرحلة</label>
                            <p>
                                <span class="badge bg-{{ 
                                    $flight->status === 'active' ? 'success' : 
                                    ($flight->status === 'pending' ? 'warning' : 'danger') 
                                }}">
                                    {{ __(strtolower($flight->status)) }}
                                </span>
                            </p>
                        </div>
                        
                        <!-- Origin -->
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                @if($flightType === 'sea')
                                    <i class="fas fa-anchor me-1"></i>ميناء المغادرة
                                @else
                                    <i class="fas fa-plane-departure me-1"></i>{{ __('Origin Airport') }}
                                @endif
                            </label>
                            <p class="fw-bold">{{ $flight->origin ?? __('N/A') }}</p>
                            @if($flightType === 'sea' && $flight->originPort)
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    {{ $flight->originPort->city_ar ?? $flight->originPort->city_en ?? '' }}
                                    @if($flight->originPort->code)
                                        ({{ $flight->originPort->code }})
                                    @endif
                                </small>
                            @elseif($flight->originAirport)
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    {{ $flight->originAirport->city_ar ?? $flight->originAirport->city_en ?? '' }}
                                    @if($flight->originAirport->iata_code)
                                        ({{ $flight->originAirport->iata_code }})
                                    @endif
                                </small>
                            @endif
                        </div>
                        
                        <!-- Destination -->
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                @if($flightType === 'sea')
                                    <i class="fas fa-anchor me-1"></i>ميناء الوصول
                                @else
                                    <i class="fas fa-plane-arrival me-1"></i>{{ __('Destination Airport') }}
                                @endif
                            </label>
                            <p class="fw-bold">{{ $flight->destination ?? __('N/A') }}</p>
                            @if($flightType === 'sea' && $flight->destinationPort)
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    {{ $flight->destinationPort->city_ar ?? $flight->destinationPort->city_en ?? '' }}
                                    @if($flight->destinationPort->code)
                                        ({{ $flight->destinationPort->code }})
                                    @endif
                                </small>
                            @elseif($flight->destinationAirport)
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    {{ $flight->destinationAirport->city_ar ?? $flight->destinationAirport->city_en ?? '' }}
                                    @if($flight->destinationAirport->iata_code)
                                        ({{ $flight->destinationAirport->iata_code }})
                                    @endif
                                </small>
                            @endif
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i>{{ __('Departure') }}</label>
                            <p>{{ $flight->departure_time->format('M d, Y H:i A') }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i>{{ __('Arrival') }}</label>
                            <p>{{ $flight->arrival_time->format('M d, Y H:i A') }}</p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">مدة الرحلة</label>
                            <p>
                                @php
                                    $duration = $flight->departure_time->diff($flight->arrival_time);
                                    $hours = $duration->h + ($duration->days * 24);
                                @endphp
                                <i class="fas fa-clock me-1"></i>{{ $hours }} ساعة {{ $duration->i }} دقيقة
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">{{ __('Available Seats') }}</label>
                            <p><i class="fas fa-chair me-1"></i>{{ $flight->available_seats }}</p>
                        </div>
                        
                        @if($flight->adult_price)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">سعر البالغين</label>
                                <p class="text-success fw-bold">${{ number_format($flight->adult_price, 2) }}</p>
                            </div>
                        @endif
                        
                        @if($flight->child_price)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">سعر الأطفال</label>
                                <p class="text-success fw-bold">${{ number_format($flight->child_price, 2) }}</p>
                            </div>
                        @endif
                        
                        @if($flight->baggage_prices && is_array($flight->baggage_prices) && count($flight->baggage_prices) > 0)
                            <div class="col-12 mb-3">
                                <label class="text-muted small">أسعار الأمتعة</label>
                                <div class="d-flex gap-2 flex-wrap">
                                    @foreach($flight->baggage_prices as $weight => $price)
                                        <span class="badge bg-secondary">
                                            <i class="fas fa-suitcase me-1"></i>
                                            {{ $weight }} كجم: ${{ $price }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                        @endif
                    </div>
                    
                @elseif($booking->serviceable_type === 'App\\Models\\CargoService' && $booking->serviceable)
                    @php
                        $cargo = $booking->serviceable;
                    @endphp
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الشحنة</label>
                            <p class="fw-bold">#{{ $cargo->id }}</p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">نوع الشحن</label>
                            <p><span class="badge bg-info">{{ $cargo->type ?? 'عادي' }}</span></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>من</label>
                            <p class="fw-bold">{{ $cargo->route_from ?? __('N/A') }}</p>
                            @if($cargo->sender_city)
                                <small class="text-muted">{{ $cargo->sender_city }}</small>
                            @endif
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>إلى</label>
                            <p class="fw-bold">{{ $cargo->route_to ?? __('N/A') }}</p>
                            @if($cargo->receiver_city)
                                <small class="text-muted">{{ $cargo->receiver_city }}</small>
                            @endif
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">السعر لكل كجم</label>
                            <p class="text-success fw-bold">${{ number_format($cargo->price_per_kg, 2) }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الوزن</label>
                            <p><i class="fas fa-weight me-1"></i>{{ $booking->weight ?? 0 }} كجم</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">التكلفة الإجمالية</label>
                            <p class="text-primary fw-bold">${{ number_format($booking->total_price, 2) }}</p>
                        </div>
                        
                        @if($cargo->estimated_days)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">مدة التوصيل المتوقعة</label>
                                <p><i class="fas fa-clock me-1"></i>{{ $cargo->estimated_days }} يوم</p>
                            </div>
                        @endif
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">حالة التتبع</label>
                            <p>
                                <span class="badge bg-warning">
                                    {{ $cargo->tracking_status ?? 'قيد المعالجة' }}
                                </span>
                            </p>
                        </div>
                        
                        @if($cargo->current_location)
                            <div class="col-12 mb-3">
                                <label class="text-muted small">الموقع الحالي</label>
                                <p><i class="fas fa-location-arrow me-1"></i>{{ $cargo->current_location }}</p>
                            </div>
                        @endif
                        
                        @if($cargo->contents_description)
                            <div class="col-12 mb-3">
                                <label class="text-muted small">محتويات الشحنة</label>
                                <p class="border-start border-3 border-info ps-3">{{ $cargo->contents_description }}</p>
                            </div>
                        @endif
                        
                        <!-- Sender Information -->
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-user me-2"></i>معلومات المرسل</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الاسم</label>
                            <p>{{ $cargo->sender_name ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الهاتف</label>
                            <p><i class="fas fa-phone me-1"></i>{{ $cargo->sender_phone ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">واتساب</label>
                            <p><i class="fab fa-whatsapp me-1"></i>{{ $cargo->sender_whatsapp ?? __('N/A') }}</p>
                        </div>
                        
                        <!-- Receiver Information -->
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-user-check me-2"></i>معلومات المستلم</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الاسم</label>
                            <p>{{ $cargo->receiver_name ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الهاتف</label>
                            <p><i class="fas fa-phone me-1"></i>{{ $cargo->receiver_phone ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">واتساب</label>
                            <p><i class="fab fa-whatsapp me-1"></i>{{ $cargo->receiver_whatsapp ?? __('N/A') }}</p>
                        </div>
                    </div>
                @else
                    <p class="text-muted">{{ __('Service details not available.') }}</p>
                @endif
            </div>
        </div>
        
        <!-- Passenger Information Card (للرحلات فقط) -->
        @if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->passenger_first_name)
            <div class="card shadow mb-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-id-card me-2"></i>معلومات المسافر</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">اللقب</label>
                            <p>{{ $booking->passenger_title ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">الاسم الأول</label>
                            <p class="fw-bold">{{ $booking->passenger_first_name }}</p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">الاسم الأوسط</label>
                            <p>{{ $booking->passenger_middle_name ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">اسم العائلة</label>
                            <p class="fw-bold">{{ $booking->passenger_last_name ?? __('N/A') }}</p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">تاريخ الميلاد</label>
                            <p><i class="fas fa-birthday-cake me-1"></i>{{ $booking->passenger_date_of_birth ? $booking->passenger_date_of_birth->format('Y-m-d') : __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الجنسية</label>
                            <p><i class="fas fa-flag me-1"></i>{{ $booking->passenger_nationality ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">نوع المسافر</label>
                            <p>
                                <span class="badge bg-{{ $booking->passenger_type === 'adult' ? 'primary' : 'info' }}">
                                    {{ $booking->passenger_type === 'adult' ? 'بالغ' : 'طفل' }}
                                </span>
                            </p>
                        </div>
                        
                        @if($booking->passenger_phone)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">رقم الهاتف</label>
                                <p><i class="fas fa-phone me-1"></i>{{ $booking->passenger_phone }}</p>
                            </div>
                        @endif
                        @if($booking->passenger_whatsapp)
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">واتساب</label>
                                <p><i class="fab fa-whatsapp me-1"></i>{{ $booking->passenger_whatsapp }}</p>
                            </div>
                        @endif
                        
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-passport me-2"></i>معلومات جواز السفر</h6>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">رقم الجواز</label>
                            <p class="fw-bold">{{ $booking->passport_number ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">دولة الإصدار</label>
                            <p>{{ $booking->passport_issuing_country ?? __('N/A') }}</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">تاريخ الانتهاء</label>
                            <p>
                                @if($booking->passport_expiry_date)
                                    {{ $booking->passport_expiry_date->format('Y-m-d') }}
                                    @php
                                        $daysUntilExpiry = now()->diffInDays($booking->passport_expiry_date, false);
                                    @endphp
                                    @if($daysUntilExpiry < 180 && $daysUntilExpiry > 0)
                                        <span class="badge bg-warning">ينتهي قريباً</span>
                                    @elseif($daysUntilExpiry <= 0)
                                        <span class="badge bg-danger">منتهي</span>
                                    @endif
                                @else
                                    {{ __('N/A') }}
                                @endif
                            </p>
                        </div>
                        
                        @if($booking->passport_image)
                            <div class="col-12 mb-3">
                                <label class="text-muted small">صورة الجواز</label>
                                <div>
                                    <a href="{{ asset('storage/' . $booking->passport_image) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>عرض صورة الجواز
                                    </a>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @endif
    </div>

    <div class="col-lg-4">
        <!-- User Information Card -->
        <div class="card shadow mb-4">
            <div class="card-header">
                <h5 class="mb-0">{{ __('User Information') }}</h5>
            </div>
            <div class="card-body text-center">
                @if($booking->user)
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mx-auto mb-3" 
                         style="width: 80px; height: 80px; font-size: 32px;">
                        {{ strtoupper(substr($booking->user->name, 0, 1)) }}
                    </div>
                    <h6 class="fw-bold">{{ $booking->user->name }}</h6>
                    <p class="text-muted mb-1">{{ $booking->user->email }}</p>
                    @if($booking->user->phone)
                        <p class="text-muted mb-3">{{ $booking->user->phone }}</p>
                    @endif
                    
                    <div class="text-start">
                        <div class="mb-2">
                            <small class="text-muted">{{ __('Role') }}:</small>
                            <span class="badge bg-info">{{ __(strtolower($booking->user->role)) }}</span>
                        </div>
                        <div class="mb-2">
                            <small class="text-muted">{{ __('Account Status') }}:</small>
                            <span class="badge bg-{{ $booking->user->is_active ? 'success' : 'danger' }}">
                                {{ $booking->user->is_active ? __('Active') : __('Inactive') }}
                            </span>
                        </div>
                        @if($booking->user->wallet)
                            <div>
                                <small class="text-muted">{{ __('Wallet Balance') }}:</small>
                                <span class="fw-bold text-success">${{ number_format($booking->user->wallet->balance, 2) }}</span>
                            </div>
                        @endif
                    </div>
                @else
                    <p class="text-muted">{{ __('User information not available.') }}</p>
                @endif
            </div>
        </div>

        <!-- Agency Information Card -->
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Agency Information') }}</h5>
            </div>
            <div class="card-body">
                @if($booking->agency)
                    <div class="text-center mb-3">
                        @if($booking->agency->logo)
                            <img src="{{ $booking->agency->logo }}" alt="{{ $booking->agency->name }}" 
                                 class="rounded-circle" width="80" height="80">
                        @else
                            <div class="rounded-circle bg-secondary text-white d-inline-flex align-items-center justify-content-center mx-auto" 
                                 style="width: 80px; height: 80px; font-size: 32px;">
                                <i class="fas fa-building"></i>
                            </div>
                        @endif
                    </div>
                    
                    <h6 class="fw-bold text-center">{{ $booking->agency->name }}</h6>
                    
                    <div class="mt-3">
                        <div class="mb-2">
                            <small class="text-muted">{{ __('License') }}:</small>
                            <p class="mb-0">{{ $booking->agency->license_number ?: __('N/A') }}</p>
                        </div>
                        <div class="mb-2">
                            <small class="text-muted">{{ __('Status') }}:</small>
                            <span class="badge bg-{{ $booking->agency->status === 'active' ? 'success' : 'danger' }}">
                                {{ __(strtolower($booking->agency->status)) }}
                            </span>
                        </div>
                        <div>
                            <small class="text-muted">{{ __('Balance') }}:</small>
                            <p class="mb-0 fw-bold">${{ number_format($booking->agency->current_balance, 2) }}</p>
                        </div>
                    </div>
                @else
                    <p class="text-muted">{{ __('Agency information not available.') }}</p>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Action Buttons -->
<div class="mt-4">
    <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Bookings') }}
    </a>
    
    @if($booking->status === 'pending')
        <form action="{{ route('admin.bookings.accept', $booking->id) }}" 
              method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn btn-success" 
                    onclick="return confirm('{{ __('Are you sure you want to accept this booking?') }}')">
                <i class="fas fa-check me-2"></i>{{ __('Accept Booking') }}
            </button>
        </form>
        
        <button type="button" 
                class="btn btn-danger" 
                data-bs-toggle="modal" 
                data-bs-target="#rejectModal">
            <i class="fas fa-times me-2"></i>{{ __('Reject Booking') }}
        </button>
    @endif
</div>

<!-- Reject Modal -->
@if($booking->status === 'pending')
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('Reject Booking') }} #{{ $booking->id }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="{{ route('admin.bookings.reject', $booking->id) }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="rejection_reason" class="form-label">
                                {{ __('Rejection Reason') }} <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" 
                                      id="rejection_reason" 
                                      name="rejection_reason" 
                                      rows="4" 
                                      placeholder="{{ __('Please provide a reason for rejecting this booking...') }}"
                                      required></textarea>
                            <small class="form-text text-muted">
                                {{ __('This reason will be visible to the customer.') }}
                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            {{ __('Cancel') }}
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-times me-2"></i>{{ __('Reject Booking') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endif

<!-- Reject Payment Modal -->
@if($booking->payment_status === 'pending_verification')
    <div class="modal fade" id="rejectPaymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-times-circle me-2"></i>رفض إيصال الدفع</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form action="{{ route('admin.bookings.reject-payment', $booking->id) }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            سيتم إرسال إشعار للعميل بسبب الرفض ليتمكن من رفع إيصال جديد
                        </div>
                        <div class="mb-3">
                            <label for="payment_rejection_reason" class="form-label">
                                سبب رفض الإيصال <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" 
                                      id="payment_rejection_reason" 
                                      name="rejection_reason" 
                                      rows="4" 
                                      placeholder="مثال: الإيصال غير واضح، المبلغ لا يتطابق، تاريخ التحويل قديم..."
                                      required></textarea>
                            <small class="form-text text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                هذا السبب سيظهر للعميل في الإشعار
                            </small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-muted small">معلومات الحجز:</label>
                            <ul class="list-unstyled mb-0">
                                <li><strong>رقم الحجز:</strong> #{{ $booking->id }}</li>
                                <li><strong>المبلغ:</strong> ${{ number_format($booking->total_price, 2) }}</li>
                                <li><strong>العميل:</strong> {{ $booking->user->name ?? 'غير معروف' }}</li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i>إلغاء
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-ban me-2"></i>رفض الإيصال وإرسال إشعار
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endif
@endsection
