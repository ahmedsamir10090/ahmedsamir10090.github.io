@extends('layouts.admin')

@section('title', __('New Cargo Shipment Booking'))

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">{{ __('New Cargo Shipment Booking') }}</h2>
        <a href="{{ route('admin.bookings.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-right me-2"></i>{{ __('Back to Bookings') }}
        </a>
    </div>

    @if($errors->any())
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <form action="{{ route('admin.cargo.bookings.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <!-- Step 1: Select Route -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-route me-2"></i>{{ __('Step 1: Select Route') }}</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('From Country') }} <span class="text-danger">*</span></label>
                        <select name="route_from" id="route_from" class="form-select @error('route_from') is-invalid @enderror" required>
                            <option value="">{{ __('Select Country') }}</option>
                            <option value="sudan" {{ old('route_from') == 'sudan' ? 'selected' : '' }}>{{ __('Sudan') }}</option>
                            <option value="egypt" {{ old('route_from') == 'egypt' ? 'selected' : '' }}>{{ __('Egypt') }}</option>
                            <option value="saudi_arabia" {{ old('route_from') == 'saudi_arabia' ? 'selected' : '' }}>{{ __('Saudi Arabia') }}</option>
                            <option value="uae" {{ old('route_from') == 'uae' ? 'selected' : '' }}>{{ __('UAE') }}</option>
                            <option value="oman" {{ old('route_from') == 'oman' ? 'selected' : '' }}>{{ __('Oman') }}</option>
                            <option value="south_sudan" {{ old('route_from') == 'south_sudan' ? 'selected' : '' }}>{{ __('South Sudan') }}</option>
                            <option value="kuwait" {{ old('route_from') == 'kuwait' ? 'selected' : '' }}>{{ __('Kuwait') }}</option>
                            <option value="bahrain" {{ old('route_from') == 'bahrain' ? 'selected' : '' }}>{{ __('Bahrain') }}</option>
                        </select>
                        @error('route_from')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('To Country') }} <span class="text-danger">*</span></label>
                        <select name="route_to" id="route_to" class="form-select @error('route_to') is-invalid @enderror" required>
                            <option value="">{{ __('Select Country') }}</option>
                            <option value="sudan" {{ old('route_to') == 'sudan' ? 'selected' : '' }}>{{ __('Sudan') }}</option>
                            <option value="egypt" {{ old('route_to') == 'egypt' ? 'selected' : '' }}>{{ __('Egypt') }}</option>
                            <option value="saudi_arabia" {{ old('route_to') == 'saudi_arabia' ? 'selected' : '' }}>{{ __('Saudi Arabia') }}</option>
                            <option value="uae" {{ old('route_to') == 'uae' ? 'selected' : '' }}>{{ __('UAE') }}</option>
                            <option value="oman" {{ old('route_to') == 'oman' ? 'selected' : '' }}>{{ __('Oman') }}</option>
                            <option value="south_sudan" {{ old('route_to') == 'south_sudan' ? 'selected' : '' }}>{{ __('South Sudan') }}</option>
                            <option value="kuwait" {{ old('route_to') == 'kuwait' ? 'selected' : '' }}>{{ __('Kuwait') }}</option>
                            <option value="bahrain" {{ old('route_to') == 'bahrain' ? 'selected' : '' }}>{{ __('Bahrain') }}</option>
                        </select>
                        @error('route_to')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <button type="button" id="btn_search_services" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i>{{ __('Search Available Services') }}
                </button>
            </div>
        </div>

        <!-- Step 2: Select Cargo Service -->
        <div class="card mb-4" id="services_container" style="display: none;">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-box me-2"></i>{{ __('Step 2: Select Cargo Service') }}</h5>
            </div>
            <div class="card-body">
                <div id="services_list" class="row">
                    <!-- Will be filled by AJAX -->
                </div>
                <div id="no_services" class="text-center text-muted" style="display: none;">
                    <i class="fas fa-info-circle fa-3x mb-3"></i>
                    <h5>{{ __('No cargo services available for this route') }}</h5>
                    <p>{{ __('Please select different countries or contact agency to add service') }}</p>
                </div>
            </div>
        </div>

        <!-- Step 3: Sender Information -->
        <div class="card mb-4" id="sender_container" style="display: none;">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-user me-2"></i>{{ __('Step 3: Sender Information') }}</h5>
            </div>
            <div class="card-body">
                <input type="hidden" name="cargo_service_id" id="cargo_service_id" value="{{ old('cargo_service_id') }}">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Sender Name') }} <span class="text-danger">*</span></label>
                        <input type="text" name="sender_name" class="form-control @error('sender_name') is-invalid @enderror" 
                               value="{{ old('sender_name') }}" required>
                        @error('sender_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Phone Number') }} <span class="text-danger">*</span></label>
                        <input type="text" name="sender_phone" class="form-control @error('sender_phone') is-invalid @enderror" 
                               value="{{ old('sender_phone') }}" required>
                        @error('sender_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('WhatsApp Number') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                        <input type="text" name="sender_whatsapp" class="form-control @error('sender_whatsapp') is-invalid @enderror" 
                               value="{{ old('sender_whatsapp') }}">
                        @error('sender_whatsapp')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('City') }} <span class="text-danger">*</span></label>
                        <input type="text" name="sender_city" class="form-control @error('sender_city') is-invalid @enderror" 
                               value="{{ old('sender_city') }}" required>
                        @error('sender_city')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label">{{ __('Passport Image') }} <span class="text-danger">*</span></label>
                        <input type="file" name="sender_passport_image" class="form-control @error('sender_passport_image') is-invalid @enderror" 
                               accept="image/*,.pdf" required>
                        <small class="text-muted">{{ __('Upload clear image of passport') }} (Max: 5MB)</small>
                        @error('sender_passport_image')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 4: Receiver Information -->
        <div class="card mb-4" id="receiver_container" style="display: none;">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="fas fa-user-check me-2"></i>{{ __('Step 4: Receiver Information') }}</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Receiver Name') }} <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_name" class="form-control @error('receiver_name') is-invalid @enderror" 
                               value="{{ old('receiver_name') }}" required>
                        @error('receiver_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Phone Number') }} <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_phone" class="form-control @error('receiver_phone') is-invalid @enderror" 
                               value="{{ old('receiver_phone') }}" required>
                        @error('receiver_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('WhatsApp Number') }} <small class="text-muted">({{ __('Optional') }})</small></label>
                        <input type="text" name="receiver_whatsapp" class="form-control @error('receiver_whatsapp') is-invalid @enderror" 
                               value="{{ old('receiver_whatsapp') }}">
                        @error('receiver_whatsapp')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('City') }} <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_city" class="form-control @error('receiver_city') is-invalid @enderror" 
                               value="{{ old('receiver_city') }}" required>
                        @error('receiver_city')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 5: Shipment Details -->
        <div class="card mb-4" id="shipment_container" style="display: none;">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-box-open me-2"></i>{{ __('Step 5: Shipment Details') }}</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Shipment Type') }} <span class="text-danger">*</span></label>
                        <select name="shipment_type" class="form-select @error('shipment_type') is-invalid @enderror" required>
                            <option value="">{{ __('Select Type') }}</option>
                            <option value="documents" {{ old('shipment_type') == 'documents' ? 'selected' : '' }}>{{ __('Documents') }}</option>
                            <option value="parcels" {{ old('shipment_type') == 'parcels' ? 'selected' : '' }}>{{ __('Parcels') }}</option>
                            <option value="goods" {{ old('shipment_type') == 'goods' ? 'selected' : '' }}>{{ __('Goods') }}</option>
                            <option value="personal_effects" {{ old('shipment_type') == 'personal_effects' ? 'selected' : '' }}>{{ __('Personal Effects') }}</option>
                        </select>
                        @error('shipment_type')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">{{ __('Weight (kg)') }} <span class="text-danger">*</span></label>
                        <input type="number" name="weight" id="weight" step="0.01" class="form-control @error('weight') is-invalid @enderror" 
                               value="{{ old('weight') }}" required>
                        <small class="text-muted" id="weight_range"><!-- Will be filled by JS --></small>
                        @error('weight')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label">{{ __('Contents Description') }} <span class="text-danger">*</span></label>
                        <textarea name="contents_description" rows="3" class="form-control @error('contents_description') is-invalid @enderror" 
                                  placeholder="{{ __('Please provide detailed description of the contents') }}" required>{{ old('contents_description') }}</textarea>
                        @error('contents_description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="no_prohibited_items" class="form-check-input @error('no_prohibited_items') is-invalid @enderror" 
                                   id="no_prohibited_items" value="1" {{ old('no_prohibited_items') ? 'checked' : '' }} required>
                            <label class="form-check-label" for="no_prohibited_items">
                                {{ __('I declare that this shipment does not contain any prohibited items') }}
                            </label>
                            @error('no_prohibited_items')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <small class="text-muted">
                            {{ __('Prohibited items include: weapons, explosives, flammable materials, drugs, and any illegal substances') }}
                        </small>
                    </div>
                </div>

                <!-- Price Summary -->
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title">{{ __('Price Summary') }}</h6>
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td>{{ __('Price per KG') }}:</td>
                                        <td class="text-end"><strong id="price_per_kg_display">0.00</strong> {{ __('SDG') }}</td>
                                    </tr>
                                    <tr>
                                        <td>{{ __('Weight') }}:</td>
                                        <td class="text-end"><strong id="weight_display">0.00</strong> {{ __('kg') }}</td>
                                    </tr>
                                    <tr>
                                        <td>{{ __('Insurance Fee') }}:</td>
                                        <td class="text-end">
                                            <input type="number" name="insurance_fee" id="insurance_fee" step="0.01" class="form-control form-control-sm text-end" value="{{ old('insurance_fee', 0) }}" style="width: 100px; display: inline;">
                                            {{ __('SDG') }}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>{{ __('Customs Fee') }}:</td>
                                        <td class="text-end">
                                            <input type="number" name="customs_fee" id="customs_fee" step="0.01" class="form-control form-control-sm text-end" value="{{ old('customs_fee', 0) }}" style="width: 100px; display: inline;">
                                            {{ __('SDG') }}
                                        </td>
                                    </tr>
                                    <tr class="table-primary">
                                        <td><strong>{{ __('Total') }}:</strong></td>
                                        <td class="text-end">
                                            <strong id="total_price_display">0.00</strong> {{ __('SDG') }}
                                            <input type="hidden" name="total_price" id="total_price" value="0">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>{{ __('Cancel') }}
                    </a>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-check me-2"></i>{{ __('Create Cargo Booking') }}
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

@push('scripts')
<script>
let selectedService = null;

// Search for services
$('#btn_search_services').on('click', function() {
    const from = $('#route_from').val();
    const to = $('#route_to').val();
    
    if (!from || !to) {
        alert('{{ __("Please select both countries") }}');
        return;
    }
    
    if (from === to) {
        alert('{{ __("From and To countries must be different") }}');
        return;
    }
    
    // Show loading
    $('#services_list').html('<div class="col-12 text-center"><i class="fas fa-spinner fa-spin fa-3x"></i></div>');
    $('#services_container').show();
    
    // Fetch services
    $.ajax({
        url: '{{ route("admin.cargo.bookings.services") }}',
        method: 'GET',
        data: { from: from, to: to },
        success: function(response) {
            if (response.services.length === 0) {
                $('#services_list').html('');
                $('#no_services').show();
            } else {
                $('#no_services').hide();
                let html = '';
                response.services.forEach(service => {
                    html += `
                        <div class="col-md-6 mb-3">
                            <div class="card service-card" data-service='${JSON.stringify(service)}' style="cursor: pointer;">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-0">${service.agency_name}</h6>
                                        <span class="badge bg-primary">${service.type_label}</span>
                                    </div>
                                    <p class="text-muted mb-2 small">
                                        <i class="fas fa-route me-1"></i>
                                        ${service.route_from_label} → ${service.route_to_label}
                                    </p>
                                    <div class="row">
                                        <div class="col-6">
                                            <small class="text-muted">{{ __("Price per KG") }}</small>
                                            <p class="mb-0"><strong>${service.price_per_kg} {{ __("SDG") }}</strong></p>
                                        </div>
                                        <div class="col-6">
                                            <small class="text-muted">{{ __("Weight Range") }}</small>
                                            <p class="mb-0">${service.min_weight} - ${service.max_weight} {{ __("kg") }}</p>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <small class="text-muted">{{ __("Estimated Delivery") }}: ${service.estimated_days} {{ __("days") }}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
                $('#services_list').html(html);
                
                // Handle service selection
                $('.service-card').on('click', function() {
                    $('.service-card').removeClass('border-success border-3');
                    $(this).addClass('border-success border-3');
                    
                    selectedService = JSON.parse($(this).attr('data-service'));
                    $('#cargo_service_id').val(selectedService.id);
                    
                    // Update weight range hint
                    $('#weight_range').text(`{{ __("Range") }}: ${selectedService.min_weight} - ${selectedService.max_weight} {{ __("kg") }}`);
                    
                    // Update price display
                    $('#price_per_kg_display').text(selectedService.price_per_kg);
                    
                    // Show next steps
                    $('#sender_container').show();
                    $('#receiver_container').show();
                    $('#shipment_container').show();
                    
                    // Scroll to sender section
                    $('html, body').animate({
                        scrollTop: $('#sender_container').offset().top - 100
                    }, 500);
                });
            }
        },
        error: function() {
            alert('{{ __("Error fetching services") }}');
        }
    });
});

// Calculate total price
function calculateTotal() {
    if (!selectedService) return;
    
    const weight = parseFloat($('#weight').val()) || 0;
    const insurance = parseFloat($('#insurance_fee').val()) || 0;
    const customs = parseFloat($('#customs_fee').val()) || 0;
    const pricePerKg = parseFloat(selectedService.price_per_kg);
    
    const total = (weight * pricePerKg) + insurance + customs;
    
    $('#weight_display').text(weight.toFixed(2));
    $('#total_price_display').text(total.toFixed(2));
    $('#total_price').val(total.toFixed(2));
}

$('#weight, #insurance_fee, #customs_fee').on('input', calculateTotal);
</script>
@endpush
@endsection
