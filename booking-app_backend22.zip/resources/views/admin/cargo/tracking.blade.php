@extends('layouts.admin')

@section('title', __('Tracking Number') . ' #' . $booking->id)

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0">{{ __('Tracking Number') }}: #{{ $booking->id }}</h2>
            <p class="text-muted mb-0">{{ __('Current Status') }}: <span class="badge bg-primary">{{ __(ucfirst($booking->serviceable->tracking_status)) }}</span></p>
        </div>
        <a href="{{ route('admin.bookings.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-right me-2"></i>{{ __('Back to Bookings') }}
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row">
        <!-- Sender Information -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">{{ __('Sender Information') }}</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>{{ __('Sender Name') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->sender_name }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Phone Number') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->sender_phone }}</p>
                    </div>
                    @if($booking->serviceable->sender_whatsapp)
                    <div class="mb-3">
                        <strong>{{ __('WhatsApp Number') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->sender_whatsapp }}</p>
                    </div>
                    @endif
                    <div class="mb-3">
                        <strong>{{ __('Country') }}:</strong>
                        <p class="mb-1">{{ __(ucfirst($booking->serviceable->sender_country)) }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('City') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->sender_city }}</p>
                    </div>
                    @if($booking->serviceable->sender_passport_image)
                    <div class="mb-3">
                        <strong>{{ __('Passport Image') }}:</strong><br>
                        <a href="{{ asset('storage/' . $booking->serviceable->sender_passport_image) }}" target="_blank" class="btn btn-sm btn-outline-primary mt-2">
                            <i class="fas fa-eye me-1"></i>{{ __('View') }}
                        </a>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Receiver Information -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">{{ __('Receiver Information') }}</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>{{ __('Receiver Name') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->receiver_name }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Phone Number') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->receiver_phone }}</p>
                    </div>
                    @if($booking->serviceable->receiver_whatsapp)
                    <div class="mb-3">
                        <strong>{{ __('WhatsApp Number') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->receiver_whatsapp }}</p>
                    </div>
                    @endif
                    <div class="mb-3">
                        <strong>{{ __('Country') }}:</strong>
                        <p class="mb-1">{{ __(ucfirst($booking->serviceable->receiver_country)) }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('City') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->receiver_city }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shipment Details -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">{{ __('Shipment Details') }}</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>{{ __('Weight') }}:</strong>
                        <p class="mb-1">{{ $booking->weight }} {{ __('kg') }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Total Price') }}:</strong>
                        <p class="mb-1">{{ number_format($booking->total_price, 2) }} {{ __('SDG') }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Contents Description') }}:</strong>
                        <p class="mb-1">{{ $booking->serviceable->contents_description }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Agency') }}:</strong>
                        <p class="mb-1">{{ $booking->agency->name ?? __('N/A') }}</p>
                    </div>
                    <div class="mb-3">
                        <strong>{{ __('Created At') }}:</strong>
                        <p class="mb-1">{{ $booking->created_at->format('Y-m-d H:i') }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tracking Status Update -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">{{ __('Update Status') }}</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.cargo.bookings.update-status', $booking->id) }}" method="POST">
                        @csrf
                        
                        <div class="mb-3">
                            <label class="form-label">{{ __('Tracking Status') }} <span class="text-danger">*</span></label>
                            <select name="tracking_status" class="form-select @error('tracking_status') is-invalid @enderror" required>
                                <option value="">{{ __('Select Type') }}</option>
                                <option value="pending" {{ $booking->serviceable->tracking_status == 'pending' ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                <option value="picked_up" {{ $booking->serviceable->tracking_status == 'picked_up' ? 'selected' : '' }}>{{ __('Picked Up') }}</option>
                                <option value="in_transit_origin" {{ $booking->serviceable->tracking_status == 'in_transit_origin' ? 'selected' : '' }}>{{ __('In Transit (Origin)') }}</option>
                                <option value="customs_origin" {{ $booking->serviceable->tracking_status == 'customs_origin' ? 'selected' : '' }}>{{ __('Customs (Origin)') }}</option>
                                <option value="in_flight" {{ $booking->serviceable->tracking_status == 'in_flight' ? 'selected' : '' }}>{{ __('In Flight') }}</option>
                                <option value="arrived_destination" {{ $booking->serviceable->tracking_status == 'arrived_destination' ? 'selected' : '' }}>{{ __('Arrived at Destination') }}</option>
                                <option value="customs_destination" {{ $booking->serviceable->tracking_status == 'customs_destination' ? 'selected' : '' }}>{{ __('Customs (Destination)') }}</option>
                                <option value="out_for_delivery" {{ $booking->serviceable->tracking_status == 'out_for_delivery' ? 'selected' : '' }}>{{ __('Out for Delivery') }}</option>
                                <option value="delivered" {{ $booking->serviceable->tracking_status == 'delivered' ? 'selected' : '' }}>{{ __('Delivered') }}</option>
                            </select>
                            @error('tracking_status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">{{ __('Current Location') }} <span class="text-danger">*</span></label>
                            <input type="text" name="current_location" class="form-control @error('current_location') is-invalid @enderror" 
                                   value="{{ old('current_location', $booking->serviceable->current_location) }}" required>
                            @error('current_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <strong>{{ __('Status Updated At') }}:</strong>
                            <p class="mb-1">{{ $booking->serviceable->status_updated_at ? $booking->serviceable->status_updated_at->format('Y-m-d H:i') : __('N/A') }}</p>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-sync-alt me-2"></i>{{ __('Update Status') }}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Tracking Timeline -->
    <div class="card">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">{{ __('Tracking Status') }}</h5>
        </div>
        <div class="card-body">
            <div class="timeline">
                @php
                    $statuses = [
                        'pending' => __('Pending'),
                        'picked_up' => __('Picked Up'),
                        'in_transit_origin' => __('In Transit (Origin)'),
                        'customs_origin' => __('Customs (Origin)'),
                        'in_flight' => __('In Flight'),
                        'arrived_destination' => __('Arrived at Destination'),
                        'customs_destination' => __('Customs (Destination)'),
                        'out_for_delivery' => __('Out for Delivery'),
                        'delivered' => __('Delivered'),
                    ];
                    
                    $currentIndex = array_search($booking->serviceable->tracking_status, array_keys($statuses));
                @endphp

                @foreach($statuses as $key => $label)
                    @php
                        $index = array_search($key, array_keys($statuses));
                        $isActive = $index <= $currentIndex;
                        $isCurrent = $key === $booking->serviceable->tracking_status;
                    @endphp
                    
                    <div class="timeline-item {{ $isActive ? 'active' : '' }} {{ $isCurrent ? 'current' : '' }}">
                        <div class="timeline-marker">
                            @if($isActive)
                                <i class="fas fa-check-circle"></i>
                            @else
                                <i class="far fa-circle"></i>
                            @endif
                        </div>
                        <div class="timeline-content">
                            <h6 class="mb-0">{{ $label }}</h6>
                            @if($isCurrent)
                                <small class="text-muted">{{ __('Current Location') }}: {{ $booking->serviceable->current_location }}</small>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
    .timeline {
        position: relative;
        padding: 20px 0;
    }
    
    .timeline-item {
        display: flex;
        margin-bottom: 30px;
        position: relative;
    }
    
    .timeline-item:not(:last-child)::before {
        content: '';
        position: absolute;
        right: 19px;
        top: 30px;
        height: calc(100% + 10px);
        width: 2px;
        background: #dee2e6;
    }
    
    .timeline-item.active:not(:last-child)::before {
        background: #0d6efd;
    }
    
    .timeline-marker {
        flex-shrink: 0;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #f8f9fa;
        border: 2px solid #dee2e6;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: 15px;
        position: relative;
        z-index: 1;
    }
    
    .timeline-item.active .timeline-marker {
        background: #0d6efd;
        border-color: #0d6efd;
        color: white;
    }
    
    .timeline-item.current .timeline-marker {
        background: #ffc107;
        border-color: #ffc107;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(255, 193, 7, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(255, 193, 7, 0);
        }
    }
    
    .timeline-content {
        flex-grow: 1;
        padding-right: 20px;
    }
    
    .timeline-item.active .timeline-content h6 {
        color: #0d6efd;
        font-weight: bold;
    }
    
    .timeline-item.current .timeline-content h6 {
        color: #ffc107;
        font-weight: bold;
    }
</style>
@endpush
@endsection
