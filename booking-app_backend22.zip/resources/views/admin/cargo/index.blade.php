@extends('layouts.admin')

@section('title', __('Manage Cargo Services'))
@section('header', __('Manage Cargo Services'))

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0">{{ __('Cargo Services') }}</h5>
        <small class="text-muted">{{ __('Manage cargo offerings') }}</small>
    </div>
    <a href="{{ route('admin.cargo.create') }}" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>{{ __('Add Cargo Service') }}
    </a>
</div>
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="card shadow">
    <div class="card-body">
        @if($services->count() > 0)
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>{{ __('ID') }}</th>
                            <th>{{ __('Agency') }}</th>
                            <th>{{ __('Type') }}</th>
                            <th>{{ __('Route') }}</th>
                            <th>{{ __('Price / Kg') }}</th>
                            <th>{{ __('Min Weight') }}</th>
                            <th>{{ __('Delivery Time') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($services as $service)
                            <tr>
                                <td>{{ $service->id }}</td>
                                <td>{{ $service->agency->name ?? __('N/A') }}</td>
                                <td>{{ __(strtolower($service->type)) }}</td>
                                <td>{{ $service->route_from }} &rarr; {{ $service->route_to }}</td>
                                <td>${{ number_format($service->price_per_kg, 2) }}</td>
                                <td>{{ number_format($service->min_weight, 2) }} {{ __('kg') }}</td>
                                <td>{{ $service->delivery_time_estimate }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('admin.cargo.edit', $service->id) }}" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> {{ __('Edit') }}
                                        </a>
                                        <form action="{{ route('admin.cargo.destroy', $service->id) }}" method="POST" class="d-inline"
                                              onsubmit="return confirm('{{ __('Delete this cargo service?') }}')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>    {{ __('Delete') }}
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                {{ $services->links() }}
            </div>
        @else
            <div class="text-center py-5">
                <i class="fas fa-box fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">{{ __('No cargo services found') }}</h5>
                <p class="text-muted">{{ __('Cargo services will appear here once created.') }}</p>
            </div>
        @endif
    </div>
</div>
@endsection
