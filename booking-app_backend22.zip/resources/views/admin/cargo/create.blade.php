@extends('layouts.admin')

@section('title', __('Create Cargo Service'))
@section('header', __('Create Cargo Service'))

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Create Cargo Service') }}</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.cargo.store') }}" method="POST">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="agency_id">{{ __('Agency') }}</label>
                            <select class="form-select @error('agency_id') is-invalid @enderror" id="agency_id" name="agency_id" required>
                                <option value="">{{ __('Select agency') }}</option>
                                @foreach($agencies as $agency)
                                    <option value="{{ $agency->id }}" {{ old('agency_id') == $agency->id ? 'selected' : '' }}>
                                        {{ $agency->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('agency_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="type">{{ __('Service Type') }}</label>
                            <select class="form-select @error('type') is-invalid @enderror" id="type" name="type" required>
                                <option value="">{{ __('Select type') }}</option>
                                <option value="air" {{ old('type') === 'air' ? 'selected' : '' }}>{{ __('Air') }}</option>
                                <option value="sea" {{ old('type') === 'sea' ? 'selected' : '' }}>{{ __('Sea') }}</option>
                                <option value="land" {{ old('type') === 'land' ? 'selected' : '' }}>{{ __('Land') }}</option>
                            </select>
                            @error('type')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="route_from">{{ __('From Country') }} <span class="text-danger">*</span></label>
                            <select class="form-select @error('route_from') is-invalid @enderror" id="route_from" name="route_from" required>
                                <option value="">{{ __('Select Country') }}</option>
                                @foreach($countries as $country)
                                    <option value="{{ strtolower(str_replace(' ', '_', $country->name_en)) }}" {{ old('route_from') == strtolower(str_replace(' ', '_', $country->name_en)) ? 'selected' : '' }}>
                                        {{ $country->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('route_from')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="route_to">{{ __('To Country') }} <span class="text-danger">*</span></label>
                            <select class="form-select @error('route_to') is-invalid @enderror" id="route_to" name="route_to" required>
                                <option value="">{{ __('Select Country') }}</option>
                                @foreach($countries as $country)
                                    <option value="{{ strtolower(str_replace(' ', '_', $country->name_en)) }}" {{ old('route_to') == strtolower(str_replace(' ', '_', $country->name_en)) ? 'selected' : '' }}>
                                        {{ $country->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('route_to')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="min_weight">{{ __('Minimum Weight (kg)') }} <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" class="form-control @error('min_weight') is-invalid @enderror" id="min_weight" name="min_weight" value="{{ old('min_weight', 30) }}" required>
                            @error('min_weight')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="max_weight">{{ __('Maximum Weight (kg)') }} <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" class="form-control @error('max_weight') is-invalid @enderror" id="max_weight" name="max_weight" value="{{ old('max_weight', 100) }}" required>
                            @error('max_weight')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="price_per_kg">{{ __('Price per Kg') }} <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" class="form-control @error('price_per_kg') is-invalid @enderror" id="price_per_kg" name="price_per_kg" value="{{ old('price_per_kg', 20) }}" required>
                            @error('price_per_kg')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label" for="delivery_time_estimate">{{ __('Estimated Delivery Days') }}</label>
                            <input type="number" class="form-control @error('delivery_time_estimate') is-invalid @enderror" id="delivery_time_estimate" name="delivery_time_estimate" value="{{ old('delivery_time_estimate', 7) }}" placeholder="{{ __('e.g. 3-5 days') }}">
                            @error('delivery_time_estimate')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                                @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
                        <a href="{{ route('admin.cargo.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Cargo Services') }}
                        </a>
                        <button type="submit" class="btn btn-primary">
                            
                            <i class="fas fa-save me-2"></i>{{ __('Create Cargo Service') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
