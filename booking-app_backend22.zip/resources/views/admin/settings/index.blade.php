@extends('layouts.admin')

@section('title', __('System Settings'))
@section('header', __('System Settings'))

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <!-- Success/Error Messages -->
        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        <!-- Settings Form -->
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-cog me-2"></i>{{ __('System Configuration') }}
                </h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.settings.update') }}" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <!-- Payment Settings -->
                    <div class="mb-4">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-credit-card me-2"></i>{{ __('Payment Settings') }}
                        </h6>
                        
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" 
                                   id="online_payment_enabled" 
                                   name="online_payment_enabled" 
                                   value="1"
                                   {{ $settings['online_payment_enabled'] ? 'checked' : '' }}>
                            <label class="form-check-label" for="online_payment_enabled">
                                {{ __('Enable Online Payment') }}
                            </label>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <small>
                                {{ __('When enabled, users can pay for bookings using online payment methods.') }}
                                {{ __('When disabled, only wallet payments will be available.') }}
                            </small>
                        </div>
                    </div>
                    
                    <!-- Commission Settings -->
                    <div class="mb-4">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-percentage me-2"></i>{{ __('Commission Settings') }}
                        </h6>
                        
                        <div class="mb-3">
                            <label for="commission_rate" class="form-label">
                                {{ __('Default Commission Rate (%)') }}
                            </label>
                            <div class="input-group">
                                <input type="number" 
                                       class="form-control @error('commission_rate') is-invalid @enderror" 
                                       id="commission_rate" 
                                       name="commission_rate" 
                                       value="{{ old('commission_rate', $settings['commission_rate']) }}"
                                       min="0" 
                                       max="100" 
                                       step="0.01" 
                                       required>
                                <span class="input-group-text">%</span>
                            </div>
                            @error('commission_rate')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <small>
                                {{ __('This commission rate will be applied to all new agencies by default.') }}
                                {{ __('Existing agencies will keep their current rates unless manually updated.') }}
                            </small>
                        </div>
                    </div>
                    
                    <!-- Current Settings Display -->
                    <div class="mb-4">
                        <h6 class="text-primary mb-3">
                            <i class="fas fa-eye me-2"></i>{{ __('Current Settings') }}
                        </h6>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6 class="text-muted mb-2">{{ __('Online Payment') }}</h6>
                                        <span class="badge bg-{{ $settings['online_payment_enabled'] ? 'success' : 'danger' }} fs-6">
                                            {{ $settings['online_payment_enabled'] ? __('Enabled') : __('Disabled') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h6 class="text-muted mb-2">{{ __('Commission Rate') }}</h6>
                                        <span class="badge bg-primary fs-6">{{ $settings['commission_rate'] }}%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Form Actions -->
                    <div class="d-flex justify-content-between">
                        <div>
                            <form action="{{ route('admin.settings.reset') }}" 
                                  method="POST" class="d-inline"
                                  onsubmit="return confirm('{{ __('Are you sure you want to reset all settings to default values? This action cannot be undone.') }}')">
                                @csrf
                                @method('PUT')
                                <button type="submit" class="btn btn-outline-warning">
                                    <i class="fas fa-undo me-2"></i>{{ __('Reset to Defaults') }}
                                </button>
                            </form>
                        </div>
                        <div>
                            <button type="reset" class="btn btn-outline-secondary me-2">
                                <i class="fas fa-times me-2"></i>{{ __('Cancel') }}
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>{{ __('Save Settings') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Additional Information -->
        <div class="card shadow mt-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>{{ __('System Information') }}
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <strong>{{ __('Application') }}:</strong> {{ __('Booking System') }}<br>
                        <strong>{{ __('Version') }}:</strong> 1.0.0<br>
                        <strong>{{ __('Environment') }}:</strong> {{ config('app.env') }}
                    </div>
                    <div class="col-md-6">
                        <strong>{{ __('Laravel Version') }}:</strong> {{ app()->version() }}<br>
                        <strong>{{ __('PHP Version') }}:</strong> {{ PHP_VERSION }}<br>
                        <strong>{{ __('Timezone') }}:</strong> {{ config('app.timezone') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }
    
    .form-switch .form-check-input {
        width: 3em;
        height: 1.5em;
    }
    
    .badge.fs-6 {
        font-size: 1rem !important;
        padding: 0.5em 0.75em;
    }
    
    .card.bg-light {
        background-color: #f8f9fa !important;
        border: 1px solid #e9ecef;
    }
</style>
@endpush

@push('scripts')
<script>
    // Auto-save functionality (optional enhancement)
    let formChanged = false;
    const form = document.querySelector('form');
    
    form.addEventListener('change', function() {
        formChanged = true;
    });
    
    // Warn before leaving if changes are unsaved
    window.addEventListener('beforeunload', function(e) {
        if (formChanged) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
    
    // Reset form changed flag after successful submission
    form.addEventListener('submit', function() {
        formChanged = false;
    });
</script>
@endpush
