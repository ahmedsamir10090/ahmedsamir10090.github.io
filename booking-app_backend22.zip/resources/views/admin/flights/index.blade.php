@extends('layouts.admin')

@section('title', 'إدارة الرحلات')
@section('header', 'إدارة الرحلات')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0">الرحلات</h5>
        <small class="text-muted">إدارة رحلات الطيران</small>
    </div>
    <a href="{{ route('admin.flights.create') }}" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>إضافة رحلة جديدة
    </a>
</div>
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    {{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="card shadow">
    <div class="card-body">
        @if($flights->count() > 0)
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>الرقم</th>
                            <th>رقم الرحلة</th>
                            <th>الوكالة</th>
                            <th>المسار</th>
                            <th>المغادرة</th>
                            <th>سعر البالغين</th>
                            <th>سعر الأطفال</th>
                            <th>المقاعد</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($flights as $flight)
                            <tr>
                                <td>{{ $flight->id }}</td>
                                <td class="fw-semibold">{{ $flight->flight_number }}</td>
                                <td>{{ $flight->agency->name ?? 'غير محدد' }}</td>
                                <td>
                                    {{ $flight->origin }} &larr; {{ $flight->destination }}
                                </td>
                                <td>
                                    {{ optional($flight->departure_time)->format('Y-m-d H:i') }}
                                </td>
                                <td>${{ number_format($flight->adult_price ?? $flight->price, 2) }}</td>
                                <td>${{ number_format($flight->child_price ?? $flight->price * 0.7, 2) }}</td>
                                <td>{{ $flight->available_seats }}</td>
                                <td>
                                    @if($flight->status === 'active')
                                        <span class="badge bg-success">نشطة</span>
                                    @elseif($flight->status === 'pending')
                                        <span class="badge bg-warning">قيد الانتظار</span>
                                    @else
                                        <span class="badge bg-danger">ملغاة</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('admin.flights.show', $flight->id) }}" class="btn btn-sm btn-info" title="عرض">
                                            <i class="fas fa-eye"></i>  عرض
                                        </a>
                                        <a href="{{ route('admin.flights.edit', $flight->id) }}" class="btn btn-sm btn-primary" title="تعديل">
                                            <i class="fas fa-edit"></i> تعديل
                                        </a>
                                        <form action="{{ route('admin.flights.destroy', $flight->id) }}" method="POST" class="d-inline"
                                              onsubmit="return confirm('هل أنت متأكد من حذف هذه الرحلة؟')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger" title="حذف">
                                                <i class="fas fa-trash"></i> حذف
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                {{ $flights->links() }}
            </div>
        @else
            <div class="text-center py-5">
                <i class="fas fa-plane fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">لا توجد رحلات</h5>
                <p class="text-muted">سوف تظهر الرحلات هنا بعد إضافتها</p>
                <a href="{{ route('admin.flights.create') }}" class="btn btn-primary mt-2">
                    <i class="fas fa-plus me-1"></i> إضافة رحلة جديدة
                </a>
            </div>
        @endif
    </div>
</div>
@endsection
