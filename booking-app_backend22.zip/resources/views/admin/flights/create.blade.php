@extends('layouts.admin')

@section('title', __('Create Flight'))
@section('header', __('Create Flight'))

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
@endpush

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0">{{ __('Create Flight') }}</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.flights.store') }}" method="POST">
                    @csrf

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="agency_id">{{ __('Agency') }}</label>
                            <select class="form-select @error('agency_id') is-invalid @enderror" id="agency_id" name="agency_id" required>
                                <option value="">{{ __('Select agency') }}</option>
                                @foreach($agencies as $agency)
                                    <option value="{{ $agency->id }}" {{ old('agency_id') == $agency->id ? 'selected' : '' }}>
                                        {{ $agency->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('agency_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="flight_number">{{ __('Flight Number') }}</label>
                            <input type="text" class="form-control @error('flight_number') is-invalid @enderror" id="flight_number" name="flight_number" value="{{ old('flight_number') }}" required>
                            @error('flight_number')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="flight_type">{{ __('Flight Type') }}</label>
                            <select class="form-select @error('flight_type') is-invalid @enderror" id="flight_type" name="flight_type" required>
                                <option value="air" {{ old('flight_type', 'air') === 'air' ? 'selected' : '' }}>{{ __('Air Flight') }}</option>
                                <option value="sea" {{ old('flight_type') === 'sea' ? 'selected' : '' }}>{{ __('Sea Travel') }}</option>
                            </select>
                            @error('flight_type')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="origin_airport_id">{{ __('Origin Airport') }}</label>
                            <select class="form-select select2 @error('origin_airport_id') is-invalid @enderror" id="origin_airport_id" name="origin_airport_id" required>
                                <option value="">{{ __('Select Origin Airport') }}</option>
                                @foreach($countries as $country)
                                    <optgroup label="{{ $country->name }}">
                                        @foreach($country->airports as $airport)
                                            <option value="{{ $airport->id }}" {{ old('origin_airport_id') == $airport->id ? 'selected' : '' }}>
                                                {{ $airport->name }} ({{ $airport->iata_code }})
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            </select>
                            @error('origin_airport_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="destination_airport_id">{{ __('Destination Airport') }}</label>
                            <select class="form-select select2 @error('destination_airport_id') is-invalid @enderror" id="destination_airport_id" name="destination_airport_id" required>
                                <option value="">{{ __('Select Destination Airport') }}</option>
                                @foreach($countries as $country)
                                    <optgroup label="{{ $country->name }}">
                                        @foreach($country->airports as $airport)
                                            <option value="{{ $airport->id }}" {{ old('destination_airport_id') == $airport->id ? 'selected' : '' }}>
                                                {{ $airport->name }} ({{ $airport->iata_code }})
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            </select>
                            @error('destination_airport_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="departure_time">{{ __('Departure Time') }}</label>
                            <input type="datetime-local" class="form-control @error('departure_time') is-invalid @enderror" id="departure_time" name="departure_time" value="{{ old('departure_time') }}" required>
                            @error('departure_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="arrival_time">{{ __('Arrival Time') }}</label>
                            <input type="datetime-local" class="form-control @error('arrival_time') is-invalid @enderror" id="arrival_time" name="arrival_time" value="{{ old('arrival_time') }}" required>
                            @error('arrival_time')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="price">{{ __('Price') }}</label>
                            <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}" required>
                            @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="available_seats">{{ __('Available Seats') }}</label>
                            <input type="number" class="form-control @error('available_seats') is-invalid @enderror" id="available_seats" name="available_seats" value="{{ old('available_seats') }}" required>
                            @error('available_seats')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="status">{{ __('Status') }}</label>
                            <select class="form-select @error('status') is-invalid @enderror" id="status" name="status" required>
                                @foreach(['pending' => __('Pending'), 'active' => __('Active'), 'cancelled' => __('Cancelled')] as $value => $label)
                                    <option value="{{ $value }}" {{ old('status', 'pending') === $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                            @error('status')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="{{ route('admin.flights.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>{{ __('Back to Flights') }}
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>{{ __('Create Flight') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: '100%',
            dir: '{{ app()->getLocale() === 'ar' ? 'rtl' : 'ltr' }}',
            language: {
                noResults: function() {
                    return '{{ __('No results found') }}';
                },
                searching: function() {
                    return '{{ __('Searching...') }}';
                }
            }
        });
    });
</script>
@endpush