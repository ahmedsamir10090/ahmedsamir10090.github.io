@extends('layouts.admin')

@section('title', isset($flight) ? 'تعديل رحلة' : 'إضافة رحلة جديدة')
@section('header', isset($flight) ? 'تعديل رحلة' : 'إضافة رحلة جديدة')

@push('styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
@endpush

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <form method="POST" action="{{ isset($flight) ? route('admin.flights.update', $flight) : route('admin.flights.store') }}">
                        @csrf
                        @if(isset($flight))
                            @method('PUT')
                        @endif
                        
                        <!-- معلومات الرحلة الأساسية -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">معلومات الرحلة الأساسية</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="flight_number" class="form-label">رقم الرحلة <span class="text-danger">*</span></label>
                                    <input type="text" 
                                           class="form-control @error('flight_number') is-invalid @enderror" 
                                           id="flight_number" 
                                           name="flight_number" 
                                           value="{{ old('flight_number', $flight->flight_number ?? '') }}" 
                                           required>
                                    @error('flight_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="flight_type" class="form-label">نوع الرحلة <span class="text-danger">*</span></label>
                                    <select class="form-select @error('flight_type') is-invalid @enderror" 
                                            id="flight_type" 
                                            name="flight_type" 
                                            required>
                                        <option value="air" {{ old('flight_type', $flight->flight_type ?? 'air') === 'air' ? 'selected' : '' }}>
                                            <i class="fas fa-plane"></i> رحلة طيران
                                        </option>
                                        <option value="sea" {{ old('flight_type', $flight->flight_type ?? '') === 'sea' ? 'selected' : '' }}>
                                            <i class="fas fa-ship"></i> رحلة بحرية
                                        </option>
                                    </select>
                                    @error('flight_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="row">
                                    <label for="agency_id" class="form-label">الوكالة</label>
                                    <select class="form-select select2 @error('agency_id') is-invalid @enderror" 
                                            id="agency_id" 
                                            name="agency_id">
                                        <option value="">بدون وكالة (إدارة مباشرة)</option>
                                        @foreach($agencies as $agency)
                                            <option value="{{ $agency->id }}" {{ old('agency_id', $flight->agency_id ?? '') == $agency->id ? 'selected' : '' }}>
                                                {{ $agency->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <small class="text-muted">اختر الوكالة المسؤولة عن هذه الرحلة</small>
                                    @error('agency_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="status" class="form-label">الحالة <span class="text-danger">*</span></label>
                                    <select class="form-select @error('status') is-invalid @enderror" 
                                            id="status" 
                                            name="status" 
                                            required>
                                        <option value="active" {{ old('status', $flight->status ?? '') === 'active' ? 'selected' : '' }}>نشطة</option>
                                        <option value="pending" {{ old('status', $flight->status ?? '') === 'pending' ? 'selected' : '' }}>قيد الانتظار</option>
                                        <option value="cancelled" {{ old('status', $flight->status ?? '') === 'cancelled' ? 'selected' : '' }}>ملغاة</option>
                                    </select>
                                    @error('status')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="available_seats" class="form-label">عدد المقاعد المتاحة <span class="text-danger">*</span></label>
                                    <input type="number" 
                                           class="form-control @error('available_seats') is-invalid @enderror" 
                                           id="available_seats" 
                                           name="available_seats" 
                                           value="{{ old('available_seats', $flight->available_seats ?? '') }}" 
                                           min="1" 
                                           required>
                                    @error('available_seats')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="row">
                                <!-- حقول المطارات (رحلات طيران) -->
                                <div class="col-md-6 airports-section">
                                    <label class="form-label" id="origin-label-air">مطار المغادرة <span class="text-danger">*</span></label>
                                    <select name="origin_airport_id" id="origin_airport_id" class="form-select select2 @error('origin_airport_id') is-invalid @enderror">
                                        <option value="">اختر مطار المغادرة</option>
                                        @foreach($countries as $country)
                                            <optgroup label="{{ $country->name }}">
                                                @foreach($country->airports as $airport)
                                                    <option value="{{ $airport->id }}" {{ old('origin_airport_id', $flight->origin_airport_id ?? '') == $airport->id ? 'selected' : '' }}>
                                                        {{ $airport->name }} ({{ $airport->iata_code }})
                                                    </option>
                                                @endforeach
                                            </optgroup>
                                        @endforeach
                                    </select>
                                    @error('origin_airport_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <!-- حقول الموانئ (رحلات بحرية) -->
                                <div class="col-md-6 ports-section" style="display: none;">
                                    <label class="form-label" id="origin-label-sea">ميناء المغادرة <span class="text-danger">*</span></label>
                                    <select name="origin_port_id" id="origin_port_id" class="form-select select2 @error('origin_port_id') is-invalid @enderror">
                                        <option value="">اختر ميناء المغادرة</option>
                                        @foreach($countries as $country)
                                            @if($country->ports->count() > 0)
                                                <optgroup label="{{ $country->name }}">
                                                    @foreach($country->ports as $port)
                                                        <option value="{{ $port->id }}" {{ old('origin_port_id', $flight->origin_port_id ?? '') == $port->id ? 'selected' : '' }}>
                                                            {{ $port->name }} ({{ $port->code }})
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endif
                                        @endforeach
                                    </select>
                                    @error('origin_port_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <!-- حقول المطارات (وجهة) -->
                                <div class="col-md-6 airports-section">
                                    <label class="form-label" id="dest-label-air">مطار الوصول <span class="text-danger">*</span></label>
                                    <select name="destination_airport_id" id="destination_airport_id" class="form-select select2 @error('destination_airport_id') is-invalid @enderror">
                                        <option value="">اختر مطار الوصول</option>
                                        @foreach($countries as $country)
                                            <optgroup label="{{ $country->name }}">
                                                @foreach($country->airports as $airport)
                                                    <option value="{{ $airport->id }}" {{ old('destination_airport_id', $flight->destination_airport_id ?? '') == $airport->id ? 'selected' : '' }}>
                                                        {{ $airport->name }} ({{ $airport->iata_code }})
                                                    </option>
                                                @endforeach
                                            </optgroup>
                                        @endforeach
                                    </select>
                                    @error('destination_airport_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <!-- حقول الموانئ (وجهة) -->
                                <div class="col-md-6 ports-section" style="display: none;">
                                    <label class="form-label" id="dest-label-sea">ميناء الوصول <span class="text-danger">*</span></label>
                                    <select name="destination_port_id" id="destination_port_id" class="form-select select2 @error('destination_port_id') is-invalid @enderror">
                                        <option value="">اختر ميناء الوصول</option>
                                        @foreach($countries as $country)
                                            @if($country->ports->count() > 0)
                                                <optgroup label="{{ $country->name }}">
                                                    @foreach($country->ports as $port)
                                                        <option value="{{ $port->id }}" {{ old('destination_port_id', $flight->destination_port_id ?? '') == $port->id ? 'selected' : '' }}>
                                                            {{ $port->name }} ({{ $port->code }})
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endif
                                        @endforeach
                                    </select>
                                    @error('destination_port_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="departure_time" class="form-label">وقت المغادرة <span class="text-danger">*</span></label>
                                    <input type="datetime-local" 
                                           class="form-control @error('departure_time') is-invalid @enderror" 
                                           id="departure_time" 
                                           name="departure_time" 
                                           value="{{ old('departure_time', isset($flight) ? $flight->departure_time->format('Y-m-d\TH:i') : '') }}" 
                                           required>
                                    @error('departure_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="arrival_time" class="form-label">وقت الوصول <span class="text-danger">*</span></label>
                                    <input type="datetime-local" 
                                           class="form-control @error('arrival_time') is-invalid @enderror" 
                                           id="arrival_time" 
                                           name="arrival_time" 
                                           value="{{ old('arrival_time', isset($flight) ? $flight->arrival_time->format('Y-m-d\TH:i') : '') }}" 
                                           required>
                                    @error('arrival_time')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            
                            {{-- <div class="col-md-6 mb-3">
                                <label for="available_seats" class="form-label">عدد المقاعد المتاحة <span class="text-danger">*</span></label>
                                <input type="number" 
                                       class="form-control @error('available_seats') is-invalid @enderror" 
                                       id="available_seats" 
                                       name="available_seats" 
                                       value="{{ old('available_seats', $flight->available_seats ?? '') }}" 
                                       min="1" 
                                       required>
                                @error('available_seats')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div> --}}
                        
                        <hr class="my-4">
                        
                        <!-- أسعار البالغين والأطفال -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">أسعار التذاكر</h5>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="price" class="form-label">السعر الأساسي <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">$</span>
                                        <input type="number" 
                                               class="form-control @error('price') is-invalid @enderror" 
                                               id="price" 
                                               name="price" 
                                               value="{{ old('price', $flight->price ?? '') }}" 
                                               step="0.01" 
                                               min="0" 
                                               required>
                                    </div>
                                    <small class="text-muted">يستخدم كسعر افتراضي</small>
                                    @error('price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="adult_price" class="form-label">سعر البالغين <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">$</span>
                                        <input type="number" 
                                               class="form-control @error('adult_price') is-invalid @enderror" 
                                               id="adult_price" 
                                               name="adult_price" 
                                               value="{{ old('adult_price', $flight->adult_price ?? '') }}" 
                                               step="0.01" 
                                               min="0" 
                                               required>
                                    </div>
                                    @error('adult_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="child_price" class="form-label">سعر الأطفال <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">$</span>
                                        <input type="number" 
                                               class="form-control @error('child_price') is-invalid @enderror" 
                                               id="child_price" 
                                               name="child_price" 
                                               value="{{ old('child_price', $flight->child_price ?? '') }}" 
                                               step="0.01" 
                                               min="0" 
                                               required>
                                    </div>
                                    @error('child_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <!-- أسعار الأمتعة -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">أسعار الأمتعة حسب الوزن</h5>
                            <p class="text-muted small">أضف أسعار مختلفة حسب وزن الأمتعة (مثال: 30 كجم، 45 كجم، 60 كجم)</p>
                            
                            <div id="baggage-prices-container">
                                @php
                                    $baggagePrices = old('baggage_prices', isset($flight) ? $flight->baggage_prices : []);
                                    $baggagePrices = is_array($baggagePrices) ? $baggagePrices : [];
                                @endphp
                                
                                @if(count($baggagePrices) > 0)
                                    @foreach($baggagePrices as $weight => $price)
                                        <div class="row mb-2 baggage-price-row">
                                            <div class="col-md-5">
                                                <div class="input-group">
                                                    <input type="number" 
                                                           class="form-control" 
                                                           name="baggage_weights[]" 
                                                           value="{{ $weight }}" 
                                                           placeholder="الوزن (كجم)" 
                                                           min="1">
                                                    <span class="input-group-text">كجم</span>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="number" 
                                                           class="form-control" 
                                                           name="baggage_weight_prices[]" 
                                                           value="{{ $price }}" 
                                                           placeholder="السعر" 
                                                           step="0.01" 
                                                           min="0">
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" class="btn btn-danger w-100 remove-baggage-row">حذف</button>
                                            </div>
                                        </div>
                                    @endforeach
                                @else
                                    <div class="row mb-2 baggage-price-row">
                                        <div class="col-md-5">
                                            <div class="input-group">
                                                <input type="number" 
                                                       class="form-control" 
                                                       name="baggage_weights[]" 
                                                       placeholder="الوزن (كجم)" 
                                                       min="1">
                                                <span class="input-group-text">كجم</span>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="input-group">
                                                <span class="input-group-text">$</span>
                                                <input type="number" 
                                                       class="form-control" 
                                                       name="baggage_weight_prices[]" 
                                                       placeholder="السعر" 
                                                       step="0.01" 
                                                       min="0">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger w-100 remove-baggage-row">حذف</button>
                                        </div>
                                    </div>
                                @endif
                            </div>
                            
                            <button type="button" id="add-baggage-row" class="btn btn-outline-primary mt-2">
                                <i class="fas fa-plus"></i> إضافة وزن جديد
                            </button>
                        </div>
                        
                        <hr class="my-4">
                        
                        <!-- أزرار الإرسال -->
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="fas fa-save me-1"></i>
                                {{ isset($flight) ? 'تحديث الرحلة' : 'إضافة الرحلة' }}
                            </button>
                            <a href="{{ route('admin.flights.index') }}" class="btn btn-secondary px-4">
                                <i class="fas fa-times me-1"></i>
                                إلغاء
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    // Initialize Select2
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: '100%',
            dir: 'rtl',
            language: {
                noResults: function() {
                    return 'لم يتم العثور على نتائج';
                },
                searching: function() {
                    return 'جاري البحث...';
                }
            }
        });
        
        // التبديل بين المطارات والموانئ حسب نوع الرحلة
        function toggleLocationType() {
            const flightType = $('#flight_type').val();
            
            if (flightType === 'sea') {
                // إظهار الموانئ وإخفاء المطارات
                $('.airports-section').hide();
                $('.ports-section').show();
                
                // تعطيل حقول المطارات وتفعيل حقول الموانئ
                $('#origin_airport_id').prop('required', false).prop('disabled', true);
                $('#destination_airport_id').prop('required', false).prop('disabled', true);
                $('#origin_port_id').prop('required', true).prop('disabled', false);
                $('#destination_port_id').prop('required', true).prop('disabled', false);
            } else {
                // إظهار المطارات وإخفاء الموانئ
                $('.airports-section').show();
                $('.ports-section').hide();
                
                // تفعيل حقول المطارات وتعطيل حقول الموانئ
                $('#origin_airport_id').prop('required', true).prop('disabled', false);
                $('#destination_airport_id').prop('required', true).prop('disabled', false);
                $('#origin_port_id').prop('required', false).prop('disabled', true);
                $('#destination_port_id').prop('required', false).prop('disabled', true);
            }
        }
        
        // تشغيل عند تحميل الصفحة
        toggleLocationType();
        
        // تشغيل عند تغيير نوع الرحلة
        $('#flight_type').on('change', function() {
            toggleLocationType();
        });
    });
    
    // إضافة صف جديد لأسعار الأمتعة
    document.getElementById('add-baggage-row').addEventListener('click', function() {
        const container = document.getElementById('baggage-prices-container');
        const newRow = document.createElement('div');
        newRow.className = 'row mb-2 baggage-price-row';
        newRow.innerHTML = `
            <div class="col-md-5">
                <div class="input-group">
                    <input type="number" 
                           class="form-control" 
                           name="baggage_weights[]" 
                           placeholder="الوزن (كجم)" 
                           min="1">
                    <span class="input-group-text">كجم</span>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" 
                           class="form-control" 
                           name="baggage_weight_prices[]" 
                           placeholder="السعر" 
                           step="0.01" 
                           min="0">
                </div>
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-danger w-100 remove-baggage-row">حذف</button>
            </div>
        `;
        container.appendChild(newRow);
        attachRemoveHandler(newRow.querySelector('.remove-baggage-row'));
    });
    
    // حذف صف
    function attachRemoveHandler(button) {
        button.addEventListener('click', function() {
            this.closest('.baggage-price-row').remove();
        });
    }
    
    // ربط أزرار الحذف الموجودة
    document.querySelectorAll('.remove-baggage-row').forEach(button => {
        attachRemoveHandler(button);
    });
</script>
@endpush
