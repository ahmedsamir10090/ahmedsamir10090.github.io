@extends('layouts.admin')

@section('title', 'تفاصيل الرحلة')
@section('header', 'تفاصيل الرحلة')

@section('content')
<div class="container-fluid">
    <div class="row mb-3">
        <div class="col-md-12">
            <a href="{{ route('admin.flights.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-right me-1"></i> العودة إلى القائمة
            </a>
            <a href="{{ route('admin.flights.edit', $flight) }}" class="btn btn-primary">
                <i class="fas fa-edit me-1"></i> تعديل الرحلة
            </a>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <!-- معلومات الرحلة -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plane me-2"></i>معلومات الرحلة</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6 class="text-muted">رقم الرحلة</h6>
                            <p class="h5">{{ $flight->flight_number }}</p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">الحالة</h6>
                            <p>
                                @if($flight->status === 'active')
                                    <span class="badge bg-success fs-6">نشطة</span>
                                @elseif($flight->status === 'pending')
                                    <span class="badge bg-warning fs-6">قيد الانتظار</span>
                                @else
                                    <span class="badge bg-danger fs-6">ملغاة</span>
                                @endif
                            </p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6 class="text-muted">من</h6>
                            <p class="h6"><i class="fas fa-map-marker-alt text-primary me-2"></i>{{ $flight->origin }}</p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">إلى</h6>
                            <p class="h6"><i class="fas fa-map-marker-alt text-danger me-2"></i>{{ $flight->destination }}</p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6 class="text-muted">وقت المغادرة</h6>
                            <p><i class="fas fa-clock me-2"></i>{{ $flight->departure_time->format('Y-m-d H:i') }}</p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">وقت الوصول</h6>
                            <p><i class="fas fa-clock me-2"></i>{{ $flight->arrival_time->format('Y-m-d H:i') }}</p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-muted">عدد المقاعد المتاحة</h6>
                            <p class="h5">
                                <span class="badge bg-info">{{ $flight->available_seats }}</span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            @if($flight->agency)
                                <h6 class="text-muted">الوكالة</h6>
                                <p>{{ $flight->agency->name }}</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <!-- الأسعار -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-dollar-sign me-2"></i>الأسعار</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="text-muted">السعر الأساسي</h6>
                        <p class="h4 text-primary">${{ number_format($flight->price, 2) }}</p>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-3">
                        <h6 class="text-muted">سعر البالغين</h6>
                        <p class="h5 text-success">${{ number_format($flight->adult_price, 2) }}</p>
                    </div>
                    
                    <div class="mb-3">
                        <h6 class="text-muted">سعر الأطفال</h6>
                        <p class="h5 text-info">${{ number_format($flight->child_price, 2) }}</p>
                    </div>
                    
                    @if(!empty($flight->baggage_prices))
                        <hr>
                        <h6 class="text-muted mb-3">أسعار الأمتعة</h6>
                        @foreach($flight->baggage_prices as $weight => $price)
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span><i class="fas fa-suitcase me-2"></i>{{ $weight }} كجم</span>
                                <span class="badge bg-secondary">${{ number_format($price, 2) }}</span>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>
    
    <!-- الحجوزات -->
    <div class="card shadow-sm">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-ticket-alt me-2"></i>الحجوزات ({{ $flight->bookings->count() }})</h5>
        </div>
        <div class="card-body">
            @if($flight->bookings->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>رقم الحجز</th>
                                <th>اسم المسافر</th>
                                <th>نوع المسافر</th>
                                <th>عدد المقاعد</th>
                                <th>الإجمالي</th>
                                <th>حالة الدفع</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($flight->bookings as $booking)
                                <tr>
                                    <td>
                                        <a href="{{ route('admin.bookings.show', $booking) }}" class="text-decoration-none">
                                            #{{ $booking->id }}
                                        </a>
                                    </td>
                                    <td>
                                        @if($booking->passenger_first_name)
                                            {{ $booking->passenger_title === 'mr' ? 'السيد' : ($booking->passenger_title === 'ms' ? 'الآنسة' : 'السيدة') }}
                                            {{ $booking->passenger_first_name }} 
                                            {{ $booking->passenger_middle_name }} 
                                            {{ $booking->passenger_last_name }}
                                        @else
                                            {{ $booking->user->name }}
                                        @endif
                                    </td>
                                    <td>
                                        @if($booking->passenger_type === 'adult')
                                            <span class="badge bg-primary">بالغ</span>
                                        @else
                                            <span class="badge bg-info">طفل</span>
                                        @endif
                                    </td>
                                    <td>{{ $booking->seats_count }}</td>
                                    <td>${{ number_format($booking->total_price, 2) }}</td>
                                    <td>
                                        @if($booking->payment_status === 'paid')
                                            <span class="badge bg-success">مدفوع</span>
                                        @elseif($booking->payment_status === 'pending')
                                            <span class="badge bg-warning">قيد المراجعة</span>
                                        @else
                                            <span class="badge bg-danger">غير مدفوع</span>
                                        @endif
                                    </td>
                                    <td>{{ $booking->created_at->format('Y-m-d') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="text-center py-4">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <p class="text-muted">لا توجد حجوزات لهذه الرحلة حتى الآن</p>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
