@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>حجز رحلة جديدة - منصة حجوزات السودان</title>
    
    <!-- Google Fonts - Cairo -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .booking-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .booking-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .booking-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .booking-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
        }
        
        .booking-body {
            padding: 40px 30px;
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #667eea;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            padding: 12px 15px;
            border-radius: 10px;
            border: 2px solid #e0e0e0;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .btn-submit {
            width: 100%;
            padding: 14px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        
        .price-badge {
            background: #f0f0f0;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            margin-top: 20px;
        }
        
        .price-badge h4 {
            color: #667eea;
            font-weight: 700;
            margin: 0;
        }
        
        .required-mark {
            color: #e74a3b;
        }
    </style>
</head>
<body>
    <div class="booking-container">
        <div class="booking-card">
            <div class="booking-header">
                <h2>حجز رحلة جديدة</h2>
                <p class="mb-0">املأ البيانات التالية لإتمام الحجز</p>
            </div>
            
            <div class="booking-body">
                <form method="POST" action="{{ route('bookings.store') }}" enctype="multipart/form-data" id="bookingForm">
                    @csrf
                    
                    <!-- اختيار الرحلة -->
                    <div class="mb-5">
                        <h3 class="section-title">📍 معلومات الرحلة</h3>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="flight_id" class="form-label">الرحلة <span class="required-mark">*</span></label>
                                <select name="serviceable_id" id="flight_id" class="form-select @error('serviceable_id') is-invalid @enderror" required>
                                    <option value="">-- اختر الرحلة --</option>
                                    @foreach($flights as $flight)
                                        <option value="{{ $flight->id }}" 
                                                data-adult-price="{{ $flight->adult_price ?? $flight->price }}"
                                                data-child-price="{{ $flight->child_price ?? $flight->price }}"
                                                data-baggage-prices="{{ json_encode($flight->baggage_prices ?? []) }}">
                                            {{ $flight->flight_number }} - من {{ $flight->origin }} إلى {{ $flight->destination }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('serviceable_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <input type="hidden" name="serviceable_type" value="App\Models\Flight">
                        </div>
                    </div>
                    
                    <!-- المعلومات الشخصية -->
                    <div class="mb-5">
                        <h3 class="section-title">👤 المعلومات الشخصية للمسافر</h3>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="passenger_title" class="form-label">اللقب <span class="required-mark">*</span></label>
                                <select name="passenger_title" id="passenger_title" class="form-select @error('passenger_title') is-invalid @enderror" required>
                                    <option value="">-- اختر --</option>
                                    <option value="السيد">السيد</option>
                                    <option value="الآنسة">الآنسة</option>
                                    <option value="السيدة">السيدة</option>
                                </select>
                                @error('passenger_title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_first_name" class="form-label">الاسم الأول <span class="required-mark">*</span></label>
                                <input type="text" name="passenger_first_name" id="passenger_first_name" class="form-control @error('passenger_first_name') is-invalid @enderror" required>
                                @error('passenger_first_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_middle_name" class="form-label">الاسم الأوسط</label>
                                <input type="text" name="passenger_middle_name" id="passenger_middle_name" class="form-control @error('passenger_middle_name') is-invalid @enderror">
                                @error('passenger_middle_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="passenger_last_name" class="form-label">اسم العائلة <span class="required-mark">*</span></label>
                                <input type="text" name="passenger_last_name" id="passenger_last_name" class="form-control @error('passenger_last_name') is-invalid @enderror" required>
                                @error('passenger_last_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="passenger_date_of_birth" class="form-label">تاريخ الميلاد <span class="required-mark">*</span></label>
                                <input type="date" name="passenger_date_of_birth" id="passenger_date_of_birth" class="form-control @error('passenger_date_of_birth') is-invalid @enderror" required>
                                @error('passenger_date_of_birth')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passenger_nationality" class="form-label">الجنسية <span class="required-mark">*</span></label>
                                <input type="text" name="passenger_nationality" id="passenger_nationality" class="form-control @error('passenger_nationality') is-invalid @enderror" required>
                                @error('passenger_nationality')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passenger_type" class="form-label">نوع المسافر <span class="required-mark">*</span></label>
                                <select name="passenger_type" id="passenger_type" class="form-select @error('passenger_type') is-invalid @enderror" required>
                                    <option value="adult">بالغ</option>
                                    <option value="child">طفل</option>
                                </select>
                                @error('passenger_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    
                    <!-- بيانات الاتصال -->
                    <div class="mb-5">
                        <h3 class="section-title">📞 بيانات الاتصال</h3>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="passenger_phone" class="form-label">رقم الجوال <span class="required-mark">*</span></label>
                                <input type="tel" name="passenger_phone" id="passenger_phone" class="form-control @error('passenger_phone') is-invalid @enderror" placeholder="+249XXXXXXXXX" required>
                                @error('passenger_phone')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label for="passenger_whatsapp" class="form-label">رقم الواتساب</label>
                                <input type="tel" name="passenger_whatsapp" id="passenger_whatsapp" class="form-control @error('passenger_whatsapp') is-invalid @enderror" placeholder="+249XXXXXXXXX">
                                @error('passenger_whatsapp')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    
                    <!-- وثائق السفر -->
                    <div class="mb-5">
                        <h3 class="section-title">🛂 وثائق السفر</h3>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="passport_number" class="form-label">رقم الجواز <span class="required-mark">*</span></label>
                                <input type="text" name="passport_number" id="passport_number" class="form-control @error('passport_number') is-invalid @enderror" required>
                                @error('passport_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passport_issuing_country" class="form-label">بلد الإصدار <span class="required-mark">*</span></label>
                                <input type="text" name="passport_issuing_country" id="passport_issuing_country" class="form-control @error('passport_issuing_country') is-invalid @enderror" required>
                                @error('passport_issuing_country')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="passport_expiry_date" class="form-label">تاريخ الانتهاء <span class="required-mark">*</span></label>
                                <input type="date" name="passport_expiry_date" id="passport_expiry_date" class="form-control @error('passport_expiry_date') is-invalid @enderror" required>
                                @error('passport_expiry_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-12 mb-3">
                                <label for="passport_image" class="form-label">رفع صورة الجواز <span class="required-mark">*</span></label>
                                <input type="file" name="passport_image" id="passport_image" class="form-control @error('passport_image') is-invalid @enderror" accept="image/*" required>
                                <small class="text-muted">يرجى رفع صورة واضحة للجواز (PNG, JPG, JPEG - بحد أقصى 2MB)</small>
                                @error('passport_image')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    
                    <!-- خيارات الأمتعة -->
                    <div class="mb-5">
                        <h3 class="section-title">🧳 وزن الأمتعة</h3>
                        
                        <div class="row">
                            <div class="col-12 mb-3">
                                <label for="selected_baggage_weight" class="form-label">اختر وزن الأمتعة <span class="required-mark">*</span></label>
                                <select name="selected_baggage_weight" id="selected_baggage_weight" class="form-select @error('selected_baggage_weight') is-invalid @enderror" required>
                                    <option value="">-- اختر الوزن --</option>
                                </select>
                                @error('selected_baggage_weight')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    
                    <!-- ملخص السعر -->
                    <div class="price-badge">
                        <p class="mb-2 text-muted">إجمالي السعر</p>
                        <h4 id="total_price_display">$0.00</h4>
                        <input type="hidden" name="total_price" id="total_price" value="0">
                    </div>
                    
                    <!-- زر الإرسال -->
                    <div class="mt-4">
                        <button type="submit" class="btn btn-submit">تأكيد الحجز</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // حساب السعر تلقائياً
        const flightSelect = document.getElementById('flight_id');
        const passengerTypeSelect = document.getElementById('passenger_type');
        const baggageSelect = document.getElementById('selected_baggage_weight');
        const totalPriceDisplay = document.getElementById('total_price_display');
        const totalPriceInput = document.getElementById('total_price');
        
        flightSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const baggagePrices = JSON.parse(selectedOption.dataset.baggagePrices || '{}');
            
            // ملء خيارات الوزن
            baggageSelect.innerHTML = '<option value="">-- اختر الوزن --</option>';
            for (const [weight, price] of Object.entries(baggagePrices)) {
                const option = document.createElement('option');
                option.value = weight;
                option.textContent = `${weight} كجم - $${price}`;
                option.dataset.price = price;
                baggageSelect.appendChild(option);
            }
            
            calculatePrice();
        });
        
        passengerTypeSelect.addEventListener('change', calculatePrice);
        baggageSelect.addEventListener('change', calculatePrice);
        
        function calculatePrice() {
            const flightOption = flightSelect.options[flightSelect.selectedIndex];
            const passengerType = passengerTypeSelect.value;
            const baggageOption = baggageSelect.options[baggageSelect.selectedIndex];
            
            if (!flightOption || !flightOption.value) {
                totalPriceDisplay.textContent = '$0.00';
                totalPriceInput.value = '0';
                return;
            }
            
            let basePrice = 0;
            if (passengerType === 'adult') {
                basePrice = parseFloat(flightOption.dataset.adultPrice || 0);
            } else {
                basePrice = parseFloat(flightOption.dataset.childPrice || 0);
            }
            
            let baggagePrice = 0;
            if (baggageOption && baggageOption.value) {
                baggagePrice = parseFloat(baggageOption.dataset.price || 0);
            }
            
            const totalPrice = basePrice + baggagePrice;
            totalPriceDisplay.textContent = `$${totalPrice.toFixed(2)}`;
            totalPriceInput.value = totalPrice.toFixed(2);
        }
    </script>
</body>
</html>
@endsection
