@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>تفاصيل الحجز - منصة حجوزات السودان</title>
    
    <!-- Google Fonts - Cairo -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .booking-details-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .details-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .details-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .details-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0 0 10px 0;
        }
        
        .status-badge {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .details-body {
            padding: 30px;
        }
        
        .section-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: #667eea;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-row {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #666;
            min-width: 200px;
        }
        
        .info-value {
            color: #333;
            flex: 1;
        }
        
        .passport-image {
            max-width: 100%;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .price-summary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
        }
        
        .price-summary h3 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn-custom {
            flex: 1;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            border: none;
            transition: transform 0.3s ease;
        }
        
        .btn-custom:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="booking-details-container">
        <!-- معلومات الحجز الأساسية -->
        <div class="details-card">
            <div class="details-header">
                <h2>تفاصيل الحجز #{{ $booking->id }}</h2>
                <span class="status-badge bg-{{ 
                    $booking->status === 'completed' ? 'success' : 
                    ($booking->status === 'pending' ? 'warning' : 
                    ($booking->status === 'accepted' ? 'info' : 'danger'))
                }}">
                    {{ __($booking->status) }}
                </span>
            </div>
            
            <div class="details-body">
                <!-- معلومات الرحلة -->
                <div class="mb-4">
                    <h3 class="section-title">
                        <span>✈️</span> معلومات الرحلة
                    </h3>
                    
                    @if($booking->serviceable_type === 'App\Models\Flight')
                        <div class="info-row">
                            <div class="info-label">رقم الرحلة:</div>
                            <div class="info-value">{{ $booking->serviceable->flight_number }}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">المسار:</div>
                            <div class="info-value">من {{ $booking->serviceable->origin }} إلى {{ $booking->serviceable->destination }}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">وقت المغادرة:</div>
                            <div class="info-value">{{ $booking->serviceable->departure_time->format('Y-m-d H:i') }}</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">وقت الوصول:</div>
                            <div class="info-value">{{ $booking->serviceable->arrival_time->format('Y-m-d H:i') }}</div>
                        </div>
                    @endif
                    
                    <div class="info-row">
                        <div class="info-label">تاريخ الحجز:</div>
                        <div class="info-value">{{ $booking->created_at->format('Y-m-d H:i') }}</div>
                    </div>
                </div>
                
                <!-- المعلومات الشخصية للمسافر -->
                <div class="mb-4">
                    <h3 class="section-title">
                        <span>👤</span> المعلومات الشخصية للمسافر
                    </h3>
                    
                    <div class="info-row">
                        <div class="info-label">اللقب:</div>
                        <div class="info-value">{{ $booking->passenger_title }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">الاسم الكامل:</div>
                        <div class="info-value">
                            {{ $booking->passenger_first_name }} 
                            {{ $booking->passenger_middle_name }} 
                            {{ $booking->passenger_last_name }}
                        </div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">تاريخ الميلاد:</div>
                        <div class="info-value">{{ $booking->passenger_date_of_birth ? $booking->passenger_date_of_birth->format('Y-m-d') : 'غير محدد' }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">الجنسية:</div>
                        <div class="info-value">{{ $booking->passenger_nationality }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">نوع المسافر:</div>
                        <div class="info-value">
                            <span class="badge bg-{{ $booking->passenger_type === 'adult' ? 'primary' : 'info' }}">
                                {{ $booking->passenger_type === 'adult' ? 'بالغ' : 'طفل' }}
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- بيانات الاتصال -->
                <div class="mb-4">
                    <h3 class="section-title">
                        <span>📞</span> بيانات الاتصال
                    </h3>
                    
                    <div class="info-row">
                        <div class="info-label">رقم الجوال:</div>
                        <div class="info-value">{{ $booking->passenger_phone }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">رقم الواتساب:</div>
                        <div class="info-value">{{ $booking->passenger_whatsapp ?? 'غير محدد' }}</div>
                    </div>
                </div>
                
                <!-- وثائق السفر -->
                <div class="mb-4">
                    <h3 class="section-title">
                        <span>🛂</span> وثائق السفر
                    </h3>
                    
                    <div class="info-row">
                        <div class="info-label">رقم الجواز:</div>
                        <div class="info-value">{{ $booking->passport_number }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">بلد الإصدار:</div>
                        <div class="info-value">{{ $booking->passport_issuing_country }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">تاريخ الانتهاء:</div>
                        <div class="info-value">{{ $booking->passport_expiry_date ? $booking->passport_expiry_date->format('Y-m-d') : 'غير محدد' }}</div>
                    </div>
                    
                    @if($booking->passport_image)
                        <div class="mt-3">
                            <p class="fw-bold mb-2">صورة الجواز:</p>
                            <img src="{{ asset('storage/' . $booking->passport_image) }}" 
                                 alt="صورة الجواز" 
                                 class="passport-image">
                        </div>
                    @endif
                </div>
                
                <!-- معلومات الأمتعة -->
                <div class="mb-4">
                    <h3 class="section-title">
                        <span>🧳</span> معلومات الأمتعة
                    </h3>
                    
                    <div class="info-row">
                        <div class="info-label">الوزن المختار:</div>
                        <div class="info-value">{{ $booking->selected_baggage_weight }} كجم</div>
                    </div>
                </div>
                
                <!-- ملخص السعر -->
                <div class="price-summary">
                    <p class="mb-2">إجمالي المبلغ المدفوع</p>
                    <h3>${{ number_format($booking->total_price, 2) }}</h3>
                    <small>حالة الدفع: {{ __($booking->payment_status) }}</small>
                </div>
                
                <!-- أزرار الإجراءات -->
                <div class="action-buttons">
                    <a href="{{ route('bookings.index') }}" class="btn btn-custom btn-secondary">
                        العودة إلى قائمة الحجوزات
                    </a>
                    <button onclick="window.print()" class="btn btn-custom btn-primary">
                        طباعة التفاصيل
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
@endsection
