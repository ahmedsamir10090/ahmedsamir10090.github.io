<?php

use App\Http\Controllers\Api\Admin\AdminAgencyController;
use App\Http\Controllers\Api\Admin\AdminSettingsController;
use App\Http\Controllers\Api\Agency\AgencyBookingController;
use App\Http\Controllers\Api\Agency\AgencyFlightController;
use App\Http\Controllers\Api\AirportController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\GoogleAuthController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\FlightController;
use App\Http\Controllers\Api\CargoController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\PortController;
use App\Http\Controllers\Api\WalletController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Public routes
    Route::post('auth/register', [AuthController::class, 'register']);
    Route::post('auth/login', [AuthController::class, 'login']);
    Route::post('auth/google', [GoogleAuthController::class, 'authenticate']);
    Route::get('flights', [FlightController::class, 'index']);
    Route::get('flights/{flight}', [FlightController::class, 'show']);
    Route::get('cargo-services', [CargoController::class, 'index']);
    Route::get('cargo-services/countries', [CargoController::class, 'getCountries']);
    Route::get('cargo-services/{cargoService}', [CargoController::class, 'show']);
    Route::post('cargo-services/calculate-price', [CargoController::class, 'calculatePrice']);
    
    // Airports and Ports
    Route::get('airports', [AirportController::class, 'index']);
    Route::get('airports/list', [AirportController::class, 'list']);
    Route::get('ports', [PortController::class, 'index']);
    Route::get('ports/list', [PortController::class, 'list']);

    // Protected routes
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('auth/profile', [AuthController::class, 'profile']);

        // User routes
        Route::middleware('user')->group(function () {
            Route::get('bookings', [BookingController::class, 'index']);
            Route::get('bookings/{booking}', [BookingController::class, 'show']);
            Route::post('bookings', [BookingController::class, 'store']);
            Route::post('bookings/{booking}/receipt', [BookingController::class, 'uploadReceipt']);
            Route::post('cargo/bookings', [CargoController::class, 'store']);
            Route::get('wallet', [WalletController::class, 'show']);
            Route::post('wallet/deposit', [WalletController::class, 'deposit']);
            
            // Notifications
            Route::get('notifications', [NotificationController::class, 'index']);
            Route::get('notifications/unread-count', [NotificationController::class, 'unreadCount']);
            Route::post('notifications/{notification}/read', [NotificationController::class, 'markAsRead']);
            Route::post('notifications/read-all', [NotificationController::class, 'markAllAsRead']);
            
            // FCM Token
            Route::post('fcm-token', [AuthController::class, 'updateFcmToken']);
        });

        // Agency routes
        Route::middleware('agency')->prefix('agency')->group(function () {
            Route::apiResource('flights', AgencyFlightController::class);
            Route::get('bookings', [AgencyBookingController::class, 'index']);
            Route::post('bookings/{booking}/accept', [AgencyBookingController::class, 'accept']);
            Route::post('bookings/{booking}/reject', [AgencyBookingController::class, 'reject']);
        });

        // Admin routes
        Route::middleware('admin')->prefix('admin')->group(function () {
            Route::apiResource('agencies', AdminAgencyController::class)->only(['index', 'store', 'show', 'update', 'destroy']);
            Route::get('settings', [AdminSettingsController::class, 'getSettings']);
            Route::put('settings', [AdminSettingsController::class, 'updateSettings']);
            Route::post('settings/toggle-payments', [AdminSettingsController::class, 'togglePayments']); // Legacy support
            Route::get('stats', [AdminSettingsController::class, 'stats']);
        });
    });
});
