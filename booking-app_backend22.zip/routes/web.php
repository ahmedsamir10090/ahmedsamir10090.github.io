<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

// --- تصحيح المسارات (Namespaces) ---
// تأكدنا من إضافة Admin\ قبل اسم الكونترولر
use App\Http\Controllers\AdminAgencyController;
use App\Http\Controllers\AdminBookingController;
use App\Http\Controllers\AdminCargoController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\Admin\FlightController as AdminFlightController;
use App\Http\Controllers\AdminSettingController;

// --- controllers for agency ---
use App\Http\Controllers\Agency\AgencyDashboardController;
use App\Http\Controllers\Agency\AgencyFlightController;
use App\Http\Controllers\Agency\AgencyCargoController;
use App\Http\Controllers\Agency\AgencyBookingController;
use App\Http\Controllers\Agency\AgencyStaffController;
use App\Http\Controllers\Agency\AgencyWalletController;

Route::get('/', function () {
    return view('welcome');
});

// ==========================================
// Admin Routes
// ==========================================
// التعديل هنا: أضفنا 'admin' middleware لمنع الوكالات من الدخول
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
    
    // Agency management
    Route::prefix('agencies')->name('agencies.')->group(function () {
        Route::get('/', [AdminAgencyController::class, 'index'])->name('index');
        Route::get('/create', [AdminAgencyController::class, 'create'])->name('create');
        Route::post('/', [AdminAgencyController::class, 'store'])->name('store');
        Route::get('/{id}', [AdminAgencyController::class, 'show'])->name('show');
        Route::post('/{id}/payout', [AdminAgencyController::class, 'payout'])->name('payout');
        Route::get('/{id}/edit', [AdminAgencyController::class, 'edit'])->name('edit');
        Route::put('/{id}', [AdminAgencyController::class, 'update'])->name('update');
        Route::post('/{id}/status', [AdminAgencyController::class, 'updateStatus'])->name('updateStatus');
        Route::delete('/{id}', [AdminAgencyController::class, 'destroy'])->name('destroy');
    });
    
    // Booking management
    Route::prefix('bookings')->name('bookings.')->group(function () {
        Route::get('/', [AdminBookingController::class, 'index'])->name('index');
        Route::get('/create', [AdminBookingController::class, 'create'])->name('create');
        Route::get('/pending-payments', [AdminBookingController::class, 'pendingPayments'])->name('pending-payments');
        Route::post('/', [AdminBookingController::class, 'store'])->name('store');
        Route::get('/services/{agencyId}/{type}', [AdminBookingController::class, 'getServicesByAgency'])->name('services');
        Route::get('/{id}', [AdminBookingController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [AdminBookingController::class, 'edit'])->name('edit');
        Route::put('/{id}', [AdminBookingController::class, 'update'])->name('update');
        Route::post('/{id}/accept', [AdminBookingController::class, 'accept'])->name('accept');
        Route::post('/{id}/reject', [AdminBookingController::class, 'reject'])->name('reject');
        Route::post('/{id}/approve-payment', [AdminBookingController::class, 'approvePayment'])->name('approve-payment');
        Route::post('/{id}/reject-payment', [AdminBookingController::class, 'rejectPayment'])->name('reject-payment');
        Route::post('/{id}/upload-receipt', [AdminBookingController::class, 'uploadReceipt'])->name('upload-receipt');
        Route::delete('/{id}', [AdminBookingController::class, 'destroy'])->name('destroy');
    });
    
    // Cargo Booking management
    Route::prefix('cargo/bookings')->name('cargo.bookings.')->group(function () {
        Route::get('/create', [AdminBookingController::class, 'createCargoBooking'])->name('create');
        Route::post('/', [AdminBookingController::class, 'storeCargoBooking'])->name('store');
        Route::get('/services', [AdminBookingController::class, 'getCargoServices'])->name('services');
        Route::get('/{id}/tracking', [AdminBookingController::class, 'showCargoTracking'])->name('tracking');
        Route::post('/{id}/update-status', [AdminBookingController::class, 'updateCargoStatus'])->name('update-status');
    });
    
    // Settings management
    Route::prefix('settings')->name('settings.')->group(function () {
        Route::get('/', [AdminSettingController::class, 'index'])->name('index');
        Route::put('/', [AdminSettingController::class, 'update'])->name('update');
        Route::put('/reset', [AdminSettingController::class, 'reset'])->name('reset');
    });
    
    Route::resource('flights', AdminFlightController::class);
    Route::resource('cargo', AdminCargoController::class)->except(['show']);
Route::get('/', function () {
    return redirect()->route('admin.dashboard');
});
    // Admin Logout
    Route::post('/logout', function () {
        Auth::logout();
        return redirect('/');
    })->name('logout'); 
});

// ==========================================
// Agency Panel Routes
// ==========================================
// هنا الكود سليم: يوجد 'agency' middleware لمنع الأدمن والمستخدمين العاديين
Route::middleware(['auth', 'agency'])->prefix('agency')->name('agency.')->group(function () {
    Route::get('/', function () {
    return redirect()->route('agency.dashboard');
});
    Route::get('/dashboard', [AgencyDashboardController::class, 'index'])->name('dashboard');
    Route::get('/wallet', [AgencyWalletController::class, 'index'])->name('wallet.index');
    
    Route::resource('flights', AgencyFlightController::class);
    Route::resource('cargo', AgencyCargoController::class);
    Route::resource('staff', AgencyStaffController::class);
    
    Route::get('/bookings', [AgencyBookingController::class, 'index'])->name('bookings.index');
    Route::get('/bookings/create', [AgencyBookingController::class, 'create'])->name('bookings.create');
    Route::post('/bookings', [AgencyBookingController::class, 'store'])->name('bookings.store');
    Route::get('/bookings/{bookingId}', [AgencyBookingController::class, 'show'])->name('bookings.show');
    Route::post('/bookings/{bookingId}/status', [AgencyBookingController::class, 'updateStatus'])->name('bookings.updateStatus');
    Route::post('/wallet/payout-request', [AgencyWalletController::class, 'payoutRequest'])->name('wallet.payoutRequest');
    
    // Agency Logout
    Route::post('/logout', function () {
        Auth::logout();
        return redirect('/');
    })->name('logout'); 
});

// Auth Routes
Auth::routes();

// ==========================================
// Home Route Handling
// ==========================================
// هذا الرابط مهم في حال كتب المستخدم /home يدوياً
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
