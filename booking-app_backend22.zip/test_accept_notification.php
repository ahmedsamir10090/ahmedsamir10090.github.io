<?php

require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

echo "=== Testing Booking Accept/Reject Notifications ===" . PHP_EOL . PHP_EOL;

// Find a booking for user 4
$booking = App\Models\Booking::where('user_id', 4)
    ->where('serviceable_type', 'App\Models\CargoService')
    ->where('status', 'pending')
    ->first();

if (!$booking) {
    echo "❌ No pending booking found for user 4" . PHP_EOL;
    exit;
}

echo "Found booking ID: {$booking->id}" . PHP_EOL;
echo "User: {$booking->user->name}" . PHP_EOL;
echo "Current status: {$booking->status}" . PHP_EOL . PHP_EOL;

// Simulate accept
echo "Simulating ACCEPT..." . PHP_EOL;
$booking->update(['status' => 'accepted', 'payment_status' => 'paid']);

// Create notification
$notification = App\Models\Notification::create([
    'user_id' => $booking->user_id,
    'title' => '✅ تم قبول الحجز',
    'body' => "تم قبول حجز الشحن رقم #{$booking->id}",
    'type' => 'booking_accepted',
    'data' => json_encode([
        'booking_id' => $booking->id,
        'status' => 'accepted',
    ]),
    'read_at' => null,
]);

echo "✅ Notification created: ID {$notification->id}" . PHP_EOL;
echo "Title: {$notification->title}" . PHP_EOL;
echo "Body: {$notification->body}" . PHP_EOL;
