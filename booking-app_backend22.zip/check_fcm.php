<?php

require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

echo "=== FCM Token Check ===" . PHP_EOL;
$user = App\Models\User::find(4);
if ($user) {
    echo "User: {$user->name}" . PHP_EOL;
    echo "FCM Token: " . ($user->fcm_token ? "EXISTS (" . strlen($user->fcm_token) . " chars)" : "NULL/EMPTY") . PHP_EOL;
    if ($user->fcm_token) {
        echo "Token: " . substr($user->fcm_token, 0, 50) . "..." . PHP_EOL;
    }
} else {
    echo "User not found" . PHP_EOL;
}

echo PHP_EOL . "=== Firebase Credentials ===" . PHP_EOL;
$credPath = config_path('firebase_credentials.json');
if (file_exists($credPath)) {
    echo "✅ File exists: {$credPath}" . PHP_EOL;
    $creds = json_decode(file_get_contents($credPath), true);
    echo "Project ID: " . ($creds['project_id'] ?? 'NOT FOUND') . PHP_EOL;
} else {
    echo "❌ File NOT found: {$credPath}" . PHP_EOL;
}

echo PHP_EOL . "=== Latest Notifications ===" . PHP_EOL;
$notifications = App\Models\Notification::where('user_id', 4)
    ->orderBy('id', 'desc')
    ->limit(3)
    ->get(['id', 'title', 'type', 'read_at', 'created_at']);
    
foreach ($notifications as $n) {
    $status = $n->read_at ? "قُرئ" : "غير مقروء";
    echo "ID: {$n->id} | {$n->title} | {$status} | {$n->created_at}" . PHP_EOL;
}
