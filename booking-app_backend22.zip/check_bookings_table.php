<?php

require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

echo "=== Bookings Table Structure ===" . PHP_EOL;
$columns = DB::select('DESCRIBE bookings');
foreach ($columns as $col) {
    echo $col->Field . ' (' . $col->Type . ')' . PHP_EOL;
}
