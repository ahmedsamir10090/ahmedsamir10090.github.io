<?php

echo "=== Latest 5 Notifications ===" . PHP_EOL;
$notifications = \App\Models\Notification::orderBy('id', 'desc')->limit(5)->get();
foreach ($notifications as $n) {
    echo "ID: {$n->id} | User: {$n->user_id} | Title: {$n->title} | Type: {$n->type} | Created: {$n->created_at}" . PHP_EOL;
}

echo PHP_EOL . "=== User FCM Token Check ===" . PHP_EOL;
$user = \App\Models\User::find(4);
if ($user) {
    echo "User: {$user->name}" . PHP_EOL;
    echo "FCM Token: " . ($user->fcm_token ? "EXISTS (" . strlen($user->fcm_token) . " chars)" : "NULL/EMPTY") . PHP_EOL;
} else {
    echo "User not found" . PHP_EOL;
}

echo PHP_EOL . "=== Booking 6 Check ===" . PHP_EOL;
$booking = \App\Models\Booking::find(6);
if ($booking) {
    echo "Booking ID: {$booking->id}" . PHP_EOL;
    echo "User ID: {$booking->user_id}" . PHP_EOL;
    echo "Tracking Status: {$booking->tracking_status}" . PHP_EOL;
    echo "Type: {$booking->type}" . PHP_EOL;
} else {
    echo "Booking not found" . PHP_EOL;
}
