<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            // أسعار البالغين والأطفال
            $table->decimal('adult_price', 10, 2)->nullable()->after('price');
            $table->decimal('child_price', 10, 2)->nullable()->after('adult_price');
            
            // أسعار الوزن (JSON لدعم أوزان متعددة)
            // مثال: {"30": 100, "45": 150, "60": 200}
            $table->json('baggage_prices')->nullable()->after('child_price');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            $table->dropColumn(['adult_price', 'child_price', 'baggage_prices']);
        });
    }
};
