<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('flights', function (Blueprint $table) {
            $table->id();
            $table->foreignId('agency_id')->nullable()->constrained()->nullOnDelete();
            $table->string('flight_number')->unique();
            $table->string('origin')->index();
            $table->string('destination')->index();
            $table->dateTime('departure_time')->index();
            $table->dateTime('arrival_time')->nullable()->index();
            $table->decimal('price', 18, 2)->index();
            $table->unsignedInteger('available_seats')->default(0);
            $table->enum('status', ['pending', 'active', 'cancelled'])->default('pending')->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('flights');
    }
};
