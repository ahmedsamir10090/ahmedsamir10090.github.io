<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Add flight_type to flights table if not exists
        if (!Schema::hasColumn('flights', 'flight_type')) {
            Schema::table('flights', function (Blueprint $table) {
                $table->enum('flight_type', ['air', 'sea'])->default('air')->after('status');
            });
        }

        // Add tracking fields to cargo_services table
        Schema::table('cargo_services', function (Blueprint $table) {
            // Sender information
            $table->string('sender_name')->nullable()->after('route_to');
            $table->string('sender_phone')->nullable();
            $table->string('sender_whatsapp')->nullable();
            $table->string('sender_country')->nullable();
            $table->string('sender_city')->nullable();
            $table->string('sender_passport_image')->nullable();
            
            // Receiver information
            $table->string('receiver_name')->nullable();
            $table->string('receiver_phone')->nullable();
            $table->string('receiver_whatsapp')->nullable();
            $table->string('receiver_country')->nullable();
            $table->string('receiver_city')->nullable();
            
            // Shipment details
            $table->text('contents_description')->nullable();
            $table->boolean('no_prohibited_items')->default(false);
            
            // Tracking status
            $table->enum('tracking_status', [
                'pending',
                'picked_up',
                'in_transit_origin',
                'customs_origin',
                'in_flight',
                'arrived_destination',
                'customs_destination',
                'out_for_delivery',
                'delivered'
            ])->default('pending');
            
            $table->string('current_location')->nullable();
            $table->timestamp('status_updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            $table->dropColumn('flight_type');
        });

        Schema::table('cargo_services', function (Blueprint $table) {
            $table->dropColumn([
                'sender_name',
                'sender_phone',
                'sender_whatsapp',
                'sender_country',
                'sender_city',
                'sender_passport_image',
                'receiver_name',
                'receiver_phone',
                'receiver_whatsapp',
                'receiver_country',
                'receiver_city',
                'contents_description',
                'no_prohibited_items',
                'tracking_status',
                'current_location',
                'status_updated_at',
            ]);
        });
    }
};
