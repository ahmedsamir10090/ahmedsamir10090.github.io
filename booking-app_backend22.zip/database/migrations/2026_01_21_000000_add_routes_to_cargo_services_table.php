<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('cargo_services', function (Blueprint $table) {
            $table->string('route_from')->nullable()->after('min_weight');
            $table->string('route_to')->nullable()->after('route_from');
        });
    }

    public function down(): void
    {
        Schema::table('cargo_services', function (Blueprint $table) {
            $table->dropColumn(['route_from', 'route_to']);
        });
    }
};
