<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('agencies', function (Blueprint $table) {
            $table->id();
            $table->string('name')->index();
            $table->string('license_number')->nullable()->unique();
            $table->string('logo')->nullable();
            $table->decimal('balance', 18, 2)->default(0)->index();
            $table->decimal('commission_rate', 5, 2)->default(0);
            $table->enum('status', ['active', 'suspended'])->default('active')->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agencies');
    }
};
