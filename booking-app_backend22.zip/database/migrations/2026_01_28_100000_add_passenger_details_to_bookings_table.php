<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            // معلومات المسافر الشخصية
            $table->enum('passenger_title', ['mr', 'ms', 'mrs'])->nullable()->after('user_id');
            $table->string('passenger_first_name')->nullable()->after('passenger_title');
            $table->string('passenger_middle_name')->nullable()->after('passenger_first_name');
            $table->string('passenger_last_name')->nullable()->after('passenger_middle_name');
            $table->date('passenger_date_of_birth')->nullable()->after('passenger_last_name');
            $table->string('passenger_nationality')->nullable()->after('passenger_date_of_birth');
            $table->enum('passenger_type', ['adult', 'child'])->default('adult')->after('passenger_nationality');
            
            // بيانات الاتصال
            $table->string('passenger_phone')->nullable()->after('passenger_type');
            $table->string('passenger_whatsapp')->nullable()->after('passenger_phone');
            
            // وثائق السفر
            $table->string('passport_number')->nullable()->after('passenger_whatsapp');
            $table->string('passport_issuing_country')->nullable()->after('passport_number');
            $table->date('passport_expiry_date')->nullable()->after('passport_issuing_country');
            $table->string('passport_image')->nullable()->after('passport_expiry_date');
            
            // وزن الأمتعة المختار
            $table->integer('selected_baggage_weight')->nullable()->after('passport_image');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn([
                'passenger_title',
                'passenger_first_name',
                'passenger_middle_name',
                'passenger_last_name',
                'passenger_date_of_birth',
                'passenger_nationality',
                'passenger_type',
                'passenger_phone',
                'passenger_whatsapp',
                'passport_number',
                'passport_issuing_country',
                'passport_expiry_date',
                'passport_image',
                'selected_baggage_weight'
            ]);
        });
    }
};
