<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('cargo_services', function (Blueprint $table) {
            $table->id();
            $table->foreignId('agency_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('type', ['air', 'sea', 'land'])->index();
            $table->decimal('price_per_kg', 18, 2)->default(0);
            $table->decimal('min_weight', 10, 2)->default(0);
            $table->string('delivery_time_estimate')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cargo_services');
    }
};
