<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // First, update the payment_status enum to include new statuses
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_status ENUM('unpaid', 'pending', 'pending_cod', 'pending_verification', 'paid', 'failed', 'refunded', 'rejected') DEFAULT 'unpaid'");
        
        // Update the payment_method enum to include cash_on_delivery
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_method ENUM('wallet', 'stripe', 'manual_receipt', 'cash_on_delivery') DEFAULT NULL");

        Schema::table('bookings', function (Blueprint $table) {
            // Payment verification fields
            $table->string('payment_rejection_reason')->nullable()->after('payment_proof_image');
            $table->timestamp('payment_verified_at')->nullable()->after('payment_rejection_reason');
            $table->foreignId('payment_verified_by')->nullable()->after('payment_verified_at')
                ->constrained('users')->nullOnDelete();
            
            // Passenger details (if not already added)
            if (!Schema::hasColumn('bookings', 'passenger_title')) {
                $table->enum('passenger_title', ['mr', 'ms', 'mrs', 'dr'])->nullable()->after('payment_verified_by');
                $table->string('passenger_first_name')->nullable()->after('passenger_title');
                $table->string('passenger_middle_name')->nullable()->after('passenger_first_name');
                $table->string('passenger_last_name')->nullable()->after('passenger_middle_name');
                $table->date('passenger_date_of_birth')->nullable()->after('passenger_last_name');
                $table->string('passenger_nationality', 100)->nullable()->after('passenger_date_of_birth');
                $table->enum('passenger_type', ['adult', 'child', 'infant'])->default('adult')->after('passenger_nationality');
                $table->string('passenger_phone', 20)->nullable()->after('passenger_type');
                $table->string('passenger_whatsapp', 20)->nullable()->after('passenger_phone');
            }
            
            // Passport details (if not already added)
            if (!Schema::hasColumn('bookings', 'passport_number')) {
                $table->string('passport_number', 50)->nullable()->after('passenger_whatsapp');
                $table->string('passport_issuing_country', 100)->nullable()->after('passport_number');
                $table->date('passport_expiry_date')->nullable()->after('passport_issuing_country');
                $table->string('passport_image')->nullable()->after('passport_expiry_date');
            }
            
            // Baggage (if not already added)
            if (!Schema::hasColumn('bookings', 'selected_baggage_weight')) {
                $table->integer('selected_baggage_weight')->nullable()->after('passport_image');
            }
        });
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropForeign(['payment_verified_by']);
            $table->dropColumn([
                'payment_rejection_reason',
                'payment_verified_at',
                'payment_verified_by',
            ]);
        });

        // Revert enums
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_status ENUM('unpaid', 'pending', 'paid', 'failed', 'refunded') DEFAULT 'unpaid'");
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_method ENUM('wallet', 'stripe', 'manual_receipt') DEFAULT NULL");
    }
};
