<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cargo_services', function (Blueprint $table) {
            if (!Schema::hasColumn('cargo_services', 'max_weight')) {
                $table->decimal('max_weight', 10, 2)->default(100)->after('min_weight');
            }
            if (!Schema::hasColumn('cargo_services', 'estimated_days')) {
                $table->integer('estimated_days')->default(7)->after('delivery_time_estimate');
            }
            if (!Schema::hasColumn('cargo_services', 'status')) {
                $table->enum('status', ['active', 'inactive'])->default('active')->after('estimated_days');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cargo_services', function (Blueprint $table) {
            $table->dropColumn(['max_weight', 'estimated_days', 'status']);
        });
    }
};
