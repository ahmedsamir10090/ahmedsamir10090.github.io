<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('flight_classes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('flight_id')->constrained()->cascadeOnDelete();
            $table->enum('class_type', ['economy', 'business', 'first'])->default('economy');
            $table->string('class_name', 100); // e.g., "Economy Standard", "Business Plus"
            $table->decimal('price', 10, 2); // Price for this class
            $table->integer('total_seats'); // Total seats available in this class
            $table->integer('available_seats'); // Currently available seats
            $table->integer('baggage_allowance')->default(20); // In KG
            $table->text('refund_policy')->nullable(); // Refundable, Non-refundable, etc.
            $table->text('change_policy')->nullable(); // Change fee, conditions
            $table->text('amenities')->nullable(); // Extra perks (meals, priority boarding, etc.)
            $table->boolean('is_active')->default(true)->index(); // Admin can disable
            $table->timestamps();

            // Composite indexes for common queries
            $table->index(['flight_id', 'class_type']);
            $table->index(['flight_id', 'is_active']);
            
            // Unique constraint: one record per class type per flight
            $table->unique(['flight_id', 'class_type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('flight_classes');
    }
};
