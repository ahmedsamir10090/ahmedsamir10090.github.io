<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            $table->foreignId('origin_port_id')->nullable()->after('origin_airport_id')->constrained('ports')->nullOnDelete();
            $table->foreignId('destination_port_id')->nullable()->after('destination_airport_id')->constrained('ports')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            $table->dropForeign(['origin_port_id']);
            $table->dropForeign(['destination_port_id']);
            $table->dropColumn(['origin_port_id', 'destination_port_id']);
        });
    }
};
