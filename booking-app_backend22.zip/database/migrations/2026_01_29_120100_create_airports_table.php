<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('airports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('country_id')->constrained()->onDelete('cascade');
            $table->string('name_ar', 150);
            $table->string('name_en', 150);
            $table->string('iata_code', 3)->unique()->comment('IATA airport code');
            $table->string('city_ar', 100)->nullable();
            $table->string('city_en', 100)->nullable();
            $table->timestamps();

            $table->index('country_id');
            $table->index('iata_code');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('airports');
    }
};
