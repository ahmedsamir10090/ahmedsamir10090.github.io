<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            // Add new foreign key columns
            $table->foreignId('origin_airport_id')->nullable()->after('flight_number')->constrained('airports')->onDelete('restrict');
            $table->foreignId('destination_airport_id')->nullable()->after('origin_airport_id')->constrained('airports')->onDelete('restrict');
        });

        // Drop old columns after adding new ones
        Schema::table('flights', function (Blueprint $table) {
            $table->dropColumn(['origin', 'destination']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('flights', function (Blueprint $table) {
            // Re-add old columns
            $table->string('origin')->nullable()->after('flight_number');
            $table->string('destination')->nullable()->after('origin');
        });

        Schema::table('flights', function (Blueprint $table) {
            // Drop foreign keys and columns
            $table->dropForeign(['origin_airport_id']);
            $table->dropForeign(['destination_airport_id']);
            $table->dropColumn(['origin_airport_id', 'destination_airport_id']);
        });
    }
};
