<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->enum('tracking_status', [
                'pending',
                'picked_up',
                'in_transit_origin',
                'arrived_at_destination',
                'in_transit_destination',
                'out_for_delivery',
                'delivered'
            ])->default('pending')->after('status');
            
            $table->string('current_location')->nullable()->after('tracking_status');
            $table->text('tracking_notes')->nullable()->after('current_location');
            $table->timestamp('delivered_at')->nullable()->after('tracking_notes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn(['tracking_status', 'current_location', 'tracking_notes', 'delivered_at']);
        });
    }
};
