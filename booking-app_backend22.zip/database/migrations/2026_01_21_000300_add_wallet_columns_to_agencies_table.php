<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('agencies', function (Blueprint $table) {
            $table->decimal('current_balance', 12, 2)->default(0)->after('balance');
            $table->decimal('total_lifetime_earnings', 12, 2)->default(0)->after('current_balance');
        });
    }

    public function down(): void
    {
        Schema::table('agencies', function (Blueprint $table) {
            $table->dropColumn(['current_balance', 'total_lifetime_earnings']);
        });
    }
};
