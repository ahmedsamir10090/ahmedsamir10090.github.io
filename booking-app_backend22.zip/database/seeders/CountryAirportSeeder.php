<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Country;
use App\Models\Airport;

class CountryAirportSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $countries = [
            [
                'name_en' => 'Sudan',
                'name_ar' => 'السودان',
                'code' => 'SD',
                'airports' => [
                    ['name_en' => 'Khartoum International Airport', 'name_ar' => 'مطار الخرطوم الدولي', 'iata_code' => 'KRT', 'city_en' => 'Khartoum', 'city_ar' => 'الخرطوم'],
                    ['name_en' => 'Port Sudan New International Airport', 'name_ar' => 'مطار بورتسودان الدولي الجديد', 'iata_code' => 'PZU', 'city_en' => 'Port Sudan', 'city_ar' => 'بورتسودان'],
                    ['name_en' => 'Dongola Airport', 'name_ar' => 'مطار دنقلا', 'iata_code' => 'DOG', 'city_en' => 'Dongola', 'city_ar' => 'دنقلا'],
                    ['name_en' => 'El Obeid Airport', 'name_ar' => 'مطار الأبيض', 'iata_code' => 'EBD', 'city_en' => 'El Obeid', 'city_ar' => 'الأبيض'],
                    ['name_en' => 'Kassala Airport', 'name_ar' => 'مطار كسلا', 'iata_code' => 'KSL', 'city_en' => 'Kassala', 'city_ar' => 'كسلا'],
                    ['name_en' => 'El Fasher Airport', 'name_ar' => 'مطار الفاشر', 'iata_code' => 'ELF', 'city_en' => 'El Fasher', 'city_ar' => 'الفاشر'],
                    ['name_en' => 'Geneina Airport', 'name_ar' => 'مطار الجنينة', 'iata_code' => 'EGN', 'city_en' => 'Geneina', 'city_ar' => 'الجنينة'],
                    ['name_en' => 'Nyala Airport', 'name_ar' => 'مطار نيالا', 'iata_code' => 'UYL', 'city_en' => 'Nyala', 'city_ar' => 'نيالا'],
                    ['name_en' => 'Damazin Airport', 'name_ar' => 'مطار الدمازين', 'iata_code' => 'RSS', 'city_en' => 'Damazin', 'city_ar' => 'الدمازين'],
                ]
            ],
            [
                'name_en' => 'Egypt',
                'name_ar' => 'مصر',
                'code' => 'EG',
                'airports' => [
                    ['name_en' => 'Cairo International Airport', 'name_ar' => 'مطار القاهرة الدولي', 'iata_code' => 'CAI', 'city_en' => 'Cairo', 'city_ar' => 'القاهرة'],
                    ['name_en' => 'Sphinx International Airport', 'name_ar' => 'مطار سفنكس الدولي', 'iata_code' => 'SPX', 'city_en' => 'Giza', 'city_ar' => 'الجيزة'],
                    ['name_en' => 'Borg El Arab Airport', 'name_ar' => 'مطار برج العرب', 'iata_code' => 'HBE', 'city_en' => 'Alexandria', 'city_ar' => 'الإسكندرية'],
                    ['name_en' => 'Sharm El Sheikh International Airport', 'name_ar' => 'مطار شرم الشيخ الدولي', 'iata_code' => 'SSH', 'city_en' => 'Sharm El Sheikh', 'city_ar' => 'شرم الشيخ'],
                    ['name_en' => 'Hurghada International Airport', 'name_ar' => 'مطار الغردقة الدولي', 'iata_code' => 'HRG', 'city_en' => 'Hurghada', 'city_ar' => 'الغردقة'],
                    ['name_en' => 'Luxor International Airport', 'name_ar' => 'مطار الأقصر الدولي', 'iata_code' => 'LXR', 'city_en' => 'Luxor', 'city_ar' => 'الأقصر'],
                    ['name_en' => 'Aswan International Airport', 'name_ar' => 'مطار أسوان الدولي', 'iata_code' => 'ASW', 'city_en' => 'Aswan', 'city_ar' => 'أسوان'],
                    ['name_en' => 'Sohag International Airport', 'name_ar' => 'مطار سوهاج الدولي', 'iata_code' => 'HMB', 'city_en' => 'Sohag', 'city_ar' => 'سوهاج'],
                    ['name_en' => 'Assiut Airport', 'name_ar' => 'مطار أسيوط', 'iata_code' => 'ATZ', 'city_en' => 'Assiut', 'city_ar' => 'أسيوط'],
                    ['name_en' => 'Marsa Alam International Airport', 'name_ar' => 'مطار مرسى علم الدولي', 'iata_code' => 'RMF', 'city_en' => 'Marsa Alam', 'city_ar' => 'مرسى علم'],
                ]
            ],
            [
                'name_en' => 'Saudi Arabia',
                'name_ar' => 'المملكة العربية السعودية',
                'code' => 'SA',
                'airports' => [
                    ['name_en' => 'King Abdulaziz International Airport', 'name_ar' => 'مطار الملك عبدالعزيز الدولي', 'iata_code' => 'JED', 'city_en' => 'Jeddah', 'city_ar' => 'جدة'],
                    ['name_en' => 'King Khalid International Airport', 'name_ar' => 'مطار الملك خالد الدولي', 'iata_code' => 'RUH', 'city_en' => 'Riyadh', 'city_ar' => 'الرياض'],
                    ['name_en' => 'King Fahd International Airport', 'name_ar' => 'مطار الملك فهد الدولي', 'iata_code' => 'DMM', 'city_en' => 'Dammam', 'city_ar' => 'الدمام'],
                    ['name_en' => 'Prince Mohammad bin Abdulaziz Airport', 'name_ar' => 'مطار الأمير محمد بن عبدالعزيز', 'iata_code' => 'MED', 'city_en' => 'Medina', 'city_ar' => 'المدينة المنورة'],
                    ['name_en' => 'Abha Regional Airport', 'name_ar' => 'مطار أبها الإقليمي', 'iata_code' => 'AHB', 'city_en' => 'Abha', 'city_ar' => 'أبها'],
                    ['name_en' => 'Prince Nayef bin Abdulaziz Regional Airport', 'name_ar' => 'مطار الأمير نايف بن عبدالعزيز الإقليمي', 'iata_code' => 'ELQ', 'city_en' => 'Qassim', 'city_ar' => 'القصيم'],
                    ['name_en' => 'Taif Regional Airport', 'name_ar' => 'مطار الطائف الإقليمي', 'iata_code' => 'TIF', 'city_en' => 'Taif', 'city_ar' => 'الطائف'],
                    ['name_en' => 'Tabuk Regional Airport', 'name_ar' => 'مطار تبوك الإقليمي', 'iata_code' => 'TUU', 'city_en' => 'Tabuk', 'city_ar' => 'تبوك'],
                    ['name_en' => 'Jazan Regional Airport', 'name_ar' => 'مطار جازان الإقليمي', 'iata_code' => 'GIZ', 'city_en' => 'Jazan', 'city_ar' => 'جازان'],
                    ['name_en' => 'Hail Regional Airport', 'name_ar' => 'مطار حائل الإقليمي', 'iata_code' => 'HAS', 'city_en' => 'Hail', 'city_ar' => 'حائل'],
                ]
            ],
            [
                'name_en' => 'United Arab Emirates',
                'name_ar' => 'الإمارات العربية المتحدة',
                'code' => 'AE',
                'airports' => [
                    ['name_en' => 'Dubai International Airport', 'name_ar' => 'مطار دبي الدولي', 'iata_code' => 'DXB', 'city_en' => 'Dubai', 'city_ar' => 'دبي'],
                    ['name_en' => 'Al Maktoum International Airport', 'name_ar' => 'مطار آل مكتوم الدولي', 'iata_code' => 'DWC', 'city_en' => 'Dubai', 'city_ar' => 'دبي'],
                    ['name_en' => 'Abu Dhabi International Airport', 'name_ar' => 'مطار أبوظبي الدولي', 'iata_code' => 'AUH', 'city_en' => 'Abu Dhabi', 'city_ar' => 'أبوظبي'],
                    ['name_en' => 'Sharjah International Airport', 'name_ar' => 'مطار الشارقة الدولي', 'iata_code' => 'SHJ', 'city_en' => 'Sharjah', 'city_ar' => 'الشارقة'],
                    ['name_en' => 'Ras Al Khaimah International Airport', 'name_ar' => 'مطار رأس الخيمة الدولي', 'iata_code' => 'RKT', 'city_en' => 'Ras Al Khaimah', 'city_ar' => 'رأس الخيمة'],
                    ['name_en' => 'Al Ain International Airport', 'name_ar' => 'مطار العين الدولي', 'iata_code' => 'AAN', 'city_en' => 'Al Ain', 'city_ar' => 'العين'],
                    ['name_en' => 'Fujairah International Airport', 'name_ar' => 'مطار الفجيرة الدولي', 'iata_code' => 'FJR', 'city_en' => 'Fujairah', 'city_ar' => 'الفجيرة'],
                ]
            ],
            [
                'name_en' => 'Oman',
                'name_ar' => 'سلطنة عمان',
                'code' => 'OM',
                'airports' => [
                    ['name_en' => 'Muscat International Airport', 'name_ar' => 'مطار مسقط الدولي', 'iata_code' => 'MCT', 'city_en' => 'Muscat', 'city_ar' => 'مسقط'],
                    ['name_en' => 'Salalah Airport', 'name_ar' => 'مطار صلالة', 'iata_code' => 'SLL', 'city_en' => 'Salalah', 'city_ar' => 'صلالة'],
                    ['name_en' => 'Sohar Airport', 'name_ar' => 'مطار صحار', 'iata_code' => 'OHS', 'city_en' => 'Sohar', 'city_ar' => 'صحار'],
                    ['name_en' => 'Duqm Airport', 'name_ar' => 'مطار الدقم', 'iata_code' => 'DQM', 'city_en' => 'Duqm', 'city_ar' => 'الدقم'],
                ]
            ],
            [
                'name_en' => 'Kuwait',
                'name_ar' => 'الكويت',
                'code' => 'KW',
                'airports' => [
                    ['name_en' => 'Kuwait International Airport', 'name_ar' => 'مطار الكويت الدولي', 'iata_code' => 'KWI', 'city_en' => 'Kuwait City', 'city_ar' => 'مدينة الكويت'],
                ]
            ],
            [
                'name_en' => 'Bahrain',
                'name_ar' => 'البحرين',
                'code' => 'BH',
                'airports' => [
                    ['name_en' => 'Bahrain International Airport', 'name_ar' => 'مطار البحرين الدولي', 'iata_code' => 'BAH', 'city_en' => 'Manama', 'city_ar' => 'المنامة'],
                ]
            ],
            [
                'name_en' => 'South Sudan',
                'name_ar' => 'جنوب السودان',
                'code' => 'SS',
                'airports' => [
                    ['name_en' => 'Juba International Airport', 'name_ar' => 'مطار جوبا الدولي', 'iata_code' => 'JUB', 'city_en' => 'Juba', 'city_ar' => 'جوبا'],
                    ['name_en' => 'Malakal Airport', 'name_ar' => 'مطار ملكال', 'iata_code' => 'MAK', 'city_en' => 'Malakal', 'city_ar' => 'ملكال'],
                    ['name_en' => 'Wau Airport', 'name_ar' => 'مطار واو', 'iata_code' => 'WUU', 'city_en' => 'Wau', 'city_ar' => 'واو'],
                ]
            ],
        ];

        foreach ($countries as $countryData) {
            $country = Country::create([
                'name_en' => $countryData['name_en'],
                'name_ar' => $countryData['name_ar'],
                'code' => $countryData['code'],
            ]);

            foreach ($countryData['airports'] as $airportData) {
                Airport::create([
                    'country_id' => $country->id,
                    'name_en' => $airportData['name_en'],
                    'name_ar' => $airportData['name_ar'],
                    'iata_code' => $airportData['iata_code'],
                    'city_en' => $airportData['city_en'],
                    'city_ar' => $airportData['city_ar'],
                ]);
            }
        }
    }
}
