<?php

namespace Database\Seeders;

use App\Models\Country;
use App\Models\Port;
use Illuminate\Database\Seeder;

class PortSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ports = [
            // Sudan Ports
            ['country_code' => 'SD', 'name_ar' => 'ميناء بورتسودان', 'name_en' => 'Port Sudan', 'code' => 'SDPZU', 'city_ar' => 'بورتسودان', 'city_en' => 'Port Sudan'],
            ['country_code' => 'SD', 'name_ar' => 'ميناء سواكن', 'name_en' => 'Suakin Port', 'code' => 'SDSUK', 'city_ar' => 'سواكن', 'city_en' => 'Suakin'],
            
            // Egypt Ports
            ['country_code' => 'EG', 'name_ar' => 'ميناء الإسكندرية', 'name_en' => 'Alexandria Port', 'code' => 'EGALY', 'city_ar' => 'الإسكندرية', 'city_en' => 'Alexandria'],
            ['country_code' => 'EG', 'name_ar' => 'ميناء بورسعيد', 'name_en' => 'Port Said', 'code' => 'EGPSD', 'city_ar' => 'بورسعيد', 'city_en' => 'Port Said'],
            ['country_code' => 'EG', 'name_ar' => 'ميناء السويس', 'name_en' => 'Suez Port', 'code' => 'EGSUZ', 'city_ar' => 'السويس', 'city_en' => 'Suez'],
            ['country_code' => 'EG', 'name_ar' => 'ميناء الغردقة', 'name_en' => 'Hurghada Port', 'code' => 'EGHUR', 'city_ar' => 'الغردقة', 'city_en' => 'Hurghada'],
            
            // Saudi Arabia Ports
            ['country_code' => 'SA', 'name_ar' => 'ميناء جدة الإسلامي', 'name_en' => 'Jeddah Islamic Port', 'code' => 'SAJED', 'city_ar' => 'جدة', 'city_en' => 'Jeddah'],
            ['country_code' => 'SA', 'name_ar' => 'ميناء الملك عبدالعزيز (الدمام)', 'name_en' => 'King Abdulaziz Port (Dammam)', 'code' => 'SADMM', 'city_ar' => 'الدمام', 'city_en' => 'Dammam'],
            ['country_code' => 'SA', 'name_ar' => 'ميناء الملك فهد الصناعي (الجبيل)', 'name_en' => 'King Fahd Industrial Port (Jubail)', 'code' => 'SAJUB', 'city_ar' => 'الجبيل', 'city_en' => 'Jubail'],
            ['country_code' => 'SA', 'name_ar' => 'ميناء ينبع التجاري', 'name_en' => 'Yanbu Commercial Port', 'code' => 'SAYNB', 'city_ar' => 'ينبع', 'city_en' => 'Yanbu'],
            
            // UAE Ports
            ['country_code' => 'AE', 'name_ar' => 'ميناء جبل علي', 'name_en' => 'Jebel Ali Port', 'code' => 'AEJEA', 'city_ar' => 'دبي', 'city_en' => 'Dubai'],
            ['country_code' => 'AE', 'name_ar' => 'ميناء راشد', 'name_en' => 'Port Rashid', 'code' => 'AEDXB', 'city_ar' => 'دبي', 'city_en' => 'Dubai'],
            ['country_code' => 'AE', 'name_ar' => 'ميناء زايد', 'name_en' => 'Zayed Port', 'code' => 'AEAUH', 'city_ar' => 'أبوظبي', 'city_en' => 'Abu Dhabi'],
            ['country_code' => 'AE', 'name_ar' => 'ميناء الفجيرة', 'name_en' => 'Fujairah Port', 'code' => 'AEFJR', 'city_ar' => 'الفجيرة', 'city_en' => 'Fujairah'],
            
            // Qatar Ports
            ['country_code' => 'QA', 'name_ar' => 'ميناء حمد', 'name_en' => 'Hamad Port', 'code' => 'QADOH', 'city_ar' => 'الدوحة', 'city_en' => 'Doha'],
            ['country_code' => 'QA', 'name_ar' => 'ميناء الدوحة', 'name_en' => 'Doha Port', 'code' => 'QADHA', 'city_ar' => 'الدوحة', 'city_en' => 'Doha'],
            
            // Kuwait Ports
            ['country_code' => 'KW', 'name_ar' => 'ميناء الشويخ', 'name_en' => 'Shuwaikh Port', 'code' => 'KWKWI', 'city_ar' => 'الكويت', 'city_en' => 'Kuwait City'],
            ['country_code' => 'KW', 'name_ar' => 'ميناء الشعيبة', 'name_en' => 'Shuaiba Port', 'code' => 'KWSHU', 'city_ar' => 'الشعيبة', 'city_en' => 'Shuaiba'],
            
            // Oman Ports
            ['country_code' => 'OM', 'name_ar' => 'ميناء السلطان قابوس', 'name_en' => 'Sultan Qaboos Port', 'code' => 'OMMCT', 'city_ar' => 'مسقط', 'city_en' => 'Muscat'],
            ['country_code' => 'OM', 'name_ar' => 'ميناء صلالة', 'name_en' => 'Salalah Port', 'code' => 'OMSLL', 'city_ar' => 'صلالة', 'city_en' => 'Salalah'],
            ['country_code' => 'OM', 'name_ar' => 'ميناء صحار', 'name_en' => 'Sohar Port', 'code' => 'OMSOH', 'city_ar' => 'صحار', 'city_en' => 'Sohar'],
            
            // Jordan Ports
            ['country_code' => 'JO', 'name_ar' => 'ميناء العقبة', 'name_en' => 'Aqaba Port', 'code' => 'JOAQJ', 'city_ar' => 'العقبة', 'city_en' => 'Aqaba'],
        ];

        foreach ($ports as $portData) {
            $country = Country::where('code', $portData['country_code'])->first();
            
            if ($country) {
                Port::create([
                    'country_id' => $country->id,
                    'name_ar' => $portData['name_ar'],
                    'name_en' => $portData['name_en'],
                    'code' => $portData['code'],
                    'city_ar' => $portData['city_ar'],
                    'city_en' => $portData['city_en'],
                    'is_active' => true,
                ]);
            }
        }

        $this->command->info('Ports seeded successfully!');
    }
}
