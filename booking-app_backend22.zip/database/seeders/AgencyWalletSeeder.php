<?php

namespace Database\Seeders;

use App\Models\Agency;
use App\Models\AgencyTransaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class AgencyWalletSeeder extends Seeder
{
    public function run(): void
    {
        $agency = Agency::first();
        if (! $agency) {
            return;
        }

        $manager = User::where('agency_id', $agency->id)
            ->where('role', 'agency_manager')
            ->first();

        $agency->update([
            'current_balance' => 5000.00,
            'total_lifetime_earnings' => 7000.00,
        ]);

        $transactions = [
            [
                'type' => 'earning',
                'amount' => 2000,
                'booking_id' => 2,
                'description' => 'Earning seed #2',
                'created_at' => Carbon::now()->subDays(4),
            ],
            [
                'type' => 'earning',
                'amount' => 3000,
                'booking_id' => 3,
                'description' => 'Earning seed #3',
                'created_at' => Carbon::now()->subDays(3),
            ],
            [
                'type' => 'payout',
                'amount' => -1000,
                'payment_method' => 'Bank Transfer',
                'description' => 'Payout seed',
                'created_at' => Carbon::now()->subDays(2),
            ],
            [
                'type' => 'earning',
                'amount' => 0,
                'booking_id' => 4,
                'description' => 'Dummy earning seed',
                'created_at' => Carbon::now()->subDays(1),
            ],
        ];

        foreach ($transactions as $tx) {
            AgencyTransaction::create(array_merge($tx, [
                'agency_id' => $agency->id,
                'admin_id' => $manager?->id,
                'updated_at' => $tx['created_at'],
            ]));
        }
    }

    
}