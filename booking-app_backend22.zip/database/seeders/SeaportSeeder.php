<?php

namespace Database\Seeders;

use App\Models\Airport;
use App\Models\Country;
use Illuminate\Database\Seeder;

class SeaportSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get countries
        $sudan = Country::where('code', 'SD')->first();
        $saudiArabia = Country::where('code', 'SA')->first();
        $egypt = Country::where('code', 'EG')->first();
        $uae = Country::where('code', 'AE')->first();

        if (!$sudan || !$saudiArabia || !$egypt || !$uae) {
            $this->command->warn('Some countries not found. Please run CountrySeeder first.');
            return;
        }

        $seaports = [
            // Sudan Seaports
            [
                'country_id' => $sudan->id,
                'iata_code' => 'PZS',
                'name_ar' => 'ميناء بورتسودان',
                'name_en' => 'Port Sudan Seaport',
                'city_ar' => 'بورتسودان',
                'city_en' => 'Port Sudan',
                'type' => 'seaport',
            ],
            [
                'country_id' => $sudan->id,
                'iata_code' => 'SUK',
                'name_ar' => 'ميناء سواكن',
                'name_en' => 'Suakin Seaport',
                'city_ar' => 'سواكن',
                'city_en' => 'Suakin',
                'type' => 'seaport',
            ],

            // Saudi Arabia Seaports
            [
                'country_id' => $saudiArabia->id,
                'iata_code' => 'JDS',
                'name_ar' => 'ميناء جدة الإسلامي',
                'name_en' => 'Jeddah Islamic Seaport',
                'city_ar' => 'جدة',
                'city_en' => 'Jeddah',
                'type' => 'seaport',
            ],
            [
                'country_id' => $saudiArabia->id,
                'iata_code' => 'DMS',
                'name_ar' => 'ميناء الملك عبدالعزيز',
                'name_en' => 'King Abdulaziz Seaport',
                'city_ar' => 'الدمام',
                'city_en' => 'Dammam',
                'type' => 'seaport',
            ],

            // Egypt Seaports
            [
                'country_id' => $egypt->id,
                'iata_code' => 'ALS',
                'name_ar' => 'ميناء الإسكندرية',
                'name_en' => 'Alexandria Seaport',
                'city_ar' => 'الإسكندرية',
                'city_en' => 'Alexandria',
                'type' => 'seaport',
            ],
            [
                'country_id' => $egypt->id,
                'iata_code' => 'SHS',
                'name_ar' => 'ميناء شرم الشيخ',
                'name_en' => 'Sharm El-Sheikh Seaport',
                'city_ar' => 'شرم الشيخ',
                'city_en' => 'Sharm El-Sheikh',
                'type' => 'seaport',
            ],

            // UAE Seaports
            [
                'country_id' => $uae->id,
                'iata_code' => 'JAS',
                'name_ar' => 'ميناء جبل علي',
                'name_en' => 'Jebel Ali Seaport',
                'city_ar' => 'دبي',
                'city_en' => 'Dubai',
                'type' => 'seaport',
            ],
        ];

        foreach ($seaports as $seaportData) {
            Airport::updateOrCreate(
                ['iata_code' => $seaportData['iata_code'], 'type' => 'seaport'],
                $seaportData
            );
        }

        $this->command->info('Seaports seeded successfully!');
    }
}
