<?php

namespace Database\Seeders;

use App\Models\Agency;
use App\Models\CargoService;
use Illuminate\Database\Seeder;

class CargoServiceSeeder extends Seeder
{
    public function run(): void
    {
        $agency = Agency::first();

        if (!$agency) {
            $this->command->error('No agency found. Please create an agency first.');
            return;
        }

        $services = [
            // Sea Services
            [
                'agency_id' => $agency->id,
                'type' => 'sea',
                'price_per_kg' => 15.00,
                'min_weight' => 10.00,
                'max_weight' => 200.00,
                'route_from' => 'sudan',
                'route_to' => 'saudi_arabia',
                'delivery_time_estimate' => '5-7 أيام',
                'estimated_days' => 6,
                'status' => 'active',
            ],
            [
                'agency_id' => $agency->id,
                'type' => 'sea',
                'price_per_kg' => 12.00,
                'min_weight' => 20.00,
                'max_weight' => 500.00,
                'route_from' => 'sudan',
                'route_to' => 'egypt',
                'delivery_time_estimate' => '3-5 أيام',
                'estimated_days' => 4,
                'status' => 'active',
            ],
            [
                'agency_id' => $agency->id,
                'type' => 'sea',
                'price_per_kg' => 18.00,
                'min_weight' => 5.00,
                'max_weight' => 100.00,
                'route_from' => 'sudan',
                'route_to' => 'united_arab_emirates',
                'delivery_time_estimate' => '7-10 أيام',
                'estimated_days' => 8,
                'status' => 'active',
            ],

            // Air Services
            [
                'agency_id' => $agency->id,
                'type' => 'air',
                'price_per_kg' => 45.00,
                'min_weight' => 1.00,
                'max_weight' => 50.00,
                'route_from' => 'sudan',
                'route_to' => 'saudi_arabia',
                'delivery_time_estimate' => '1-2 يوم',
                'estimated_days' => 1,
                'status' => 'active',
            ],
            [
                'agency_id' => $agency->id,
                'type' => 'air',
                'price_per_kg' => 50.00,
                'min_weight' => 0.5,
                'max_weight' => 30.00,
                'route_from' => 'egypt',
                'route_to' => 'saudi_arabia',
                'delivery_time_estimate' => '1 يوم',
                'estimated_days' => 1,
                'status' => 'active',
            ],

            // Land Services
            [
                'agency_id' => $agency->id,
                'type' => 'land',
                'price_per_kg' => 8.00,
                'min_weight' => 50.00,
                'max_weight' => 1000.00,
                'route_from' => 'sudan',
                'route_to' => 'egypt',
                'delivery_time_estimate' => '5-7 أيام',
                'estimated_days' => 6,
                'status' => 'active',
            ],
            [
                'agency_id' => $agency->id,
                'type' => 'land',
                'price_per_kg' => 10.00,
                'min_weight' => 30.00,
                'max_weight' => 500.00,
                'route_from' => 'egypt',
                'route_to' => 'saudi_arabia',
                'delivery_time_estimate' => '7-10 أيام',
                'estimated_days' => 8,
                'status' => 'active',
            ],
        ];

        foreach ($services as $service) {
            CargoService::create($service);
            $this->command->info("Created cargo service: {$service['route_from']} → {$service['route_to']} ({$service['type']})");
        }

        $this->command->info('✅ Created ' . count($services) . ' cargo services successfully!');
    }
}
