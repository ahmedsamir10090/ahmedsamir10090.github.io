<?php

namespace Database\Seeders;

use App\Models\Flight;
use App\Models\Airport;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class SeaFlightSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get seaports
        $portSudan = Airport::where('iata_code', 'PZS')->first();
        $suakin = Airport::where('iata_code', 'SUK')->first();
        $jeddah = Airport::where('iata_code', 'JDS')->first();
        $dammam = Airport::where('iata_code', 'DMS')->first();
        $alexandria = Airport::where('iata_code', 'ALS')->first();
        $sharm = Airport::where('iata_code', 'SHS')->first();
        $jabalAli = Airport::where('iata_code', 'JAS')->first();

        if (!$portSudan || !$jeddah) {
            $this->command->warn('Required seaports not found. Please run SeaportSeeder first.');
            return;
        }

        $seaFlights = [
            // Port Sudan to Jeddah
            [
                'flight_number' => 'SF101',
                'type' => 'sea',
                'origin_airport_id' => $portSudan->id,
                'destination_airport_id' => $jeddah->id,
                'departure_time' => Carbon::now()->addDays(5)->setTime(8, 0),
                'arrival_time' => Carbon::now()->addDays(5)->setTime(18, 0),
                'available_seats' => 200,
                'price' => 200.00,
                'adult_price' => 200.00,
                'child_price' => 100.00,
                'status' => 'active',
            ],
            [
                'flight_number' => 'SF102',
                'type' => 'sea',
                'origin_airport_id' => $portSudan->id,
                'destination_airport_id' => $jeddah->id,
                'departure_time' => Carbon::now()->addDays(12)->setTime(8, 0),
                'arrival_time' => Carbon::now()->addDays(12)->setTime(18, 0),
                'available_seats' => 200,
                'price' => 200.00,
                'adult_price' => 200.00,
                'child_price' => 100.00,
                'status' => 'active',
            ],
            
            // Jeddah to Port Sudan
            [
                'flight_number' => 'SF201',
                'type' => 'sea',
                'origin_airport_id' => $jeddah->id,
                'destination_airport_id' => $portSudan->id,
                'departure_time' => Carbon::now()->addDays(7)->setTime(9, 0),
                'arrival_time' => Carbon::now()->addDays(7)->setTime(19, 0),
                'available_seats' => 200,
                'price' => 200.00,
                'adult_price' => 200.00,
                'child_price' => 100.00,
                'status' => 'active',
            ],

            // Port Sudan to Dammam
            [
                'flight_number' => 'SF103',
                'type' => 'sea',
                'origin_airport_id' => $portSudan->id,
                'destination_airport_id' => $dammam->id,
                'departure_time' => Carbon::now()->addDays(8)->setTime(7, 0),
                'arrival_time' => Carbon::now()->addDays(8)->setTime(20, 0),
                'available_seats' => 180,
                'price' => 250.00,
                'adult_price' => 250.00,
                'child_price' => 125.00,
                'status' => 'active',
            ],

            // Port Sudan to Alexandria
            [
                'flight_number' => 'SF301',
                'type' => 'sea',
                'origin_airport_id' => $portSudan->id,
                'destination_airport_id' => $alexandria->id,
                'departure_time' => Carbon::now()->addDays(6)->setTime(6, 0),
                'arrival_time' => Carbon::now()->addDays(6)->setTime(16, 0),
                'available_seats' => 150,
                'price' => 180.00,
                'adult_price' => 180.00,
                'child_price' => 90.00,
                'status' => 'active',
            ],

            // Alexandria to Port Sudan
            [
                'flight_number' => 'SF302',
                'type' => 'sea',
                'origin_airport_id' => $alexandria->id,
                'destination_airport_id' => $portSudan->id,
                'departure_time' => Carbon::now()->addDays(9)->setTime(7, 0),
                'arrival_time' => Carbon::now()->addDays(9)->setTime(17, 0),
                'available_seats' => 150,
                'price' => 180.00,
                'adult_price' => 180.00,
                'child_price' => 90.00,
                'status' => 'active',
            ],

            // Jeddah to Dubai (Jabal Ali)
            [
                'flight_number' => 'SF401',
                'type' => 'sea',
                'origin_airport_id' => $jeddah->id,
                'destination_airport_id' => $jabalAli->id,
                'departure_time' => Carbon::now()->addDays(4)->setTime(10, 0),
                'arrival_time' => Carbon::now()->addDays(4)->setTime(22, 0),
                'available_seats' => 250,
                'price' => 300.00,
                'adult_price' => 300.00,
                'child_price' => 150.00,
                'status' => 'active',
            ],

            // Dubai to Jeddah
            [
                'flight_number' => 'SF402',
                'type' => 'sea',
                'origin_airport_id' => $jabalAli->id,
                'destination_airport_id' => $jeddah->id,
                'departure_time' => Carbon::now()->addDays(10)->setTime(11, 0),
                'arrival_time' => Carbon::now()->addDays(10)->setTime(23, 0),
                'available_seats' => 250,
                'price' => 300.00,
                'adult_price' => 300.00,
                'child_price' => 150.00,
                'status' => 'active',
            ],
        ];

        foreach ($seaFlights as $flightData) {
            Flight::updateOrCreate(
                ['flight_number' => $flightData['flight_number']],
                $flightData
            );
        }

        $this->command->info('Sea flights seeded successfully!');
    }
}
