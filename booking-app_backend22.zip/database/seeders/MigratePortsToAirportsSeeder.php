<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Airport;
use App\Models\Country;

class MigratePortsToAirportsSeeder extends Seeder
{
    /**
     * Migrate ports from old 'ports' table to 'airports' table with type='seaport'
     * and update existing flights to use airport_id instead of port_id
     */
    public function run(): void
    {
        // Map of port codes to IATA-like codes (shorter, 3-letter codes)
        // Using P suffix for ports to avoid conflicts with airports
        $codeMapping = [
            'SDPZU' => 'PZS', // Port Sudan
            'SDSUK' => 'SUK', // Suakin
            'EGALY' => 'ALS', // Alexandria
            'EGPSD' => 'PSD', // Port Said
            'EGSUZ' => 'SUZ', // Suez
            'EGHUR' => 'HRP', // Hurghada Port
            'SAJED' => 'JDS', // Jeddah
            'SADMM' => 'DMS', // Dammam
            'SAJUB' => 'JBP', // Jubail Port
            'SAYNB' => 'YNP', // Yanbu Port
            'AEJEA' => 'JEA', // Jebel Ali
            'AEDXB' => 'RSD', // Rashid Port
            'AEAUH' => 'ZAY', // Zayed Port
            'AEFJR' => 'FJP', // Fujairah Port
            'KWKWI' => 'KWP', // Kuwait Port
            'KWSHU' => 'SHU', // Shuaiba
            'OMMCT' => 'MCP', // Muscat Port
            'OMSLL' => 'SLP', // Salalah Port
            'OMSOH' => 'SOP', // Sohar Port
        ];

        // Get country mapping from code to ID
        $countryMap = [
            'SD' => Country::where('code', 'SD')->first()?->id ?? 1, // Sudan
            'EG' => Country::where('code', 'EG')->first()?->id ?? 2, // Egypt
            'SA' => Country::where('code', 'SA')->first()?->id ?? 3, // Saudi Arabia
            'AE' => Country::where('code', 'AE')->first()?->id ?? 4, // UAE
            'KW' => Country::where('code', 'KW')->first()?->id ?? 5, // Kuwait
            'OM' => Country::where('code', 'OM')->first()?->id ?? 6, // Oman
        ];

        // Mapping of old port ID to new airport ID
        $portToAirportMap = [];

        // Get all ports from old table
        $ports = DB::table('ports')->get();

        foreach ($ports as $port) {
            // Extract country code from port code (first 2 letters)
            $countryCode = substr($port->code, 0, 2);
            $countryId = $countryMap[$countryCode] ?? 1;

            // Get new shorter code
            $newCode = $codeMapping[$port->code] ?? $port->code;

            // Check if airport with this code already exists
            $existingAirport = Airport::where('iata_code', $newCode)
                ->where('type', 'seaport')
                ->first();

            if ($existingAirport) {
                $portToAirportMap[$port->id] = $existingAirport->id;
                $this->command->info("Seaport '{$port->name_ar}' already exists with code {$newCode} (ID: {$existingAirport->id})");
                continue;
            }

            // Create new airport entry
            $airport = Airport::create([
                'country_id' => $countryId,
                'name_ar' => $port->name_ar,
                'name_en' => $port->name_en ?? $port->name_ar,
                'iata_code' => $newCode,
                'type' => 'seaport',
                'city_ar' => $port->city_ar,
                'city_en' => $port->city_en ?? $port->city_ar,
            ]);

            $portToAirportMap[$port->id] = $airport->id;
            $this->command->info("Migrated seaport '{$port->name_ar}' ({$port->code} → {$newCode}) to airports table (ID: {$airport->id})");
        }

        // Update existing flights to use origin_airport_id/destination_airport_id
        $flightsUpdated = 0;
        $flights = DB::table('flights')
            ->whereNotNull('origin_port_id')
            ->orWhereNotNull('destination_port_id')
            ->get();

        foreach ($flights as $flight) {
            $updates = [];

            if ($flight->origin_port_id && isset($portToAirportMap[$flight->origin_port_id])) {
                $updates['origin_airport_id'] = $portToAirportMap[$flight->origin_port_id];
            }

            if ($flight->destination_port_id && isset($portToAirportMap[$flight->destination_port_id])) {
                $updates['destination_airport_id'] = $portToAirportMap[$flight->destination_port_id];
            }

            if (!empty($updates)) {
                DB::table('flights')
                    ->where('id', $flight->id)
                    ->update($updates);
                $flightsUpdated++;
            }
        }

        $this->command->info("✅ Migration completed!");
        $this->command->info("   - Migrated " . count($portToAirportMap) . " seaports to airports table");
        $this->command->info("   - Updated {$flightsUpdated} flights to use airport IDs");
    }
}
