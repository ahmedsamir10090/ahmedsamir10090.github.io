<?php

namespace Database\Seeders;

use App\Models\Agency;
use App\Models\Flight;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Super Admin user
        $admin = User::firstOrCreate(
            ['email' => 'admin@admin.com'],
            [
                'name' => 'Super Admin',
                'password' => Hash::make('password'),
                'role' => 'admin',
                'is_active' => true,
            ]
        );

        // 2. System setting for online payments enabled
        SystemSetting::updateOrCreate(
            ['key' => 'online_payment_enabled'],
            ['value' => '1']
        );

        // 3. Two dummy agencies with flights
        if (Agency::count() === 0) {
            $agency1 = Agency::create([
                'name' => 'Blue Sky Travel',
                'license_number' => 'LIC-001',
                'status' => 'active',
                'commission_rate' => 5,
                'balance' => 0,
            ]);

            $agency2 = Agency::create([
                'name' => 'Desert Wings Logistics',
                'license_number' => 'LIC-002',
                'status' => 'active',
                'commission_rate' => 7.5,
                'balance' => 0,
            ]);

            Flight::create([
                'agency_id' => $agency1->id,
                'flight_number' => 'BS101',
                'origin' => 'KRT',
                'destination' => 'DXB',
                'departure_time' => now()->addDays(3),
                'arrival_time' => now()->addDays(3)->addHours(3),
                'price' => 250,
                'available_seats' => 120,
                'status' => 'active',
            ]);

            Flight::create([
                'agency_id' => $agency1->id,
                'flight_number' => 'BS202',
                'origin' => 'KRT',
                'destination' => 'JED',
                'departure_time' => now()->addDays(7),
                'arrival_time' => now()->addDays(7)->addHours(2),
                'price' => 300,
                'available_seats' => 100,
                'status' => 'active',
            ]);

            Flight::create([
                'agency_id' => $agency2->id,
                'flight_number' => 'DW301',
                'origin' => 'KRT',
                'destination' => 'CAI',
                'departure_time' => now()->addDays(5),
                'arrival_time' => now()->addDays(5)->addHours(2),
                'price' => 220,
                'available_seats' => 80,
                'status' => 'active',
            ]);
        }
    }
}

