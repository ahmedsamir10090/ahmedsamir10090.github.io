<?php

require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

echo "=== All Cargo Bookings ===" . PHP_EOL;
$bookings = App\Models\Booking::where('serviceable_type', 'App\Models\CargoService')
    ->get(['id', 'user_id', 'tracking_status', 'payment_status', 'created_at']);
    
if ($bookings->isEmpty()) {
    echo "❌ No cargo bookings found" . PHP_EOL;
} else {
    foreach ($bookings as $b) {
        $user = App\Models\User::find($b->user_id);
        $userName = $user ? $user->name : 'Unknown';
        $hasToken = $user && $user->fcm_token ? '✅' : '❌';
        echo "Booking ID: {$b->id} | User: {$userName} (ID: {$b->user_id}) {$hasToken} | Status: {$b->tracking_status} | Created: {$b->created_at}" . PHP_EOL;
    }
}

echo PHP_EOL . "=== Users with FCM Tokens ===" . PHP_EOL;
$users = App\Models\User::whereNotNull('fcm_token')->get(['id', 'name']);
foreach ($users as $u) {
    echo "✅ User ID: {$u->id} | Name: {$u->name}" . PHP_EOL;
}
