

<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('header', __('Business Intelligence')); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row g-3 mb-4">
        <div class="col-xxl-3 col-md-6">
            <div class="card kpi-card bg-success text-white shadow-sm h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <p class="text-uppercase small mb-1"><?php echo e(__('Total Revenue')); ?></p>
                        <h4 class="mb-0">$<?php echo e(number_format($kpis['total_revenue'], 2)); ?></h4>
                        <span class="badge bg-light text-success"><?php echo e(__('All time')); ?></span>
                    </div>
                    <div class="icon-circle bg-white text-success">
                        <i class="fas fa-money-bill-wave"></i>      
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-md-6">
            <div class="card kpi-card bg-primary text-white shadow-sm h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <p class="text-uppercase small mb-1"><?php echo e(__('Platform Commission')); ?></p>
                        <h4 class="mb-0">$<?php echo e(number_format($kpis['total_commission'], 2)); ?></h4>
                        <span class="badge bg-light text-primary"><?php echo e(__('Based on rate')); ?></span>
                    </div>
                    <div class="icon-circle bg-white text-primary">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-md-6">
            <div class="card kpi-card bg-danger text-white shadow-sm h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <p class="text-uppercase small mb-1"><?php echo e(__('Pending Orders')); ?></p>
                        <h4 class="mb-0"><?php echo e($kpis['pending_bookings']); ?></h4>
                        <span class="badge bg-light text-danger"><?php echo e(__('Action required')); ?></span>
                    </div>
                    <div class="icon-circle bg-white text-danger">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-md-6">
            <div class="card kpi-card bg-info text-white shadow-sm h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <p class="text-uppercase small mb-1"><?php echo e(__('Active Agencies')); ?></p>
                        <h4 class="mb-0"><?php echo e($kpis['active_agencies']); ?></h4>
                        <span class="badge bg-light text-info"><?php echo e($kpis['total_users']); ?> <?php echo e(__('users')); ?></span>
                    </div>
                    <div class="icon-circle bg-white text-info">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="mb-0"><?php echo e(__('Booking Statuses')); ?></h6>
                        <small class="text-muted"><?php echo e(__('Distribution across pipeline')); ?></small>
                    </div>
                    <span class="badge bg-light text-primary"><?php echo e(__('Real-time')); ?></span>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="bookingsStatusChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="mb-0"><?php echo e(__('Cargo Types')); ?></h6>
                        <small class="text-muted"><?php echo e(__('Air vs Sea vs Land')); ?></small>
                    </div>
                    <span class="badge bg-light text-info"><?php echo e(__('Mix')); ?></span>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="cargoTypesChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex align-items-center justify-content-between">
                    <h6 class="mb-0 text-warning"><?php echo e(__('Smart Alerts')); ?></h6>
                    <i class="fas fa-bell text-warning"></i>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex align-items-center">
                            <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                            <div>
                                <strong><?php echo e($alerts['stuck_bookings']); ?></strong> <?php echo e(__('bookings pending more than 48 hours')); ?>

                            </div>
                        </li>
                        <li class="list-group-item d-flex align-items-center">
                            <i class="fas fa-info-circle text-info me-2"></i>
                            <div>
                                <strong><?php echo e($alerts['inactive_agencies']); ?></strong> <?php echo e(__('agencies with no bookings in last 30 days')); ?>

                            </div>
                        </li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($alerts['stuck_bookings'] === 0 && $alerts['inactive_agencies'] === 0): ?>
                            <li class="list-group-item d-flex align-items-center text-success">
                                <i class="fas fa-check-circle me-2"></i>
                                <div><?php echo e(__('All systems operating normally')); ?></div>
                            </li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex align-items-center justify-content-between">
                    <h6 class="mb-0"><?php echo e(__('Top Performing Agencies')); ?></h6>
                    <span class="badge bg-light text-success"><?php echo e(__('Last completed')); ?></span>
                </div>
                <div class="card-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($topAgencies->count()): ?>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th><?php echo e(__('Name')); ?></th>
                                        <th class="text-end"><?php echo e(__('Completed')); ?></th>
                                        <th class="text-end"><?php echo e(__('Earnings')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $topAgencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <tr>
                                            <td><?php echo e($agency->name); ?></td>
                                            <td class="text-end"><?php echo e($agency->completed_bookings_count); ?></td>
                                            <td class="text-end">$<?php echo e(number_format($agency->completed_earnings ?? 0, 2)); ?></td>
                                        </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0"><?php echo e(__('No agency performance data yet.')); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white border-0 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="mb-0"><?php echo e(__('Recent Bookings')); ?></h6>
                        <small class="text-muted"><?php echo e(__('Latest 5 bookings')); ?></small>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($latestBookings->count()): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th><?php echo e(__('ID')); ?></th>
                                        <th><?php echo e(__('User')); ?></th>
                                        <th><?php echo e(__('Agency')); ?></th>
                                        <th class="text-end"><?php echo e(__('Amount')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                        <th><?php echo e(__('Created')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $latestBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <tr>
                                            <td><?php echo e($booking->id); ?></td>
                                            <td><?php echo e($booking->user->name ?? __('N/A')); ?></td>
                                            <td><?php echo e($booking->agency->name ?? __('N/A')); ?></td>
                                            <td class="text-end">$<?php echo e(number_format($booking->total_price, 2)); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo e($booking->status === 'completed' ? 'success' :
                                                    ($booking->status === 'pending' ? 'warning' :
                                                    ($booking->status === 'accepted' ? 'info' : 'danger'))); ?>"><?php echo e(__(strtolower($booking->status))); ?></span>
                                            </td>
                                            <td><?php echo e($booking->created_at->format('M j, Y H:i')); ?></td>
                                        </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0"><?php echo e(__('No recent bookings found.')); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const bookingStatusCtx = document.getElementById('bookingsStatusChart');
    const cargoTypesCtx = document.getElementById('cargoTypesChart');

    // البيانات القادمة من الباك اند
    const bookingStatusData = <?php echo json_encode($bookingsByStatus, 15, 512) ?>;
    const cargoTypesData = <?php echo json_encode($cargoByType, 15, 512) ?>;

    // 1. قاموس ترجمة الحالات (عدل النصوص العربية كما تحب)
    const statusTranslations = {
        'pending': 'قيد المراجعة',
        'accepted': 'مقبولة',
        'rejected': 'مرفوضة',
        'completed': 'مكتملة',
        'cancelled': 'ملغاة'
    };

    // 2. قاموس ترجمة أنواع الشحن
    const cargoTranslations = {
        'Air': 'شحن جوي',
        'Sea': 'شحن بحري',
        'Land': 'شحن بري'
    };

    const statusColors = ['#f6c23e', '#36b9cc', '#e74a3b', '#1cc88a'];
    const cargoColors = ['#4e73df', '#20c997', '#fd7e14'];

    // --- رسم مخطط الحالات ---
    new Chart(bookingStatusCtx, {
        type: 'pie',
        data: {
            // التعديل هنا: نستخدم القاموس للترجمة، ولو الكلمة مش موجودة نعرضها إنجليزي
            labels: Object.keys(bookingStatusData).map(key => statusTranslations[key] || key),
            datasets: [{
                data: Object.values(bookingStatusData),
                backgroundColor: statusColors,
                borderWidth: 1
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    rtl: true, // دعم اتجاه النص
                    labels: {
                        font: { family: 'Cairo' } // لتوحيد الخط (اختياري)
                    }
                },
                tooltip: {
                    rtl: true,
                    titleFont: { family: 'Cairo' },
                    bodyFont: { family: 'Cairo' }
                }
            }
        }
    });

    // --- رسم مخطط أنواع الشحن ---
    new Chart(cargoTypesCtx, {
        type: 'bar',
        data: {
            // التعديل هنا: ترجمة أنواع الشحن
            labels: Object.keys(cargoTypesData).map(key => cargoTranslations[key] || key),
            datasets: [{
                label: 'عدد الحجوزات', // تعريب العنوان
                data: Object.values(cargoTypesData),
                backgroundColor: cargoColors,
                borderColor: cargoColors,
                borderWidth: 1
            }]
        },
        options: {
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    rtl: true,
                    titleFont: { family: 'Cairo' },
                    bodyFont: { family: 'Cairo' }
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('styles'); ?>
<style>
    .kpi-card {
        border: none;
        border-radius: 14px;
    }
    .kpi-card .icon-circle {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        font-size: 1.1rem;
    }
    .chart-area {
        position: relative;
        height: 20rem;
        width: 100%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>