

<?php $__env->startSection('title', 'إدارة الرحلات'); ?>
<?php $__env->startSection('header', 'إدارة الرحلات'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0">الرحلات</h5>
        <small class="text-muted">إدارة رحلات الطيران</small>
    </div>
    <a href="<?php echo e(route('admin.flights.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>إضافة رحلة جديدة
    </a>
</div>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="card shadow">
    <div class="card-body">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flights->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>الرقم</th>
                            <th>رقم الرحلة</th>
                            <th>الوكالة</th>
                            <th>المسار</th>
                            <th>المغادرة</th>
                            <th>سعر البالغين</th>
                            <th>سعر الأطفال</th>
                            <th>المقاعد</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($flight->id); ?></td>
                                <td class="fw-semibold"><?php echo e($flight->flight_number); ?></td>
                                <td><?php echo e($flight->agency->name ?? 'غير محدد'); ?></td>
                                <td>
                                    <?php echo e($flight->origin); ?> &larr; <?php echo e($flight->destination); ?>

                                </td>
                                <td>
                                    <?php echo e(optional($flight->departure_time)->format('Y-m-d H:i')); ?>

                                </td>
                                <td>$<?php echo e(number_format($flight->adult_price ?? $flight->price, 2)); ?></td>
                                <td>$<?php echo e(number_format($flight->child_price ?? $flight->price * 0.7, 2)); ?></td>
                                <td><?php echo e($flight->available_seats); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->status === 'active'): ?>
                                        <span class="badge bg-success">نشطة</span>
                                    <?php elseif($flight->status === 'pending'): ?>
                                        <span class="badge bg-warning">قيد الانتظار</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">ملغاة</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.flights.show', $flight->id)); ?>" class="btn btn-sm btn-info" title="عرض">
                                            <i class="fas fa-eye"></i>  عرض
                                        </a>
                                        <a href="<?php echo e(route('admin.flights.edit', $flight->id)); ?>" class="btn btn-sm btn-primary" title="تعديل">
                                            <i class="fas fa-edit"></i> تعديل
                                        </a>
                                        <form action="<?php echo e(route('admin.flights.destroy', $flight->id)); ?>" method="POST" class="d-inline"
                                              onsubmit="return confirm('هل أنت متأكد من حذف هذه الرحلة؟')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="حذف">
                                                <i class="fas fa-trash"></i> حذف
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($flights->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-plane fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">لا توجد رحلات</h5>
                <p class="text-muted">سوف تظهر الرحلات هنا بعد إضافتها</p>
                <a href="<?php echo e(route('admin.flights.create')); ?>" class="btn btn-primary mt-2">
                    <i class="fas fa-plus me-1"></i> إضافة رحلة جديدة
                </a>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/flights/index.blade.php ENDPATH**/ ?>