

<?php $__env->startSection('title', 'المدفوعات المعلقة'); ?>
<?php $__env->startSection('header', 'المدفوعات المعلقة للتحقق'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow">
    <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="fas fa-hourglass-half me-2"></i>
            إيصالات الدفع في انتظار المراجعة
        </h5>
        <span class="badge bg-dark"><?php echo e($bookings->total()); ?> حجز</span>
    </div>
    <div class="card-body">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bookings->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>العميل</th>
                            <th>نوع الخدمة</th>
                            <th>المبلغ</th>
                            <th>الإيصال</th>
                            <th>تاريخ الحجز</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('admin.bookings.show', $booking->id)); ?>" class="fw-bold">
                                        #<?php echo e($booking->id); ?>

                                    </a>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($booking->user->name ?? 'غير معروف'); ?></strong>
                                    </div>
                                    <small class="text-muted"><?php echo e($booking->user->email ?? ''); ?></small>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === \App\Models\Flight::class): ?>
                                        <?php
                                            $flightType = $booking->serviceable->flight_type ?? 'air';
                                        ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                            <span class="badge bg-primary"><i class="fas fa-ship me-1"></i>رحلة بحرية</span>
                                        <?php else: ?>
                                            <span class="badge bg-info"><i class="fas fa-plane me-1"></i>رحلة طيران</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge bg-warning"><i class="fas fa-box me-1"></i>شحن</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <span class="fw-bold text-primary">$<?php echo e(number_format($booking->total_price, 2)); ?></span>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_proof_image): ?>
                                        <a href="<?php echo e(asset('storage/' . $booking->payment_proof_image)); ?>" 
                                           target="_blank" 
                                           class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-image me-1"></i>عرض
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">لا يوجد</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <small><?php echo e($booking->created_at->format('Y-m-d')); ?></small>
                                    <br>
                                    <small class="text-muted"><?php echo e($booking->created_at->diffForHumans()); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.bookings.show', $booking->id)); ?>" 
                                           class="btn btn-info" 
                                           title="عرض التفاصيل">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.bookings.approve-payment', $booking->id)); ?>" 
                                              method="POST" 
                                              class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" 
                                                    class="btn btn-success" 
                                                    title="قبول"
                                                    onclick="return confirm('هل أنت متأكد من الموافقة على الدفع؟')">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                        <button type="button" 
                                                class="btn btn-danger" 
                                                title="رفض"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#rejectModal<?php echo e($booking->id); ?>">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <!-- Reject Modal for each booking -->
                            <div class="modal fade" id="rejectModal<?php echo e($booking->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-white">
                                            <h5 class="modal-title">رفض إيصال الحجز #<?php echo e($booking->id); ?></h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <form action="<?php echo e(route('admin.bookings.reject-payment', $booking->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label class="form-label">سبب الرفض <span class="text-danger">*</span></label>
                                                    <textarea class="form-control" 
                                                              name="rejection_reason" 
                                                              rows="3" 
                                                              required
                                                              placeholder="مثال: الإيصال غير واضح، المبلغ غير صحيح..."></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fas fa-times me-1"></i>رفض وإرسال إشعار
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($bookings->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-check-circle text-success fa-4x mb-3"></i>
                <h5 class="text-muted">لا توجد إيصالات معلقة للمراجعة</h5>
                <p class="text-muted">جميع المدفوعات تمت مراجعتها</p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/bookings/pending-payments.blade.php ENDPATH**/ ?>