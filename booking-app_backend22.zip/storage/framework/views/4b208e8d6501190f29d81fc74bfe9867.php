

<?php $__env->startSection('title', __('New Cargo Shipment Booking')); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0"><?php echo e(__('New Cargo Shipment Booking')); ?></h2>
        <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-right me-2"></i><?php echo e(__('Back to Bookings')); ?>

        </a>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <li><?php echo e($error); ?></li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <form action="<?php echo e(route('admin.cargo.bookings.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <!-- Step 1: Select Route -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-route me-2"></i><?php echo e(__('Step 1: Select Route')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('From Country')); ?> <span class="text-danger">*</span></label>
                        <select name="route_from" id="route_from" class="form-select <?php $__errorArgs = ['route_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value=""><?php echo e(__('Select Country')); ?></option>
                            <option value="sudan" <?php echo e(old('route_from') == 'sudan' ? 'selected' : ''); ?>><?php echo e(__('Sudan')); ?></option>
                            <option value="egypt" <?php echo e(old('route_from') == 'egypt' ? 'selected' : ''); ?>><?php echo e(__('Egypt')); ?></option>
                            <option value="saudi_arabia" <?php echo e(old('route_from') == 'saudi_arabia' ? 'selected' : ''); ?>><?php echo e(__('Saudi Arabia')); ?></option>
                            <option value="uae" <?php echo e(old('route_from') == 'uae' ? 'selected' : ''); ?>><?php echo e(__('UAE')); ?></option>
                            <option value="oman" <?php echo e(old('route_from') == 'oman' ? 'selected' : ''); ?>><?php echo e(__('Oman')); ?></option>
                            <option value="south_sudan" <?php echo e(old('route_from') == 'south_sudan' ? 'selected' : ''); ?>><?php echo e(__('South Sudan')); ?></option>
                            <option value="kuwait" <?php echo e(old('route_from') == 'kuwait' ? 'selected' : ''); ?>><?php echo e(__('Kuwait')); ?></option>
                            <option value="bahrain" <?php echo e(old('route_from') == 'bahrain' ? 'selected' : ''); ?>><?php echo e(__('Bahrain')); ?></option>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['route_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('To Country')); ?> <span class="text-danger">*</span></label>
                        <select name="route_to" id="route_to" class="form-select <?php $__errorArgs = ['route_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value=""><?php echo e(__('Select Country')); ?></option>
                            <option value="sudan" <?php echo e(old('route_to') == 'sudan' ? 'selected' : ''); ?>><?php echo e(__('Sudan')); ?></option>
                            <option value="egypt" <?php echo e(old('route_to') == 'egypt' ? 'selected' : ''); ?>><?php echo e(__('Egypt')); ?></option>
                            <option value="saudi_arabia" <?php echo e(old('route_to') == 'saudi_arabia' ? 'selected' : ''); ?>><?php echo e(__('Saudi Arabia')); ?></option>
                            <option value="uae" <?php echo e(old('route_to') == 'uae' ? 'selected' : ''); ?>><?php echo e(__('UAE')); ?></option>
                            <option value="oman" <?php echo e(old('route_to') == 'oman' ? 'selected' : ''); ?>><?php echo e(__('Oman')); ?></option>
                            <option value="south_sudan" <?php echo e(old('route_to') == 'south_sudan' ? 'selected' : ''); ?>><?php echo e(__('South Sudan')); ?></option>
                            <option value="kuwait" <?php echo e(old('route_to') == 'kuwait' ? 'selected' : ''); ?>><?php echo e(__('Kuwait')); ?></option>
                            <option value="bahrain" <?php echo e(old('route_to') == 'bahrain' ? 'selected' : ''); ?>><?php echo e(__('Bahrain')); ?></option>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['route_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <button type="button" id="btn_search_services" class="btn btn-primary">
                    <i class="fas fa-search me-2"></i><?php echo e(__('Search Available Services')); ?>

                </button>
            </div>
        </div>

        <!-- Step 2: Select Cargo Service -->
        <div class="card mb-4" id="services_container" style="display: none;">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-box me-2"></i><?php echo e(__('Step 2: Select Cargo Service')); ?></h5>
            </div>
            <div class="card-body">
                <div id="services_list" class="row">
                    <!-- Will be filled by AJAX -->
                </div>
                <div id="no_services" class="text-center text-muted" style="display: none;">
                    <i class="fas fa-info-circle fa-3x mb-3"></i>
                    <h5><?php echo e(__('No cargo services available for this route')); ?></h5>
                    <p><?php echo e(__('Please select different countries or contact agency to add service')); ?></p>
                </div>
            </div>
        </div>

        <!-- Step 3: Sender Information -->
        <div class="card mb-4" id="sender_container" style="display: none;">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-user me-2"></i><?php echo e(__('Step 3: Sender Information')); ?></h5>
            </div>
            <div class="card-body">
                <input type="hidden" name="cargo_service_id" id="cargo_service_id" value="<?php echo e(old('cargo_service_id')); ?>">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Sender Name')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="sender_name" class="form-control <?php $__errorArgs = ['sender_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('sender_name')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sender_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Phone Number')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="sender_phone" class="form-control <?php $__errorArgs = ['sender_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('sender_phone')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sender_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('WhatsApp Number')); ?> <small class="text-muted">(<?php echo e(__('Optional')); ?>)</small></label>
                        <input type="text" name="sender_whatsapp" class="form-control <?php $__errorArgs = ['sender_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('sender_whatsapp')); ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sender_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('City')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="sender_city" class="form-control <?php $__errorArgs = ['sender_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('sender_city')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sender_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label"><?php echo e(__('Passport Image')); ?> <span class="text-danger">*</span></label>
                        <input type="file" name="sender_passport_image" class="form-control <?php $__errorArgs = ['sender_passport_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               accept="image/*,.pdf" required>
                        <small class="text-muted"><?php echo e(__('Upload clear image of passport')); ?> (Max: 5MB)</small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sender_passport_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 4: Receiver Information -->
        <div class="card mb-4" id="receiver_container" style="display: none;">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="fas fa-user-check me-2"></i><?php echo e(__('Step 4: Receiver Information')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Receiver Name')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_name" class="form-control <?php $__errorArgs = ['receiver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('receiver_name')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['receiver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Phone Number')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_phone" class="form-control <?php $__errorArgs = ['receiver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('receiver_phone')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['receiver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('WhatsApp Number')); ?> <small class="text-muted">(<?php echo e(__('Optional')); ?>)</small></label>
                        <input type="text" name="receiver_whatsapp" class="form-control <?php $__errorArgs = ['receiver_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('receiver_whatsapp')); ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['receiver_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('City')); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="receiver_city" class="form-control <?php $__errorArgs = ['receiver_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('receiver_city')); ?>" required>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['receiver_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 5: Shipment Details -->
        <div class="card mb-4" id="shipment_container" style="display: none;">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-box-open me-2"></i><?php echo e(__('Step 5: Shipment Details')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Shipment Type')); ?> <span class="text-danger">*</span></label>
                        <select name="shipment_type" class="form-select <?php $__errorArgs = ['shipment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value=""><?php echo e(__('Select Type')); ?></option>
                            <option value="documents" <?php echo e(old('shipment_type') == 'documents' ? 'selected' : ''); ?>><?php echo e(__('Documents')); ?></option>
                            <option value="parcels" <?php echo e(old('shipment_type') == 'parcels' ? 'selected' : ''); ?>><?php echo e(__('Parcels')); ?></option>
                            <option value="goods" <?php echo e(old('shipment_type') == 'goods' ? 'selected' : ''); ?>><?php echo e(__('Goods')); ?></option>
                            <option value="personal_effects" <?php echo e(old('shipment_type') == 'personal_effects' ? 'selected' : ''); ?>><?php echo e(__('Personal Effects')); ?></option>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['shipment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('Weight (kg)')); ?> <span class="text-danger">*</span></label>
                        <input type="number" name="weight" id="weight" step="0.01" class="form-control <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('weight')); ?>" required>
                        <small class="text-muted" id="weight_range"><!-- Will be filled by JS --></small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label"><?php echo e(__('Contents Description')); ?> <span class="text-danger">*</span></label>
                        <textarea name="contents_description" rows="3" class="form-control <?php $__errorArgs = ['contents_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  placeholder="<?php echo e(__('Please provide detailed description of the contents')); ?>" required><?php echo e(old('contents_description')); ?></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['contents_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="no_prohibited_items" class="form-check-input <?php $__errorArgs = ['no_prohibited_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="no_prohibited_items" value="1" <?php echo e(old('no_prohibited_items') ? 'checked' : ''); ?> required>
                            <label class="form-check-label" for="no_prohibited_items">
                                <?php echo e(__('I declare that this shipment does not contain any prohibited items')); ?>

                            </label>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['no_prohibited_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <small class="text-muted">
                            <?php echo e(__('Prohibited items include: weapons, explosives, flammable materials, drugs, and any illegal substances')); ?>

                        </small>
                    </div>
                </div>

                <!-- Price Summary -->
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title"><?php echo e(__('Price Summary')); ?></h6>
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td><?php echo e(__('Price per KG')); ?>:</td>
                                        <td class="text-end"><strong id="price_per_kg_display">0.00</strong> <?php echo e(__('SDG')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Weight')); ?>:</td>
                                        <td class="text-end"><strong id="weight_display">0.00</strong> <?php echo e(__('kg')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Insurance Fee')); ?>:</td>
                                        <td class="text-end">
                                            <input type="number" name="insurance_fee" id="insurance_fee" step="0.01" class="form-control form-control-sm text-end" value="<?php echo e(old('insurance_fee', 0)); ?>" style="width: 100px; display: inline;">
                                            <?php echo e(__('SDG')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td><?php echo e(__('Customs Fee')); ?>:</td>
                                        <td class="text-end">
                                            <input type="number" name="customs_fee" id="customs_fee" step="0.01" class="form-control form-control-sm text-end" value="<?php echo e(old('customs_fee', 0)); ?>" style="width: 100px; display: inline;">
                                            <?php echo e(__('SDG')); ?>

                                        </td>
                                    </tr>
                                    <tr class="table-primary">
                                        <td><strong><?php echo e(__('Total')); ?>:</strong></td>
                                        <td class="text-end">
                                            <strong id="total_price_display">0.00</strong> <?php echo e(__('SDG')); ?>

                                            <input type="hidden" name="total_price" id="total_price" value="0">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i><?php echo e(__('Cancel')); ?>

                    </a>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-check me-2"></i><?php echo e(__('Create Cargo Booking')); ?>

                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
let selectedService = null;

// Search for services
$('#btn_search_services').on('click', function() {
    const from = $('#route_from').val();
    const to = $('#route_to').val();
    
    if (!from || !to) {
        alert('<?php echo e(__("Please select both countries")); ?>');
        return;
    }
    
    if (from === to) {
        alert('<?php echo e(__("From and To countries must be different")); ?>');
        return;
    }
    
    // Show loading
    $('#services_list').html('<div class="col-12 text-center"><i class="fas fa-spinner fa-spin fa-3x"></i></div>');
    $('#services_container').show();
    
    // Fetch services
    $.ajax({
        url: '<?php echo e(route("admin.cargo.bookings.services")); ?>',
        method: 'GET',
        data: { from: from, to: to },
        success: function(response) {
            if (response.services.length === 0) {
                $('#services_list').html('');
                $('#no_services').show();
            } else {
                $('#no_services').hide();
                let html = '';
                response.services.forEach(service => {
                    html += `
                        <div class="col-md-6 mb-3">
                            <div class="card service-card" data-service='${JSON.stringify(service)}' style="cursor: pointer;">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-0">${service.agency_name}</h6>
                                        <span class="badge bg-primary">${service.type_label}</span>
                                    </div>
                                    <p class="text-muted mb-2 small">
                                        <i class="fas fa-route me-1"></i>
                                        ${service.route_from_label} → ${service.route_to_label}
                                    </p>
                                    <div class="row">
                                        <div class="col-6">
                                            <small class="text-muted"><?php echo e(__("Price per KG")); ?></small>
                                            <p class="mb-0"><strong>${service.price_per_kg} <?php echo e(__("SDG")); ?></strong></p>
                                        </div>
                                        <div class="col-6">
                                            <small class="text-muted"><?php echo e(__("Weight Range")); ?></small>
                                            <p class="mb-0">${service.min_weight} - ${service.max_weight} <?php echo e(__("kg")); ?></p>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <small class="text-muted"><?php echo e(__("Estimated Delivery")); ?>: ${service.estimated_days} <?php echo e(__("days")); ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
                $('#services_list').html(html);
                
                // Handle service selection
                $('.service-card').on('click', function() {
                    $('.service-card').removeClass('border-success border-3');
                    $(this).addClass('border-success border-3');
                    
                    selectedService = JSON.parse($(this).attr('data-service'));
                    $('#cargo_service_id').val(selectedService.id);
                    
                    // Update weight range hint
                    $('#weight_range').text(`<?php echo e(__("Range")); ?>: ${selectedService.min_weight} - ${selectedService.max_weight} <?php echo e(__("kg")); ?>`);
                    
                    // Update price display
                    $('#price_per_kg_display').text(selectedService.price_per_kg);
                    
                    // Show next steps
                    $('#sender_container').show();
                    $('#receiver_container').show();
                    $('#shipment_container').show();
                    
                    // Scroll to sender section
                    $('html, body').animate({
                        scrollTop: $('#sender_container').offset().top - 100
                    }, 500);
                });
            }
        },
        error: function() {
            alert('<?php echo e(__("Error fetching services")); ?>');
        }
    });
});

// Calculate total price
function calculateTotal() {
    if (!selectedService) return;
    
    const weight = parseFloat($('#weight').val()) || 0;
    const insurance = parseFloat($('#insurance_fee').val()) || 0;
    const customs = parseFloat($('#customs_fee').val()) || 0;
    const pricePerKg = parseFloat(selectedService.price_per_kg);
    
    const total = (weight * pricePerKg) + insurance + customs;
    
    $('#weight_display').text(weight.toFixed(2));
    $('#total_price_display').text(total.toFixed(2));
    $('#total_price').val(total.toFixed(2));
}

$('#weight, #insurance_fee, #customs_fee').on('input', calculateTotal);
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/cargo/create-booking.blade.php ENDPATH**/ ?>