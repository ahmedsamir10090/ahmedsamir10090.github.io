

<?php $__env->startSection('title', __('Manage Bookings')); ?>
<?php $__env->startSection('header', __('Manage Bookings')); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0"><?php echo e(__('Bookings')); ?></h5>
        <small class="text-muted"><?php echo e(__('Manage customer bookings')); ?></small>
    </div>
    <div>
        <a href="<?php echo e(route('admin.cargo.bookings.create')); ?>" class="btn btn-success me-2">
            <i class="fas fa-box me-2"></i><?php echo e(__('Book Cargo Shipment')); ?>

        </a>
        <a href="<?php echo e(route('admin.bookings.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>حجز رحلة
        </a>
    </div>
</div>
<!-- Success/Error Messages -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<!-- Bookings Table -->
<div class="card shadow">
    <div class="card-body">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bookings->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th><?php echo e(__('ID')); ?></th>
                            <th><?php echo e(__('User')); ?></th>
                            <th><?php echo e(__('Agency')); ?></th>
                            <th><?php echo e(__('Type')); ?></th>
                            <th><?php echo e(__('Details')); ?></th>
                            <th><?php echo e(__('Price')); ?></th>
                            <th><?php echo e(__('Payment Method')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($booking->id); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center me-2" 
                                             style="width: 32px; height: 32px; font-size: 12px;">
                                            <?php echo e(strtoupper(substr($booking->user->name ?? 'U', 0, 1))); ?>

                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo e($booking->user->name ?? __('N/A')); ?></div>
                                            <small class="text-muted"><?php echo e($booking->user->email ?? __('N/A')); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->agency): ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->agency->logo): ?>
                                            <img src="<?php echo e(asset('storage/' . $booking->agency->logo)); ?>" alt="<?php echo e($booking->agency->name); ?>" 
                                                 class="rounded-circle" width="40" height="40">
                                        <?php else: ?>
                                            <div class="rounded-circle bg-secondary d-inline-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="fas fa-building text-white"></i>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <div class="ms-2">
                                            <div class="fw-bold"><?php echo e($booking->agency->name); ?></div>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-muted">
                                            <i class="fas fa-minus-circle me-1"></i>غير محدد
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <?php
                                        if ($booking->serviceable_type === \App\Models\Flight::class) {
                                            $flightType = $booking->serviceable->flight_type ?? 'air';
                                            $typeLabel = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
                                            $badgeColor = $flightType === 'sea' ? 'bg-primary' : 'bg-info';
                                        } else {
                                            $typeLabel = __('Cargo Service');
                                            $badgeColor = 'bg-warning';
                                        }
                                    ?>
                                    <span class="badge <?php echo e($badgeColor); ?>">
                                        <?php echo e($typeLabel); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->serviceable): ?>
                                        <?php
                                            $flight = $booking->serviceable;
                                            $flightType = $flight->flight_type ?? 'air';
                                        ?>
                                        <div>
                                            <strong><?php echo e($flight->flight_number ?? __('N/A')); ?></strong>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                                <span class="badge bg-primary bg-opacity-25 text-primary">بحري</span>
                                            <?php else: ?>
                                                <span class="badge bg-info bg-opacity-25 text-info">جوي</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-map-marker-alt me-1"></i>
                                                <?php echo e($flight->origin ?? __('N/A')); ?> &rarr; <?php echo e($flight->destination ?? __('N/A')); ?>

                                            </small>
                                        </div>
                                    <?php elseif($booking->serviceable_type === 'App\\Models\\CargoService' && $booking->serviceable): ?>
                                        <?php
                                            $cargo = $booking->serviceable;
                                        ?>
                                        <div>
                                            <strong><?php echo e(__('Cargo Service')); ?> #<?php echo e($cargo->id); ?></strong><br>
                                            <small class="text-muted">
                                                <i class="fas fa-box me-1"></i>
                                                <?php echo e($cargo->route_from ?? __('N/A')); ?> &rarr; <?php echo e($cargo->route_to ?? __('N/A')); ?>

                                            </small><br>
                                            <small class="text-muted">
                                                <i class="fas fa-weight me-1"></i>
                                                الوزن: <?php echo e($booking->weight ?? 0); ?> كجم
                                            </small>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted"><?php echo e(__('N/A')); ?></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <strong>$<?php echo e(number_format($booking->total_price, 2)); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo e(__(strtolower(str_replace('_', ' ', $booking->payment_method)))); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($booking->status === 'completed' ? 'success' : 
                                        ($booking->status === 'paid' ? 'info' : 
                                        ($booking->status === 'pending' ? 'warning' : 'danger'))); ?>">
                                        <?php echo e(__(strtolower($booking->status))); ?>

                                    </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rejection_reason): ?>
                                        <i class="fas fa-info-circle text-danger ms-1" 
                                           data-bs-toggle="tooltip" 
                                           title="<?php echo e($booking->rejection_reason); ?>"></i>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <!-- Edit Button -->
                                        
<a href="<?php echo e(route('admin.bookings.edit', $booking->id)); ?>" 
   class="btn btn-sm btn-outline-warning" 
   title="<?php echo e(__('Edit Booking')); ?>">
    
    
    <i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?>


</a>
                                    
                                        
<a href="<?php echo e(route('admin.bookings.show', $booking->id)); ?>" 
                                           class="btn btn-sm btn-outline-primary" title="<?php echo e(__('View Details')); ?>">

    
    
        <i class="fas fa-eye"></i> <?php echo e(__('View Details')); ?>


</a>

                                        <!-- Cargo Tracking Button -->
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === \App\Models\CargoService::class): ?>
                                            <a href="<?php echo e(route('admin.cargo.bookings.tracking', $booking->id)); ?>" 
                                               class="btn btn-sm btn-outline-info" title="<?php echo e(__('View Tracking')); ?>">
                                                <i class="fas fa-map-marker-alt"></i> <?php echo e(__('View Tracking')); ?>

                                            </a>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status === 'pending'): ?>
                                            <!-- Accept Button -->
                                            <form action="<?php echo e(route('admin.bookings.accept', $booking->id)); ?>" 
                                                  method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success" 
                                                        onclick="return confirm('<?php echo e(__('Are you sure you want to accept this booking?')); ?>')"
                                                        title="<?php echo e(__('Accept Booking')); ?>">
                                                    <i class="fas fa-check"></i><?php echo e(__('Accept Booking')); ?>

                                                </button>
                                            </form>
                                            
                                            <!-- Reject Button (Triggers Modal) -->
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#rejectModal<?php echo e($booking->id); ?>"
                                                    title="<?php echo e(__('Reject Booking')); ?>">
                                                <i class="fas fa-times"></i>    <?php echo e(__('Reject Booking')); ?>

                                            </button>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status === 'cancelled' || $booking->status === 'pending'): ?>
                                            <!-- Delete Button -->
                                            <form action="<?php echo e(route('admin.bookings.destroy', $booking->id)); ?>" 
                                                  method="POST" class="d-inline"
                                                  onsubmit="return confirm('<?php echo e(__('Are you sure you want to delete this booking?')); ?>')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                        title="<?php echo e(__('Delete Booking')); ?>">
                                                    <i class="fas fa-trash"></i>    <?php echo e(__('Delete Booking')); ?>

                                                </button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($bookings->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                <h5 class="text-muted"><?php echo e(__('No bookings found')); ?></h5>
                <p class="text-muted"><?php echo e(__('When users make bookings, they will appear here.')); ?></p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<!-- Reject Modals -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status === 'pending'): ?>
        <div class="modal fade" id="rejectModal<?php echo e($booking->id); ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e(__('Reject Booking')); ?> #<?php echo e($booking->id); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form action="<?php echo e(route('admin.bookings.reject', $booking->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <?php
                                $typeLabel = $booking->serviceable_type === \App\Models\Flight::class
                                    ? __('Flight')
                                    : __('Cargo Service');
                            ?>
                            <div class="mb-3">
                                <label for="rejection_reason<?php echo e($booking->id); ?>" class="form-label">
                                    <?php echo e(__('Rejection Reason')); ?> <span class="text-danger">*</span>
                                </label>
                                <textarea class="form-control" 
                                          id="rejection_reason<?php echo e($booking->id); ?>" 
                                          name="rejection_reason" 
                                          rows="4" 
                                          placeholder="<?php echo e(__('Please provide a reason for rejecting this booking...')); ?>"
                                          required></textarea>
                                <small class="form-text text-muted">
                                    <?php echo e(__('This reason will be visible to the customer.')); ?>

                                </small>
                            </div>
                            
                            <!-- Booking Summary -->
                            <div class="alert alert-light">
                                <h6 class="mb-2"><?php echo e(__('Booking Details')); ?>:</h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong><?php echo e(__('User')); ?>:</strong> <?php echo e($booking->user->name ?? __('N/A')); ?><br>
                                        <strong><?php echo e(__('Agency')); ?>:</strong> <?php echo e($booking->agency->name ?? __('N/A')); ?>

                                    </div>
                                    <div class="col-md-6">
                                        <strong><?php echo e(__('Amount')); ?>:</strong> $<?php echo e(number_format($booking->total_price, 2)); ?><br>
                                        <strong><?php echo e(__('Type')); ?>:</strong> <?php echo e($typeLabel); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <?php echo e(__('Cancel')); ?>

                            </button>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-times me-2"></i><?php echo e(__('Reject Booking')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .table th {
        border-top: none;
        font-weight: 600;
        color: #5a5c69;
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .btn-group form {
        display: inline-block;
    }
    
    .rounded-circle {
        object-fit: cover;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>