

<?php $__env->startSection('title', __('Manage Cargo Services')); ?>
<?php $__env->startSection('header', __('Manage Cargo Services')); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h5 class="mb-0"><?php echo e(__('Cargo Services')); ?></h5>
        <small class="text-muted"><?php echo e(__('Manage cargo offerings')); ?></small>
    </div>
    <a href="<?php echo e(route('admin.cargo.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i><?php echo e(__('Add Cargo Service')); ?>

    </a>
</div>
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<div class="card shadow">
    <div class="card-body">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($services->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th><?php echo e(__('ID')); ?></th>
                            <th><?php echo e(__('Agency')); ?></th>
                            <th><?php echo e(__('Type')); ?></th>
                            <th><?php echo e(__('Route')); ?></th>
                            <th><?php echo e(__('Price / Kg')); ?></th>
                            <th><?php echo e(__('Min Weight')); ?></th>
                            <th><?php echo e(__('Delivery Time')); ?></th>
                            <th><?php echo e(__('Actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                            <tr>
                                <td><?php echo e($service->id); ?></td>
                                <td><?php echo e($service->agency->name ?? __('N/A')); ?></td>
                                <td><?php echo e(__(strtolower($service->type))); ?></td>
                                <td><?php echo e($service->route_from); ?> &rarr; <?php echo e($service->route_to); ?></td>
                                <td>$<?php echo e(number_format($service->price_per_kg, 2)); ?></td>
                                <td><?php echo e(number_format($service->min_weight, 2)); ?> <?php echo e(__('kg')); ?></td>
                                <td><?php echo e($service->delivery_time_estimate); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.cargo.edit', $service->id)); ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?>

                                        </a>
                                        <form action="<?php echo e(route('admin.cargo.destroy', $service->id)); ?>" method="POST" class="d-inline"
                                              onsubmit="return confirm('<?php echo e(__('Delete this cargo service?')); ?>')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>    <?php echo e(__('Delete')); ?>

                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($services->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-box fa-3x text-muted mb-3"></i>
                <h5 class="text-muted"><?php echo e(__('No cargo services found')); ?></h5>
                <p class="text-muted"><?php echo e(__('Cargo services will appear here once created.')); ?></p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/cargo/index.blade.php ENDPATH**/ ?>