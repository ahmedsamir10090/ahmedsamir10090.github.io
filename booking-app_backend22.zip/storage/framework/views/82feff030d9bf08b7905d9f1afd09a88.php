

<?php $__env->startSection('title', __('Tracking Number') . ' #' . $booking->id); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0"><?php echo e(__('Tracking Number')); ?>: #<?php echo e($booking->id); ?></h2>
            <p class="text-muted mb-0"><?php echo e(__('Current Status')); ?>: <span class="badge bg-primary"><?php echo e(__(ucfirst($booking->serviceable->tracking_status))); ?></span></p>
        </div>
        <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-right me-2"></i><?php echo e(__('Back to Bookings')); ?>

        </a>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="row">
        <!-- Sender Information -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><?php echo e(__('Sender Information')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong><?php echo e(__('Sender Name')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->sender_name); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Phone Number')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->sender_phone); ?></p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable->sender_whatsapp): ?>
                    <div class="mb-3">
                        <strong><?php echo e(__('WhatsApp Number')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->sender_whatsapp); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="mb-3">
                        <strong><?php echo e(__('Country')); ?>:</strong>
                        <p class="mb-1"><?php echo e(__(ucfirst($booking->serviceable->sender_country))); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('City')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->sender_city); ?></p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable->sender_passport_image): ?>
                    <div class="mb-3">
                        <strong><?php echo e(__('Passport Image')); ?>:</strong><br>
                        <a href="<?php echo e(asset('storage/' . $booking->serviceable->sender_passport_image)); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2">
                            <i class="fas fa-eye me-1"></i><?php echo e(__('View')); ?>

                        </a>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Receiver Information -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><?php echo e(__('Receiver Information')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong><?php echo e(__('Receiver Name')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->receiver_name); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Phone Number')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->receiver_phone); ?></p>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable->receiver_whatsapp): ?>
                    <div class="mb-3">
                        <strong><?php echo e(__('WhatsApp Number')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->receiver_whatsapp); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="mb-3">
                        <strong><?php echo e(__('Country')); ?>:</strong>
                        <p class="mb-1"><?php echo e(__(ucfirst($booking->serviceable->receiver_country))); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('City')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->receiver_city); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shipment Details -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><?php echo e(__('Shipment Details')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong><?php echo e(__('Weight')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->weight); ?> <?php echo e(__('kg')); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Total Price')); ?>:</strong>
                        <p class="mb-1"><?php echo e(number_format($booking->total_price, 2)); ?> <?php echo e(__('SDG')); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Contents Description')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->serviceable->contents_description); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Agency')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->agency->name ?? __('N/A')); ?></p>
                    </div>
                    <div class="mb-3">
                        <strong><?php echo e(__('Created At')); ?>:</strong>
                        <p class="mb-1"><?php echo e($booking->created_at->format('Y-m-d H:i')); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tracking Status Update -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0"><?php echo e(__('Update Status')); ?></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.cargo.bookings.update-status', $booking->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('Tracking Status')); ?> <span class="text-danger">*</span></label>
                            <select name="tracking_status" class="form-select <?php $__errorArgs = ['tracking_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value=""><?php echo e(__('Select Type')); ?></option>
                                <option value="pending" <?php echo e($booking->serviceable->tracking_status == 'pending' ? 'selected' : ''); ?>><?php echo e(__('Pending')); ?></option>
                                <option value="picked_up" <?php echo e($booking->serviceable->tracking_status == 'picked_up' ? 'selected' : ''); ?>><?php echo e(__('Picked Up')); ?></option>
                                <option value="in_transit_origin" <?php echo e($booking->serviceable->tracking_status == 'in_transit_origin' ? 'selected' : ''); ?>><?php echo e(__('In Transit (Origin)')); ?></option>
                                <option value="customs_origin" <?php echo e($booking->serviceable->tracking_status == 'customs_origin' ? 'selected' : ''); ?>><?php echo e(__('Customs (Origin)')); ?></option>
                                <option value="in_flight" <?php echo e($booking->serviceable->tracking_status == 'in_flight' ? 'selected' : ''); ?>><?php echo e(__('In Flight')); ?></option>
                                <option value="arrived_destination" <?php echo e($booking->serviceable->tracking_status == 'arrived_destination' ? 'selected' : ''); ?>><?php echo e(__('Arrived at Destination')); ?></option>
                                <option value="customs_destination" <?php echo e($booking->serviceable->tracking_status == 'customs_destination' ? 'selected' : ''); ?>><?php echo e(__('Customs (Destination)')); ?></option>
                                <option value="out_for_delivery" <?php echo e($booking->serviceable->tracking_status == 'out_for_delivery' ? 'selected' : ''); ?>><?php echo e(__('Out for Delivery')); ?></option>
                                <option value="delivered" <?php echo e($booking->serviceable->tracking_status == 'delivered' ? 'selected' : ''); ?>><?php echo e(__('Delivered')); ?></option>
                            </select>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['tracking_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('Current Location')); ?> <span class="text-danger">*</span></label>
                            <input type="text" name="current_location" class="form-control <?php $__errorArgs = ['current_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   value="<?php echo e(old('current_location', $booking->serviceable->current_location)); ?>" required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['current_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <strong><?php echo e(__('Status Updated At')); ?>:</strong>
                            <p class="mb-1"><?php echo e($booking->serviceable->status_updated_at ? $booking->serviceable->status_updated_at->format('Y-m-d H:i') : __('N/A')); ?></p>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-sync-alt me-2"></i><?php echo e(__('Update Status')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Tracking Timeline -->
    <div class="card">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0"><?php echo e(__('Tracking Status')); ?></h5>
        </div>
        <div class="card-body">
            <div class="timeline">
                <?php
                    $statuses = [
                        'pending' => __('Pending'),
                        'picked_up' => __('Picked Up'),
                        'in_transit_origin' => __('In Transit (Origin)'),
                        'customs_origin' => __('Customs (Origin)'),
                        'in_flight' => __('In Flight'),
                        'arrived_destination' => __('Arrived at Destination'),
                        'customs_destination' => __('Customs (Destination)'),
                        'out_for_delivery' => __('Out for Delivery'),
                        'delivered' => __('Delivered'),
                    ];
                    
                    $currentIndex = array_search($booking->serviceable->tracking_status, array_keys($statuses));
                ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                    <?php
                        $index = array_search($key, array_keys($statuses));
                        $isActive = $index <= $currentIndex;
                        $isCurrent = $key === $booking->serviceable->tracking_status;
                    ?>
                    
                    <div class="timeline-item <?php echo e($isActive ? 'active' : ''); ?> <?php echo e($isCurrent ? 'current' : ''); ?>">
                        <div class="timeline-marker">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isActive): ?>
                                <i class="fas fa-check-circle"></i>
                            <?php else: ?>
                                <i class="far fa-circle"></i>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="timeline-content">
                            <h6 class="mb-0"><?php echo e($label); ?></h6>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCurrent): ?>
                                <small class="text-muted"><?php echo e(__('Current Location')); ?>: <?php echo e($booking->serviceable->current_location); ?></small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .timeline {
        position: relative;
        padding: 20px 0;
    }
    
    .timeline-item {
        display: flex;
        margin-bottom: 30px;
        position: relative;
    }
    
    .timeline-item:not(:last-child)::before {
        content: '';
        position: absolute;
        right: 19px;
        top: 30px;
        height: calc(100% + 10px);
        width: 2px;
        background: #dee2e6;
    }
    
    .timeline-item.active:not(:last-child)::before {
        background: #0d6efd;
    }
    
    .timeline-marker {
        flex-shrink: 0;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #f8f9fa;
        border: 2px solid #dee2e6;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: 15px;
        position: relative;
        z-index: 1;
    }
    
    .timeline-item.active .timeline-marker {
        background: #0d6efd;
        border-color: #0d6efd;
        color: white;
    }
    
    .timeline-item.current .timeline-marker {
        background: #ffc107;
        border-color: #ffc107;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.7);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(255, 193, 7, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(255, 193, 7, 0);
        }
    }
    
    .timeline-content {
        flex-grow: 1;
        padding-right: 20px;
    }
    
    .timeline-item.active .timeline-content h6 {
        color: #0d6efd;
        font-weight: bold;
    }
    
    .timeline-item.current .timeline-content h6 {
        color: #ffc107;
        font-weight: bold;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/cargo/tracking.blade.php ENDPATH**/ ?>