

<?php $__env->startSection('title', __('Booking Details')); ?>
<?php $__env->startSection('header', __('Booking Details') . ' #' . $booking->id); ?>

<?php $__env->startSection('content'); ?>
<?php
    if ($booking->serviceable_type === \App\Models\Flight::class) {
        $flightType = $booking->serviceable->flight_type ?? 'air';
        $typeLabel = $flightType === 'sea' ? 'رحلة بحرية' : __('Flight');
    } else {
        $typeLabel = __('Cargo Service');
    }
?>
<div class="row">
    <div class="col-lg-8">
        <!-- Booking Details Card -->
        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-ticket-alt me-2"></i><?php echo e(__('Booking Information')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Booking ID')); ?></label>
                        <p class="fw-bold">#<?php echo e($booking->id); ?></p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Service Type')); ?></label>
                        <p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === \App\Models\Flight::class): ?>
                                <?php
                                    $flightType = $booking->serviceable->flight_type ?? 'air';
                                ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                    <span class="badge bg-primary"><i class="fas fa-ship me-1"></i>رحلة بحرية</span>
                                <?php else: ?>
                                    <span class="badge bg-info"><i class="fas fa-plane me-1"></i><?php echo e(__('Flight')); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php else: ?>
                                <span class="badge bg-warning"><i class="fas fa-box me-1"></i><?php echo e(__('Cargo Service')); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Status')); ?></label>
                        <p>
                            <span class="badge bg-<?php echo e($booking->status === 'completed' ? 'success' : 
                                ($booking->status === 'paid' ? 'info' : 
                                ($booking->status === 'pending' ? 'warning' : 'danger'))); ?>">
                                <?php echo e(__(strtolower($booking->status))); ?>

                            </span>
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Total Price')); ?></label>
                        <p class="fw-bold text-primary fs-4">$<?php echo e(number_format($booking->total_price, 2)); ?></p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Payment Method')); ?></label>
                        <p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_method === 'cash_on_delivery'): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-money-bill-wave me-1"></i>
                                    الدفع عند الاستلام
                                </span>
                            <?php elseif($booking->payment_method === 'manual_receipt'): ?>
                                <span class="badge bg-info">
                                    <i class="fas fa-receipt me-1"></i>
                                    إيصال تحويل بنكي
                                </span>
                            <?php elseif($booking->payment_method === 'wallet'): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-wallet me-1"></i>
                                    المحفظة
                                </span>
                            <?php elseif($booking->payment_method === 'stripe'): ?>
                                <span class="badge bg-primary">
                                    <i class="fab fa-stripe me-1"></i>
                                    Stripe
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary">
                                    <i class="fas fa-credit-card me-1"></i>
                                    <?php echo e($booking->payment_method ?? 'غير محدد'); ?>

                                </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Payment Status')); ?></label>
                        <p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'paid'): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check-circle me-1"></i>مدفوع
                                </span>
                            <?php elseif($booking->payment_status === 'pending_cod'): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-truck me-1"></i>في انتظار الدفع عند الاستلام
                                </span>
                            <?php elseif($booking->payment_status === 'pending_verification'): ?>
                                <span class="badge bg-info">
                                    <i class="fas fa-hourglass-half me-1"></i>في انتظار التحقق من الإيصال
                                </span>
                            <?php elseif($booking->payment_status === 'rejected'): ?>
                                <span class="badge bg-danger">
                                    <i class="fas fa-times-circle me-1"></i>مرفوض
                                </span>
                            <?php elseif($booking->payment_status === 'refunded'): ?>
                                <span class="badge bg-secondary">
                                    <i class="fas fa-undo me-1"></i>مسترد
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger">
                                    <i class="fas fa-clock me-1"></i>غير مدفوع
                                </span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    </div>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === \App\Models\Flight::class): ?>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">عدد المقاعد</label>
                            <p><i class="fas fa-chair me-1"></i><?php echo e($booking->seats_count ?? 1); ?> مقعد</p>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->selected_baggage_weight): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">الأمتعة المختارة</label>
                                <p><i class="fas fa-suitcase me-1"></i><?php echo e($booking->selected_baggage_weight); ?> كجم</p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === \App\Models\CargoService::class && $booking->weight): ?>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">وزن الشحنة</label>
                            <p><i class="fas fa-weight me-1"></i><?php echo e($booking->weight); ?> كجم</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small"><?php echo e(__('Created At')); ?></label>
                        <p><i class="fas fa-calendar me-1"></i><?php echo e($booking->created_at->format('M d, Y H:i A')); ?></p>
                    </div>
                </div>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->rejection_reason): ?>
                    <div class="alert alert-danger">
                        <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i><?php echo e(__('Rejection Reason')); ?></h6>
                        <p class="mb-0"><?php echo e($booking->rejection_reason); ?></p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <!-- Payment Management Card -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_method === 'cash_on_delivery' || $booking->payment_method === 'manual_receipt'): ?>
        <div class="card shadow mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="fas fa-credit-card me-2"></i>إدارة الدفع</h5>
            </div>
            <div class="card-body">
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_method === 'cash_on_delivery'): ?>
                    <div class="alert alert-info mb-4">
                        <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i>الدفع عند الاستلام</h6>
                        <p class="mb-0">العميل اختار الدفع نقداً عند استلام التذكرة/الخدمة.</p>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="text-muted small">حالة الدفع الحالية</label>
                            <p>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'paid'): ?>
                                    <span class="badge bg-success fs-6"><i class="fas fa-check-circle me-1"></i>تم استلام المبلغ</span>
                                <?php elseif($booking->payment_status === 'pending_cod'): ?>
                                    <span class="badge bg-warning text-dark fs-6"><i class="fas fa-truck me-1"></i>في انتظار الاستلام والدفع</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary fs-6"><?php echo e($booking->payment_status); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">المبلغ المطلوب</label>
                            <p class="fw-bold text-primary fs-4">$<?php echo e(number_format($booking->total_price, 2)); ?></p>
                        </div>
                    </div>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'pending_cod'): ?>
                        <hr>
                        <h6 class="mb-3"><i class="fas fa-check-double me-2"></i>تأكيد استلام المبلغ</h6>
                        <form action="<?php echo e(route('admin.bookings.approve-payment', $booking->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success" 
                                    onclick="return confirm('هل تم استلام المبلغ نقداً من العميل؟')">
                                <i class="fas fa-check me-2"></i>تأكيد استلام المبلغ
                            </button>
                        </form>
                        <small class="text-muted d-block mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            سيتم تغيير حالة الدفع إلى "مدفوع" وإرسال إشعار للعميل
                        </small>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_method === 'manual_receipt'): ?>
                    <div class="alert alert-info mb-4">
                        <h6 class="alert-heading"><i class="fas fa-university me-2"></i>تحويل بنكي</h6>
                        <p class="mb-0">العميل قام بتحويل المبلغ ورفع إيصال الدفع للمراجعة.</p>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="text-muted small">حالة التحقق من الدفع</label>
                            <p>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'paid'): ?>
                                    <span class="badge bg-success fs-6"><i class="fas fa-check-circle me-1"></i>تم التحقق والموافقة</span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_verified_at): ?>
                                        <br><small class="text-muted">تم التحقق في: <?php echo e($booking->payment_verified_at->format('Y-m-d H:i')); ?></small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php elseif($booking->payment_status === 'pending_verification'): ?>
                                    <span class="badge bg-warning text-dark fs-6"><i class="fas fa-hourglass-half me-1"></i>في انتظار المراجعة</span>
                                <?php elseif($booking->payment_status === 'rejected'): ?>
                                    <span class="badge bg-danger fs-6"><i class="fas fa-times-circle me-1"></i>تم رفض الإيصال</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary fs-6"><?php echo e($booking->payment_status); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">المبلغ المطلوب</label>
                            <p class="fw-bold text-primary fs-4">$<?php echo e(number_format($booking->total_price, 2)); ?></p>
                        </div>
                    </div>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_proof_image): ?>
                        <div class="mb-4">
                            <label class="text-muted small d-block mb-2"><i class="fas fa-image me-1"></i>إيصال الدفع المرفق</label>
                            <div class="border rounded p-3 bg-light">
                                <a href="<?php echo e(asset('storage/' . $booking->payment_proof_image)); ?>" target="_blank" class="d-block">
                                    <img src="<?php echo e(asset('storage/' . $booking->payment_proof_image)); ?>" 
                                         alt="إيصال الدفع" 
                                         class="img-fluid rounded shadow-sm" 
                                         style="max-height: 400px; cursor: pointer;">
                                </a>
                                <div class="mt-2">
                                    <a href="<?php echo e(asset('storage/' . $booking->payment_proof_image)); ?>" 
                                       target="_blank" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-external-link-alt me-1"></i>فتح في نافذة جديدة
                                    </a>
                                    <a href="<?php echo e(asset('storage/' . $booking->payment_proof_image)); ?>" 
                                       download 
                                       class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-download me-1"></i>تحميل
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning mb-4">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            لم يتم رفع إيصال الدفع بعد
                            
                            
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status !== 'paid'): ?>
                                <hr>
                                <form action="<?php echo e(route('admin.bookings.upload-receipt', $booking->id)); ?>" 
                                      method="POST" 
                                      enctype="multipart/form-data"
                                      class="mt-2">
                                    <?php echo csrf_field(); ?>
                                    <label class="form-label fw-bold">رفع الإيصال يدوياً:</label>
                                    <div class="input-group">
                                        <input type="file" 
                                               class="form-control" 
                                               name="payment_proof_image" 
                                               accept="image/*" 
                                               required>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-upload me-1"></i>رفع
                                        </button>
                                    </div>
                                    <small class="text-muted">يمكنك رفع الإيصال هنا إذا استلمته من العميل بطريقة أخرى</small>
                                </form>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'rejected' && $booking->payment_rejection_reason): ?>
                        <div class="alert alert-danger mb-4">
                            <h6 class="alert-heading"><i class="fas fa-ban me-2"></i>سبب رفض الإيصال</h6>
                            <p class="mb-0"><?php echo e($booking->payment_rejection_reason); ?></p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'pending_verification' && $booking->payment_proof_image): ?>
                        <hr>
                        <h6 class="mb-3"><i class="fas fa-tasks me-2"></i>مراجعة إيصال الدفع</h6>
                        <div class="d-flex gap-2 flex-wrap">
                            <form action="<?php echo e(route('admin.bookings.approve-payment', $booking->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success" 
                                        onclick="return confirm('هل أنت متأكد من الموافقة على إيصال الدفع؟ سيتم تأكيد الحجز وإرسال إشعار للعميل.')">
                                    <i class="fas fa-check-circle me-2"></i>قبول الإيصال وتأكيد الدفع
                                </button>
                            </form>
                            
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectPaymentModal">
                                <i class="fas fa-times-circle me-2"></i>رفض الإيصال
                            </button>
                        </div>
                        <small class="text-muted d-block mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            تأكد من صحة الإيصال والمبلغ المحول قبل الموافقة
                        </small>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Service Details Card -->
        <div class="card shadow mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i><?php echo e($typeLabel); ?> <?php echo e(__('Details')); ?></h5>
            </div>
            <div class="card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->serviceable): ?>
                    <?php
                        $flight = $booking->serviceable;
                        $flightType = $flight->flight_type ?? 'air';
                    ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الرحلة</label>
                            <p class="fw-bold fs-5">
                                <?php echo e($flight->flight_number); ?>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                    <span class="badge bg-primary"><i class="fas fa-ship"></i> بحري</span>
                                <?php else: ?>
                                    <span class="badge bg-info"><i class="fas fa-plane"></i> جوي</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">حالة الرحلة</label>
                            <p>
                                <span class="badge bg-<?php echo e($flight->status === 'active' ? 'success' : 
                                    ($flight->status === 'pending' ? 'warning' : 'danger')); ?>">
                                    <?php echo e(__(strtolower($flight->status))); ?>

                                </span>
                            </p>
                        </div>
                        
                        <!-- Origin -->
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                    <i class="fas fa-anchor me-1"></i>ميناء المغادرة
                                <?php else: ?>
                                    <i class="fas fa-plane-departure me-1"></i><?php echo e(__('Origin Airport')); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </label>
                            <p class="fw-bold"><?php echo e($flight->origin ?? __('N/A')); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea' && $flight->originPort): ?>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?php echo e($flight->originPort->city_ar ?? $flight->originPort->city_en ?? ''); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->originPort->code): ?>
                                        (<?php echo e($flight->originPort->code); ?>)
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </small>
                            <?php elseif($flight->originAirport): ?>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?php echo e($flight->originAirport->city_ar ?? $flight->originAirport->city_en ?? ''); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->originAirport->iata_code): ?>
                                        (<?php echo e($flight->originAirport->iata_code); ?>)
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        
                        <!-- Destination -->
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea'): ?>
                                    <i class="fas fa-anchor me-1"></i>ميناء الوصول
                                <?php else: ?>
                                    <i class="fas fa-plane-arrival me-1"></i><?php echo e(__('Destination Airport')); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </label>
                            <p class="fw-bold"><?php echo e($flight->destination ?? __('N/A')); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flightType === 'sea' && $flight->destinationPort): ?>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?php echo e($flight->destinationPort->city_ar ?? $flight->destinationPort->city_en ?? ''); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->destinationPort->code): ?>
                                        (<?php echo e($flight->destinationPort->code); ?>)
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </small>
                            <?php elseif($flight->destinationAirport): ?>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i>
                                    <?php echo e($flight->destinationAirport->city_ar ?? $flight->destinationAirport->city_en ?? ''); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->destinationAirport->iata_code): ?>
                                        (<?php echo e($flight->destinationAirport->iata_code); ?>)
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i><?php echo e(__('Departure')); ?></label>
                            <p><?php echo e($flight->departure_time->format('M d, Y H:i A')); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-calendar-check me-1"></i><?php echo e(__('Arrival')); ?></label>
                            <p><?php echo e($flight->arrival_time->format('M d, Y H:i A')); ?></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">مدة الرحلة</label>
                            <p>
                                <?php
                                    $duration = $flight->departure_time->diff($flight->arrival_time);
                                    $hours = $duration->h + ($duration->days * 24);
                                ?>
                                <i class="fas fa-clock me-1"></i><?php echo e($hours); ?> ساعة <?php echo e($duration->i); ?> دقيقة
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><?php echo e(__('Available Seats')); ?></label>
                            <p><i class="fas fa-chair me-1"></i><?php echo e($flight->available_seats); ?></p>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->adult_price): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">سعر البالغين</label>
                                <p class="text-success fw-bold">$<?php echo e(number_format($flight->adult_price, 2)); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->child_price): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">سعر الأطفال</label>
                                <p class="text-success fw-bold">$<?php echo e(number_format($flight->child_price, 2)); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flight->baggage_prices && is_array($flight->baggage_prices) && count($flight->baggage_prices) > 0): ?>
                            <div class="col-12 mb-3">
                                <label class="text-muted small">أسعار الأمتعة</label>
                                <div class="d-flex gap-2 flex-wrap">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $flight->baggage_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight => $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <span class="badge bg-secondary">
                                            <i class="fas fa-suitcase me-1"></i>
                                            <?php echo e($weight); ?> كجم: $<?php echo e($price); ?>

                                        </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    
                <?php elseif($booking->serviceable_type === 'App\\Models\\CargoService' && $booking->serviceable): ?>
                    <?php
                        $cargo = $booking->serviceable;
                    ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">رقم الشحنة</label>
                            <p class="fw-bold">#<?php echo e($cargo->id); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">نوع الشحن</label>
                            <p><span class="badge bg-info"><?php echo e($cargo->type ?? 'عادي'); ?></span></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>من</label>
                            <p class="fw-bold"><?php echo e($cargo->route_from ?? __('N/A')); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cargo->sender_city): ?>
                                <small class="text-muted"><?php echo e($cargo->sender_city); ?></small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small"><i class="fas fa-map-marker-alt me-1"></i>إلى</label>
                            <p class="fw-bold"><?php echo e($cargo->route_to ?? __('N/A')); ?></p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cargo->receiver_city): ?>
                                <small class="text-muted"><?php echo e($cargo->receiver_city); ?></small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">السعر لكل كجم</label>
                            <p class="text-success fw-bold">$<?php echo e(number_format($cargo->price_per_kg, 2)); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الوزن</label>
                            <p><i class="fas fa-weight me-1"></i><?php echo e($booking->weight ?? 0); ?> كجم</p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">التكلفة الإجمالية</label>
                            <p class="text-primary fw-bold">$<?php echo e(number_format($booking->total_price, 2)); ?></p>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cargo->estimated_days): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">مدة التوصيل المتوقعة</label>
                                <p><i class="fas fa-clock me-1"></i><?php echo e($cargo->estimated_days); ?> يوم</p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <div class="col-md-6 mb-3">
                            <label class="text-muted small">حالة التتبع</label>
                            <p>
                                <span class="badge bg-warning">
                                    <?php echo e($cargo->tracking_status ?? 'قيد المعالجة'); ?>

                                </span>
                            </p>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cargo->current_location): ?>
                            <div class="col-12 mb-3">
                                <label class="text-muted small">الموقع الحالي</label>
                                <p><i class="fas fa-location-arrow me-1"></i><?php echo e($cargo->current_location); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($cargo->contents_description): ?>
                            <div class="col-12 mb-3">
                                <label class="text-muted small">محتويات الشحنة</label>
                                <p class="border-start border-3 border-info ps-3"><?php echo e($cargo->contents_description); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <!-- Sender Information -->
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-user me-2"></i>معلومات المرسل</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الاسم</label>
                            <p><?php echo e($cargo->sender_name ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الهاتف</label>
                            <p><i class="fas fa-phone me-1"></i><?php echo e($cargo->sender_phone ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">واتساب</label>
                            <p><i class="fab fa-whatsapp me-1"></i><?php echo e($cargo->sender_whatsapp ?? __('N/A')); ?></p>
                        </div>
                        
                        <!-- Receiver Information -->
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-user-check me-2"></i>معلومات المستلم</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الاسم</label>
                            <p><?php echo e($cargo->receiver_name ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الهاتف</label>
                            <p><i class="fas fa-phone me-1"></i><?php echo e($cargo->receiver_phone ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">واتساب</label>
                            <p><i class="fab fa-whatsapp me-1"></i><?php echo e($cargo->receiver_whatsapp ?? __('N/A')); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <p class="text-muted"><?php echo e(__('Service details not available.')); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
        
        <!-- Passenger Information Card (للرحلات فقط) -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->serviceable_type === 'App\\Models\\Flight' && $booking->passenger_first_name): ?>
            <div class="card shadow mb-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-id-card me-2"></i>معلومات المسافر</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">اللقب</label>
                            <p><?php echo e($booking->passenger_title ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">الاسم الأول</label>
                            <p class="fw-bold"><?php echo e($booking->passenger_first_name); ?></p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">الاسم الأوسط</label>
                            <p><?php echo e($booking->passenger_middle_name ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="text-muted small">اسم العائلة</label>
                            <p class="fw-bold"><?php echo e($booking->passenger_last_name ?? __('N/A')); ?></p>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">تاريخ الميلاد</label>
                            <p><i class="fas fa-birthday-cake me-1"></i><?php echo e($booking->passenger_date_of_birth ? $booking->passenger_date_of_birth->format('Y-m-d') : __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">الجنسية</label>
                            <p><i class="fas fa-flag me-1"></i><?php echo e($booking->passenger_nationality ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">نوع المسافر</label>
                            <p>
                                <span class="badge bg-<?php echo e($booking->passenger_type === 'adult' ? 'primary' : 'info'); ?>">
                                    <?php echo e($booking->passenger_type === 'adult' ? 'بالغ' : 'طفل'); ?>

                                </span>
                            </p>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->passenger_phone): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">رقم الهاتف</label>
                                <p><i class="fas fa-phone me-1"></i><?php echo e($booking->passenger_phone); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->passenger_whatsapp): ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">واتساب</label>
                                <p><i class="fab fa-whatsapp me-1"></i><?php echo e($booking->passenger_whatsapp); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        
                        <div class="col-12"><hr></div>
                        <div class="col-12 mb-2">
                            <h6 class="fw-bold"><i class="fas fa-passport me-2"></i>معلومات جواز السفر</h6>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">رقم الجواز</label>
                            <p class="fw-bold"><?php echo e($booking->passport_number ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">دولة الإصدار</label>
                            <p><?php echo e($booking->passport_issuing_country ?? __('N/A')); ?></p>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="text-muted small">تاريخ الانتهاء</label>
                            <p>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->passport_expiry_date): ?>
                                    <?php echo e($booking->passport_expiry_date->format('Y-m-d')); ?>

                                    <?php
                                        $daysUntilExpiry = now()->diffInDays($booking->passport_expiry_date, false);
                                    ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($daysUntilExpiry < 180 && $daysUntilExpiry > 0): ?>
                                        <span class="badge bg-warning">ينتهي قريباً</span>
                                    <?php elseif($daysUntilExpiry <= 0): ?>
                                        <span class="badge bg-danger">منتهي</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php else: ?>
                                    <?php echo e(__('N/A')); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </p>
                        </div>
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->passport_image): ?>
                            <div class="col-12 mb-3">
                                <label class="text-muted small">صورة الجواز</label>
                                <div>
                                    <a href="<?php echo e(asset('storage/' . $booking->passport_image)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>عرض صورة الجواز
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="col-lg-4">
        <!-- User Information Card -->
        <div class="card shadow mb-4">
            <div class="card-header">
                <h5 class="mb-0"><?php echo e(__('User Information')); ?></h5>
            </div>
            <div class="card-body text-center">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->user): ?>
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mx-auto mb-3" 
                         style="width: 80px; height: 80px; font-size: 32px;">
                        <?php echo e(strtoupper(substr($booking->user->name, 0, 1))); ?>

                    </div>
                    <h6 class="fw-bold"><?php echo e($booking->user->name); ?></h6>
                    <p class="text-muted mb-1"><?php echo e($booking->user->email); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->user->phone): ?>
                        <p class="text-muted mb-3"><?php echo e($booking->user->phone); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    
                    <div class="text-start">
                        <div class="mb-2">
                            <small class="text-muted"><?php echo e(__('Role')); ?>:</small>
                            <span class="badge bg-info"><?php echo e(__(strtolower($booking->user->role))); ?></span>
                        </div>
                        <div class="mb-2">
                            <small class="text-muted"><?php echo e(__('Account Status')); ?>:</small>
                            <span class="badge bg-<?php echo e($booking->user->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($booking->user->is_active ? __('Active') : __('Inactive')); ?>

                            </span>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->user->wallet): ?>
                            <div>
                                <small class="text-muted"><?php echo e(__('Wallet Balance')); ?>:</small>
                                <span class="fw-bold text-success">$<?php echo e(number_format($booking->user->wallet->balance, 2)); ?></span>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted"><?php echo e(__('User information not available.')); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <!-- Agency Information Card -->
        <div class="card shadow">
            <div class="card-header">
                <h5 class="mb-0"><?php echo e(__('Agency Information')); ?></h5>
            </div>
            <div class="card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->agency): ?>
                    <div class="text-center mb-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->agency->logo): ?>
                            <img src="<?php echo e($booking->agency->logo); ?>" alt="<?php echo e($booking->agency->name); ?>" 
                                 class="rounded-circle" width="80" height="80">
                        <?php else: ?>
                            <div class="rounded-circle bg-secondary text-white d-inline-flex align-items-center justify-content-center mx-auto" 
                                 style="width: 80px; height: 80px; font-size: 32px;">
                                <i class="fas fa-building"></i>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    
                    <h6 class="fw-bold text-center"><?php echo e($booking->agency->name); ?></h6>
                    
                    <div class="mt-3">
                        <div class="mb-2">
                            <small class="text-muted"><?php echo e(__('License')); ?>:</small>
                            <p class="mb-0"><?php echo e($booking->agency->license_number ?: __('N/A')); ?></p>
                        </div>
                        <div class="mb-2">
                            <small class="text-muted"><?php echo e(__('Status')); ?>:</small>
                            <span class="badge bg-<?php echo e($booking->agency->status === 'active' ? 'success' : 'danger'); ?>">
                                <?php echo e(__(strtolower($booking->agency->status))); ?>

                            </span>
                        </div>
                        <div>
                            <small class="text-muted"><?php echo e(__('Balance')); ?>:</small>
                            <p class="mb-0 fw-bold">$<?php echo e(number_format($booking->agency->current_balance, 2)); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <p class="text-muted"><?php echo e(__('Agency information not available.')); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Action Buttons -->
<div class="mt-4">
    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i><?php echo e(__('Back to Bookings')); ?>

    </a>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status === 'pending'): ?>
        <form action="<?php echo e(route('admin.bookings.accept', $booking->id)); ?>" 
              method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success" 
                    onclick="return confirm('<?php echo e(__('Are you sure you want to accept this booking?')); ?>')">
                <i class="fas fa-check me-2"></i><?php echo e(__('Accept Booking')); ?>

            </button>
        </form>
        
        <button type="button" 
                class="btn btn-danger" 
                data-bs-toggle="modal" 
                data-bs-target="#rejectModal">
            <i class="fas fa-times me-2"></i><?php echo e(__('Reject Booking')); ?>

        </button>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<!-- Reject Modal -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->status === 'pending'): ?>
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('Reject Booking')); ?> #<?php echo e($booking->id); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="<?php echo e(route('admin.bookings.reject', $booking->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="rejection_reason" class="form-label">
                                <?php echo e(__('Rejection Reason')); ?> <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" 
                                      id="rejection_reason" 
                                      name="rejection_reason" 
                                      rows="4" 
                                      placeholder="<?php echo e(__('Please provide a reason for rejecting this booking...')); ?>"
                                      required></textarea>
                            <small class="form-text text-muted">
                                <?php echo e(__('This reason will be visible to the customer.')); ?>

                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <?php echo e(__('Cancel')); ?>

                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-times me-2"></i><?php echo e(__('Reject Booking')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<!-- Reject Payment Modal -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->payment_status === 'pending_verification'): ?>
    <div class="modal fade" id="rejectPaymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-times-circle me-2"></i>رفض إيصال الدفع</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form action="<?php echo e(route('admin.bookings.reject-payment', $booking->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            سيتم إرسال إشعار للعميل بسبب الرفض ليتمكن من رفع إيصال جديد
                        </div>
                        <div class="mb-3">
                            <label for="payment_rejection_reason" class="form-label">
                                سبب رفض الإيصال <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" 
                                      id="payment_rejection_reason" 
                                      name="rejection_reason" 
                                      rows="4" 
                                      placeholder="مثال: الإيصال غير واضح، المبلغ لا يتطابق، تاريخ التحويل قديم..."
                                      required></textarea>
                            <small class="form-text text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                هذا السبب سيظهر للعميل في الإشعار
                            </small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label text-muted small">معلومات الحجز:</label>
                            <ul class="list-unstyled mb-0">
                                <li><strong>رقم الحجز:</strong> #<?php echo e($booking->id); ?></li>
                                <li><strong>المبلغ:</strong> $<?php echo e(number_format($booking->total_price, 2)); ?></li>
                                <li><strong>العميل:</strong> <?php echo e($booking->user->name ?? 'غير معروف'); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i>إلغاء
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-ban me-2"></i>رفض الإيصال وإرسال إشعار
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sudan_booking\booking-app_backend\resources\views/admin/bookings/show.blade.php ENDPATH**/ ?>