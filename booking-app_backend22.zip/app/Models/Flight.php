<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Flight extends Model
{
    use HasFactory;

    public const STATUSES = ['pending', 'active', 'cancelled'];

    protected $fillable = [
        'agency_id',
        'flight_number',
        'type',
        'origin_airport_id',
        'destination_airport_id',
        'origin_port_id',
        'destination_port_id',
        'departure_time',
        'arrival_time',
        'price',
        'available_seats',
        'status',
        'flight_type',
        'adult_price',
        'child_price',
        'baggage_prices',
    ];

    protected $casts = [
        'departure_time' => 'datetime',
        'arrival_time' => 'datetime',
        'price' => 'decimal:2',
        'adult_price' => 'decimal:2',
        'child_price' => 'decimal:2',
        'baggage_prices' => 'array',
    ];

    public function agency(): BelongsTo
    {
        return $this->belongsTo(Agency::class);
    }

    /**
     * Get the origin airport.
     */
    public function originAirport(): BelongsTo
    {
        return $this->belongsTo(Airport::class, 'origin_airport_id');
    }

    /**
     * Get the destination airport.
     */
    public function destinationAirport(): BelongsTo
    {
        return $this->belongsTo(Airport::class, 'destination_airport_id');
    }

    /**
     * Get the origin port.
     */
    public function originPort(): BelongsTo
    {
        return $this->belongsTo(Port::class, 'origin_port_id');
    }

    /**
     * Get the destination port.
     */
    public function destinationPort(): BelongsTo
    {
        return $this->belongsTo(Port::class, 'destination_port_id');
    }

    /**
     * Get formatted origin name (backwards compatibility).
     */
    public function getOriginAttribute(): ?string
    {
        if ($this->flight_type === 'sea' && $this->originPort) {
            return $this->originPort->name;
        }
        return $this->originAirport?->display_name;
    }

    /**
     * Get formatted destination name (backwards compatibility).
     */
    public function getDestinationAttribute(): ?string
    {
        if ($this->flight_type === 'sea' && $this->destinationPort) {
            return $this->destinationPort->name;
        }
        return $this->destinationAirport?->display_name;
    }

    public function bookings(): MorphMany
    {
        return $this->morphMany(Booking::class, 'serviceable');
    }

    /**
     * Get all flight classes for this flight
     */
    public function flightClasses(): HasMany
    {
        return $this->hasMany(FlightClass::class);
    }

    /**
     * Get active flight classes
     */
    public function activeClasses(): HasMany
    {
        return $this->flightClasses()->where('is_active', true);
    }

    /**
     * Get available flight classes (active with seats)
     */
    public function availableClasses(): HasMany
    {
        return $this->flightClasses()
            ->where('is_active', true)
            ->where('available_seats', '>', 0);
    }

    /**
     * Check if flight has any available seats across all classes
     */
    public function hasAvailableSeats(): bool
    {
        return $this->flightClasses()
            ->where('is_active', true)
            ->where('available_seats', '>', 0)
            ->exists();
    }

    /**
     * Get total available seats across all classes
     */
    public function getTotalAvailableSeats(): int
    {
        return $this->flightClasses()
            ->where('is_active', true)
            ->sum('available_seats');
    }

    /**
     * Get minimum price across all active classes
     */
    public function getMinimumPrice(): ?float
    {
        return $this->flightClasses()
            ->where('is_active', true)
            ->min('price');
    }

    /**
     * Check if flight has specific class available
     */
    public function hasClass(string $classType): bool
    {
        return $this->flightClasses()
            ->where('class_type', $classType)
            ->where('is_active', true)
            ->exists();
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope: Flights with available seats
     */
    public function scopeWithAvailableSeats($query)
    {
        return $query->whereHas('flightClasses', function ($q) {
            $q->where('is_active', true)
              ->where('available_seats', '>', 0);
        });
    }
}
