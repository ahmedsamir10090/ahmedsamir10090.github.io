<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    use HasFactory;

    protected $fillable = ['key', 'value'];

    /**
     * Get setting value by key
     */
    public static function getSetting(string $key, mixed $default = null): mixed
    {
        $setting = static::where('key', $key)->first();

        if (! $setting) {
            return $default;
        }

        return $setting->value;
    }

    /**
     * Get multiple settings as key-value array
     */
    public static function getSettings(array $keys): array
    {
        $settings = static::whereIn('key', $keys)
            ->pluck('value', 'key')
            ->toArray();

        // Convert boolean values
        if (isset($settings['online_payment_enabled'])) {
            $settings['online_payment_enabled'] = (bool) $settings['online_payment_enabled'];
        }

        // Convert numeric values
        if (isset($settings['commission_rate'])) {
            $settings['commission_rate'] = (float) $settings['commission_rate'];
        }

        return $settings;
    }

    /**
     * Set or update a setting (creates if doesn't exist)
     */
    public static function setSetting(string $key, string $value): void
    {
        static::updateOrCreate(
            ['key' => $key],
            ['value' => $value]
        );
    }
}
