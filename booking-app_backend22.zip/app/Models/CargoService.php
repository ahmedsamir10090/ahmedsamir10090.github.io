<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class CargoService extends Model
{
    use HasFactory;

    protected $fillable = [
        'agency_id',
        'type',
        'price_per_kg',
        'min_weight',
        'max_weight',
        'estimated_days',
        'delivery_time_estimate',
        'route_from',
        'route_to',
        'status',
        'sender_name',
        'sender_phone',
        'sender_whatsapp',
        'sender_country',
        'sender_city',
        'sender_passport_image',
        'receiver_name',
        'receiver_phone',
        'receiver_whatsapp',
        'receiver_country',
        'receiver_city',
        'contents_description',
        'no_prohibited_items',
        'tracking_status',
        'current_location',
        'status_updated_at',
    ];

    protected $casts = [
        'price_per_kg' => 'decimal:2',
        'min_weight' => 'decimal:2',
        'max_weight' => 'decimal:2',
        'estimated_days' => 'integer',
        'no_prohibited_items' => 'boolean',
        'status_updated_at' => 'datetime',
    ];

    public function agency(): BelongsTo
    {
        return $this->belongsTo(Agency::class);
    }

    public function bookings(): MorphMany
    {
        return $this->morphMany(Booking::class, 'serviceable');
    }
}
