<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FlightClass extends Model
{
    use HasFactory;

    /**
     * Class types
     */
    public const CLASS_ECONOMY = 'economy';
    public const CLASS_BUSINESS = 'business';
    public const CLASS_FIRST = 'first';

    /**
     * Refund policy constants
     */
    public const REFUND_FULL = 'Full refund up to 24 hours before departure';
    public const REFUND_PARTIAL = 'Partial refund with cancellation fee';
    public const REFUND_NONE = 'Non-refundable';

    protected $fillable = [
        'flight_id',
        'class_type',
        'class_name',
        'price',
        'total_seats',
        'available_seats',
        'baggage_allowance',
        'refund_policy',
        'change_policy',
        'amenities',
        'is_active',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'total_seats' => 'integer',
        'available_seats' => 'integer',
        'baggage_allowance' => 'integer',
        'is_active' => 'boolean',
    ];

    /**
     * Boot method for model events
     */
    protected static function boot()
    {
        parent::boot();

        // When creating, set available_seats equal to total_seats
        static::creating(function ($flightClass) {
            if (is_null($flightClass->available_seats)) {
                $flightClass->available_seats = $flightClass->total_seats;
            }
        });
    }

    /**
     * Get the flight that owns this class
     */
    public function flight(): BelongsTo
    {
        return $this->belongsTo(Flight::class);
    }

    /**
     * Get bookings for this flight class
     */
    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    /**
     * Scope: Active classes only
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope: Available classes (has seats)
     */
    public function scopeAvailable($query)
    {
        return $query->where('available_seats', '>', 0)->where('is_active', true);
    }

    /**
     * Scope: By class type
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('class_type', $type);
    }

    /**
     * Check if seats are available
     */
    public function hasAvailableSeats(int $requestedSeats = 1): bool
    {
        return $this->is_active && $this->available_seats >= $requestedSeats;
    }

    /**
     * Reserve seats (decrements available_seats)
     */
    public function reserveSeats(int $count): bool
    {
        if (!$this->hasAvailableSeats($count)) {
            return false;
        }

        return $this->decrement('available_seats', $count);
    }

    /**
     * Release seats (increments available_seats)
     */
    public function releaseSeats(int $count): bool
    {
        // Don't exceed total_seats
        $newAvailable = $this->available_seats + $count;
        
        if ($newAvailable > $this->total_seats) {
            $newAvailable = $this->total_seats;
        }

        $this->available_seats = $newAvailable;
        return $this->save();
    }

    /**
     * Calculate total price for multiple seats
     */
    public function calculatePrice(int $seats): float
    {
        return (float) $this->price * $seats;
    }

    /**
     * Get occupancy percentage
     */
    public function getOccupancyPercentage(): float
    {
        if ($this->total_seats === 0) {
            return 0;
        }

        $booked = $this->total_seats - $this->available_seats;
        return round(($booked / $this->total_seats) * 100, 2);
    }

    /**
     * Get human-readable class type
     */
    public function getClassTypeLabel(): string
    {
        return match($this->class_type) {
            self::CLASS_ECONOMY => 'Economy',
            self::CLASS_BUSINESS => 'Business',
            self::CLASS_FIRST => 'First Class',
            default => ucfirst($this->class_type),
        };
    }

    /**
     * Check if fully booked
     */
    public function isFullyBooked(): bool
    {
        return $this->available_seats <= 0;
    }

    /**
     * Get amenities as array
     */
    public function getAmenitiesArray(): array
    {
        if (empty($this->amenities)) {
            return [];
        }

        // If stored as JSON
        if (is_string($this->amenities)) {
            $decoded = json_decode($this->amenities, true);
            if (is_array($decoded)) {
                return $decoded;
            }
            // If stored as comma-separated
            return array_map('trim', explode(',', $this->amenities));
        }

        return [];
    }

    /**
     * Toggle active status
     */
    public function toggleActive(): bool
    {
        $this->is_active = !$this->is_active;
        return $this->save();
    }

    /**
     * Get status badge color for UI
     */
    public function getStatusColor(): string
    {
        if (!$this->is_active) {
            return 'gray';
        }

        if ($this->isFullyBooked()) {
            return 'red';
        }

        $occupancy = $this->getOccupancyPercentage();
        
        if ($occupancy >= 90) {
            return 'orange';
        }

        return 'green';
    }
}
