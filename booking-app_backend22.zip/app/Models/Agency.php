<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Agency extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'license_number',
        'logo',
        'phone',
        'balance',
        'current_balance',
        'total_lifetime_earnings',
        'commission_rate',
        'status',
    ];

    protected $casts = [
        'current_balance' => 'decimal:2',
        'total_lifetime_earnings' => 'decimal:2',
    ];

    public function flights(): HasMany
    {
        return $this->hasMany(Flight::class);
    }

    public function cargoServices(): HasMany
    {
        return $this->hasMany(CargoService::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function agencyTransactions(): HasMany
    {
        return $this->hasMany(AgencyTransaction::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

        public function transactions()
    {
        // اسم الموديل هو AgencyTransaction، والمفتاح الخارجي هو agency_id
        return $this->hasMany(AgencyTransaction::class, 'agency_id', 'id');
    }
}
