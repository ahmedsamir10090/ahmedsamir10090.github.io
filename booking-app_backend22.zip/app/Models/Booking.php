<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Booking extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'agency_id',
        'serviceable_type',
        'serviceable_id',
        'seats_count',
        'weight',
        'total_price',
        'status',
        'payment_status',
        'payment_method',
        'payment_proof_image',
        'payment_rejection_reason',
        'payment_verified_at',
        'payment_verified_by',
        // معلومات المسافر
        'passenger_title',
        'passenger_first_name',
        'passenger_middle_name',
        'passenger_last_name',
        'passenger_date_of_birth',
        'passenger_nationality',
        'passenger_type',
        'passenger_phone',
        'passenger_whatsapp',
        'passport_number',
        'passport_issuing_country',
        'passport_expiry_date',
        'passport_image',
        'selected_baggage_weight',
    ];

    protected $casts = [
        'total_price' => 'decimal:2',
        'weight' => 'decimal:2',
        'seats_count' => 'integer',
        'agency_id' => 'integer',
        'passenger_date_of_birth' => 'date',
        'passport_expiry_date' => 'date',
        'payment_verified_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function agency(): BelongsTo
    {
        return $this->belongsTo(Agency::class);
    }

    public function verifiedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'payment_verified_by');
    }

    public function serviceable(): MorphTo
    {
        return $this->morphTo();
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }
}
