<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\Flight;
use App\Models\FlightClass;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class BookingService
{
    /**
     * Create a new flight booking request
     * 
     * @param User $user
     * @param Flight $flight
     * @param FlightClass $flightClass
     * @param int $seatsCount
     * @param array $additionalData
     * @return Booking
     * @throws \Exception
     */
    public function createBookingRequest(
        User $user,
        Flight $flight,
        FlightClass $flightClass,
        int $seatsCount,
        array $additionalData = []
    ): Booking {
        // Validation
        if (!$flightClass->is_active) {
            throw new \Exception('This flight class is not available.');
        }

        if (!$flightClass->hasAvailableSeats($seatsCount)) {
            throw new \Exception("Only {$flightClass->available_seats} seats available in {$flightClass->class_name}.");
        }

        if ($flight->status !== 'active') {
            throw new \Exception('This flight is not accepting bookings.');
        }

        return DB::transaction(function () use ($user, $flight, $flightClass, $seatsCount, $additionalData) {
            // Temporarily reserve seats
            $flightClass->reserveSeats($seatsCount);

            // Calculate total price
            $totalPrice = $flightClass->calculatePrice($seatsCount);

            // Create booking
            $booking = Booking::create([
                'user_id' => $user->id,
                'agency_id' => $flight->agency_id,
                'serviceable_type' => Flight::class,
                'serviceable_id' => $flight->id,
                'flight_class_id' => $flightClass->id,
                'seats_count' => $seatsCount,
                'total_price' => $totalPrice,
                'status' => Booking::STATUS_PENDING,
                'payment_status' => 'pending',
                'weight' => $additionalData['weight'] ?? null,
            ]);

            Log::info('Booking request created', [
                'booking_id' => $booking->id,
                'user_id' => $user->id,
                'flight_id' => $flight->id,
                'class_id' => $flightClass->id,
                'seats' => $seatsCount,
            ]);

            return $booking;
        });
    }

    /**
     * Agency approves a booking request
     * 
     * @param Booking $booking
     * @param User $approver (Agency staff)
     * @param string|null $notes
     * @return bool
     * @throws \Exception
     */
    public function approveBooking(Booking $booking, User $approver, ?string $notes = null): bool
    {
        if (!$booking->isPending()) {
            throw new \Exception('Only pending bookings can be approved.');
        }

        return DB::transaction(function () use ($booking, $approver, $notes) {
            $booking->update([
                'status' => Booking::STATUS_APPROVED,
                'approved_by' => $approver->id,
                'approved_at' => now(),
                'agency_notes' => $notes,
            ]);

            Log::info('Booking approved', [
                'booking_id' => $booking->id,
                'approved_by' => $approver->id,
            ]);

            // TODO: Send notification to user
            // event(new BookingApproved($booking));

            return true;
        });
    }

    /**
     * Agency rejects a booking request
     * 
     * @param Booking $booking
     * @param User $rejecter
     * @param string $reason
     * @return bool
     * @throws \Exception
     */
    public function rejectBooking(Booking $booking, User $rejecter, string $reason): bool
    {
        if (!$booking->isPending()) {
            throw new \Exception('Only pending bookings can be rejected.');
        }

        return DB::transaction(function () use ($booking, $rejecter, $reason) {
            // Release the reserved seats
            if ($booking->flightClass) {
                $booking->flightClass->releaseSeats($booking->seats_count);
            }

            $booking->update([
                'status' => Booking::STATUS_REJECTED,
                'rejected_at' => now(),
                'approved_by' => $rejecter->id, // Track who rejected
                'agency_notes' => $reason,
            ]);

            Log::info('Booking rejected', [
                'booking_id' => $booking->id,
                'rejected_by' => $rejecter->id,
                'reason' => $reason,
            ]);

            // TODO: Send notification to user
            // event(new BookingRejected($booking));

            return true;
        });
    }

    /**
     * Confirm booking after payment
     * 
     * @param Booking $booking
     * @param string $paymentMethod
     * @param string|null $paymentProofImage
     * @return bool
     * @throws \Exception
     */
    public function confirmBooking(
        Booking $booking,
        string $paymentMethod = 'cash',
        ?string $paymentProofImage = null
    ): bool {
        if (!$booking->isApproved()) {
            throw new \Exception('Only approved bookings can be confirmed.');
        }

        return DB::transaction(function () use ($booking, $paymentMethod, $paymentProofImage) {
            $booking->update([
                'status' => Booking::STATUS_CONFIRMED,
                'payment_status' => 'paid',
                'payment_method' => $paymentMethod,
                'payment_proof_image' => $paymentProofImage,
            ]);

            Log::info('Booking confirmed', [
                'booking_id' => $booking->id,
                'payment_method' => $paymentMethod,
            ]);

            // TODO: Send confirmation notification
            // event(new BookingConfirmed($booking));

            return true;
        });
    }

    /**
     * Cancel a booking
     * 
     * @param Booking $booking
     * @param User $cancelledBy
     * @param string|null $reason
     * @return bool
     * @throws \Exception
     */
    public function cancelBooking(Booking $booking, User $cancelledBy, ?string $reason = null): bool
    {
        if (!$booking->canBeCancelled()) {
            throw new \Exception('This booking cannot be cancelled.');
        }

        return DB::transaction(function () use ($booking, $cancelledBy, $reason) {
            // Release seats back to inventory
            if ($booking->flightClass) {
                $booking->flightClass->releaseSeats($booking->seats_count);
            }

            $booking->update([
                'status' => Booking::STATUS_CANCELLED,
                'agency_notes' => $reason ? "Cancelled: {$reason}" : $booking->agency_notes,
            ]);

            Log::info('Booking cancelled', [
                'booking_id' => $booking->id,
                'cancelled_by' => $cancelledBy->id,
                'reason' => $reason,
            ]);

            // TODO: Process refund based on refund policy
            // $this->processRefund($booking);

            return true;
        });
    }

    /**
     * Mark booking as completed (after flight departure)
     * 
     * @param Booking $booking
     * @return bool
     */
    public function completeBooking(Booking $booking): bool
    {
        if (!$booking->isConfirmed()) {
            throw new \Exception('Only confirmed bookings can be marked as completed.');
        }

        $booking->update([
            'status' => Booking::STATUS_COMPLETED,
        ]);

        Log::info('Booking completed', ['booking_id' => $booking->id]);

        return true;
    }

    /**
     * Get booking statistics for an agency
     * 
     * @param int $agencyId
     * @return array
     */
    public function getAgencyBookingStats(int $agencyId): array
    {
        return [
            'pending' => Booking::where('agency_id', $agencyId)->pending()->count(),
            'approved' => Booking::where('agency_id', $agencyId)->approved()->count(),
            'confirmed' => Booking::where('agency_id', $agencyId)->confirmed()->count(),
            'rejected' => Booking::where('agency_id', $agencyId)->rejected()->count(),
            'cancelled' => Booking::where('agency_id', $agencyId)->cancelled()->count(),
            'total_revenue' => Booking::where('agency_id', $agencyId)
                ->whereIn('status', [Booking::STATUS_CONFIRMED, Booking::STATUS_COMPLETED])
                ->sum('total_price'),
        ];
    }

    /**
     * Check seat availability before booking
     * 
     * @param FlightClass $flightClass
     * @param int $requestedSeats
     * @return array
     */
    public function checkAvailability(FlightClass $flightClass, int $requestedSeats): array
    {
        $available = $flightClass->hasAvailableSeats($requestedSeats);
        
        return [
            'available' => $available,
            'available_seats' => $flightClass->available_seats,
            'requested_seats' => $requestedSeats,
            'is_active' => $flightClass->is_active,
            'price_per_seat' => $flightClass->price,
            'total_price' => $flightClass->calculatePrice($requestedSeats),
            'class_name' => $flightClass->class_name,
            'baggage_allowance' => $flightClass->baggage_allowance,
        ];
    }

    /**
     * Get available flights for booking
     * 
     * @param string $origin
     * @param string $destination
     * @param string|null $date
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function searchAvailableFlights(string $origin, string $destination, ?string $date = null)
    {
        $query = Flight::query()
            ->where('status', 'active')
            ->where('origin', $origin)
            ->where('destination', $destination)
            ->withAvailableSeats()
            ->with(['flightClasses' => function ($q) {
                $q->where('is_active', true)
                  ->where('available_seats', '>', 0);
            }]);

        if ($date) {
            $query->whereDate('departure_time', $date);
        }

        return $query->orderBy('departure_time')->get();
    }
}
