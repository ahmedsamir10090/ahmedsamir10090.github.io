<?php

namespace App\Services;

use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use InvalidArgumentException;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class PaymentService
{
    protected StripeClient $stripe;

    public function __construct()
    {
        $stripeKey = config('services.stripe.secret');
        
        if ($stripeKey) {
            $this->stripe = new StripeClient($stripeKey);
        }
    }

    /**
     * Pay with wallet balance
     *
     * @param User $user
     * @param float $amount
     * @param string|null $referenceId
     * @return Transaction
     * @throws \Exception
     */
    public function payWithWallet(User $user, float $amount, ?string $referenceId = null): Transaction
    {
        if ($amount <= 0) {
            throw new InvalidArgumentException('Amount must be greater than zero');
        }

        return DB::transaction(function () use ($user, $amount, $referenceId) {
            $wallet = $user->wallet()->lockForUpdate()->firstOrCreate(
                ['user_id' => $user->id],
                ['balance' => 0, 'currency' => 'USD']
            );

            if ($wallet->balance < $amount) {
                throw new \Exception('Insufficient wallet balance');
            }

            // Deduct amount
            $wallet->balance -= $amount;
            $wallet->save();

            // Log transaction
            $transaction = $wallet->transactions()->create([
                'amount' => $amount,
                'type' => 'withdrawal',
                'reference_id' => $referenceId,
                'status' => 'completed',
            ]);

            Log::info('Wallet payment processed', [
                'user_id' => $user->id,
                'amount' => $amount,
                'transaction_id' => $transaction->id,
            ]);

            return $transaction;
        });
    }

    /**
     * Deposit to wallet
     *
     * @param User $user
     * @param float $amount
     * @param string|null $referenceId
     * @param string $status
     * @return Transaction
     */
    public function depositToWallet(User $user, float $amount, ?string $referenceId = null, string $status = 'completed'): Transaction
    {
        if ($amount <= 0) {
            throw new InvalidArgumentException('Amount must be greater than zero');
        }

        return DB::transaction(function () use ($user, $amount, $referenceId, $status) {
            $wallet = $user->wallet()->lockForUpdate()->firstOrCreate(
                ['user_id' => $user->id],
                ['balance' => 0, 'currency' => 'USD']
            );

            // Add amount
            $wallet->balance += $amount;
            $wallet->save();

            // Log transaction
            $transaction = $wallet->transactions()->create([
                'amount' => $amount,
                'type' => 'deposit',
                'reference_id' => $referenceId,
                'status' => $status,
            ]);

            Log::info('Wallet deposit processed', [
                'user_id' => $user->id,
                'amount' => $amount,
                'transaction_id' => $transaction->id,
                'status' => $status,
            ]);

            return $transaction;
        });
    }

    /**
     * Create Stripe Payment Intent
     *
     * @param float $amount
     * @param string $currency
     * @param array $metadata
     * @return array
     * @throws ApiErrorException
     */
    public function createStripeIntent(float $amount, string $currency = 'usd', array $metadata = []): array
    {
        if ($amount <= 0) {
            throw new InvalidArgumentException('Amount must be greater than zero');
        }

        if (! isset($this->stripe)) {
            throw new \Exception('Stripe is not configured. Please set STRIPE_SECRET in your .env file.');
        }

        try {
            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => (int) ($amount * 100), // Convert to cents
                'currency' => strtolower($currency),
                'metadata' => $metadata,
                'automatic_payment_methods' => [
                    'enabled' => true,
                ],
            ]);

            Log::info('Stripe Payment Intent created', [
                'payment_intent_id' => $paymentIntent->id,
                'amount' => $amount,
                'currency' => $currency,
            ]);

            return [
                'client_secret' => $paymentIntent->client_secret,
                'payment_intent_id' => $paymentIntent->id,
                'amount' => $amount,
                'currency' => $currency,
            ];
        } catch (ApiErrorException $e) {
            Log::error('Stripe Payment Intent creation failed', [
                'error' => $e->getMessage(),
                'amount' => $amount,
            ]);
            throw $e;
        }
    }
}
