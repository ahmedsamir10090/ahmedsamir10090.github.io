<?php

namespace App\Http\Controllers;

use App\Models\Agency;
use App\Models\Flight;
use App\Models\Country;
use Illuminate\Http\Request;

class AdminFlightController extends Controller
{
    /**
     * Display a listing of flights.
     */
    public function index(Request $request)
    {
        $flights = Flight::with(['agency', 'originAirport.country', 'destinationAirport.country'])
            ->orderBy('departure_time', 'desc')
            ->paginate(15);

        return view('admin.flights.index', compact('flights'));
    }

    /**
     * Show the form for creating a flight.
     */
    public function create()
    {
        $agencies = Agency::orderBy('name')->get();
        $countries = Country::with('airports')->orderBy('name_' . app()->getLocale())->get();

        return view('admin.flights.create', compact('agencies', 'countries'));
    }

    /**
     * Store a newly created flight.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'agency_id' => ['required', 'exists:agencies,id'],
            'flight_number' => ['required', 'string', 'max:255'],
            'flight_type' => ['required', 'in:air,sea'],
            'origin_airport_id' => ['required', 'exists:airports,id'],
            'destination_airport_id' => ['required', 'exists:airports,id', 'different:origin_airport_id'],
            'departure_time' => ['required', 'date'],
            'arrival_time' => ['required', 'date', 'after:departure_time'],
            'price' => ['required', 'numeric', 'min:0'],
            'available_seats' => ['required', 'integer', 'min:0'],
            'status' => ['required', 'in:pending,active,cancelled'],
        ]);

        Flight::create($validated);

        return redirect()
            ->route('admin.flights.index')
            ->with('success', 'Flight created successfully.');
    }

    /**
     * Show the form for editing a flight.
     */
    public function edit($id)
    {
        $flight = Flight::with('agency')->findOrFail($id);
        $agencies = Agency::orderBy('name')->get();
        $countries = Country::with('airports')->orderBy('name_' . app()->getLocale())->get();

        return view('admin.flights.edit', compact('flight', 'agencies', 'countries'));
    }

    /**
     * Update the specified flight.
     */
    public function update(Request $request, $id)
    {
        $flight = Flight::findOrFail($id);

        $validated = $request->validate([
            'agency_id' => ['required', 'exists:agencies,id'],
            'flight_number' => ['required', 'string', 'max:255'],
            'flight_type' => ['required', 'in:air,sea'],
            'origin_airport_id' => ['required', 'exists:airports,id'],
            'destination_airport_id' => ['required', 'exists:airports,id', 'different:origin_airport_id'],
            'departure_time' => ['required', 'date'],
            'arrival_time' => ['required', 'date', 'after:departure_time'],
            'price' => ['required', 'numeric', 'min:0'],
            'available_seats' => ['required', 'integer', 'min:0'],
            'status' => ['required', 'in:pending,active,cancelled'],
        ]);

        $flight->update($validated);

        return redirect()
            ->route('admin.flights.index')
            ->with('success', 'Flight updated successfully.');
    }

    /**
     * Remove the specified flight.
     */
    public function destroy($id)
    {
        $flight = Flight::findOrFail($id);
        $flight->delete();

        return redirect()
            ->route('admin.flights.index')
            ->with('success', 'Flight deleted successfully.');
    }
}
