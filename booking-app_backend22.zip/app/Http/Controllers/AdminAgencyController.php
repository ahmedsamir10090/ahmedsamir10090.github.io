<?php
namespace App\Http\Controllers;

use App\Models\Agency;
use App\Models\AgencyTransaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AdminAgencyController extends Controller
{
    /**
     * Display a listing of agencies.
     */
    public function index(Request $request)
    {
        $agencies = Agency::with(['users' => function($query) {
            $query->where('role', 'agency_manager')->limit(1);
        }])->paginate(10);

        return view('admin.agencies.index', compact('agencies'));
    }

    /**
     * Toggle agency status between active and suspended.
     */
    public function updateStatus(Request $request, $id)
    {
        $agency = Agency::findOrFail($id);
        
        $newStatus = $agency->status === 'active' ? 'suspended' : 'active';
        
        DB::transaction(function () use ($agency, $newStatus) {
            $agency->update(['status' => $newStatus]);
            
            // Also update associated users' active status
            $agency->users()->update(['is_active' => $newStatus === 'active']);
        });

        return redirect()
            ->route('admin.agencies.index')
            ->with('success', "Agency status updated to {$newStatus} successfully.");
    }

    /**
     * Show the form for creating a new agency.
     */
    public function create()
    {
        return view('admin.agencies.create');
    }

    /**
     * Store a newly created agency.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'license_number' => 'nullable|string|max:255|unique:agencies,license_number',
            'logo' => 'nullable|file|image|max:2048',
            'phone' => 'nullable|string|max:50',
            'commission_rate' => 'nullable|numeric|min:0|max:100',
            'status' => 'required|in:active,suspended',
            'manager_name' => 'required|string|max:255',
            'manager_email' => 'required|email|max:255|unique:users,email',
            'manager_password' => 'required|string|min:8',
        ]);

        $logoPath = $request->file('logo')
            ? $request->file('logo')->store('agency-logos', 'public')
            : null;

        DB::transaction(function () use ($validated, $logoPath) {
            $agency = Agency::create([
                'name' => $validated['name'],
                'license_number' => $validated['license_number'],
                'logo' => $logoPath,
                'phone' => $validated['phone'] ?? null,
                'status' => $validated['status'],
                'current_balance' => 0,
                'total_lifetime_earnings' => 0,
                'commission_rate' => $validated['commission_rate'] ?? 0,
            ]);

            User::create([
                'name' => $validated['manager_name'],
                'email' => $validated['manager_email'],
                'password' => bcrypt($validated['manager_password']),
                'role' => 'agency_manager',
                'agency_id' => $agency->id,
                'is_active' => $validated['status'] === 'active',
            ]);
        });

        return redirect()
            ->route('admin.agencies.index')
            ->with('success', 'Agency created successfully.');
    }

    /**
     * Show the form for editing the specified agency.
     */
    public function edit($id)
    {
        $agency = Agency::with(['users' => function($query) {
            $query->where('role', 'agency_manager');
        }])->findOrFail($id);

        return view('admin.agencies.edit', compact('agency'));
    }

    /**
     * Display the specified agency.
     */
    public function show($id)
    {
        $agency = Agency::with([
            'users' => function ($query) {
                $query->where('role', 'agency_manager');
            },
            'flights',
            'cargoServices',
            'bookings.user',
            'agencyTransactions.admin',
        ])->findOrFail($id);

        $manager = $agency->users->first();

        $totalCompletedBookings = $agency->bookings()
            ->where('status', 'completed')
            ->count();
        $activeFlightsCount = $agency->flights()
            ->where('status', 'active')
            ->count();
        $currentBalance = $agency->current_balance ?? 0;
        $totalLifetimeEarnings = $agency->total_lifetime_earnings ?? 0;

        $activeFlights = $agency->flights()
            ->where('status', 'active')
            ->orderBy('departure_time')
            ->get();
        $cargoServices = $agency->cargoServices()->orderBy('type')->get();
        $recentBookings = $agency->bookings()
            ->with(['user'])
            ->latest()
            ->limit(10)
            ->get();
        $transactions = $agency->agencyTransactions()
            ->with(['admin'])
            ->latest()
            ->get();

        return view('admin.agencies.show', compact(
            'agency',
            'manager',
            'totalCompletedBookings',
            'currentBalance',
            'totalLifetimeEarnings',
            'activeFlightsCount',
            'activeFlights',
            'cargoServices',
            'recentBookings',
            'transactions'
        ));
    }

    /**
     * Process an agency payout.
     */
    public function payout(Request $request, $id)
    {
        $agency = Agency::findOrFail($id);

        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:1', 'max:' . $agency->current_balance],
            'payment_method' => ['required', 'string', 'max:255'],
            'proof_image' => ['required', 'image', 'max:2048'],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        $proofPath = $request->file('proof_image')->store('agency-payouts', 'public');
        $amount = (float) $validated['amount'];

        DB::transaction(function () use ($agency, $validated, $amount, $proofPath) {
            $agency->decrement('current_balance', $amount);

            AgencyTransaction::create([
                'agency_id' => $agency->id,
                'admin_id' => Auth::id(),
                'type' => 'payout',
                'amount' => -abs($amount),
                'payment_method' => $validated['payment_method'],
                'proof_image' => $proofPath,
                'description' => $validated['description'] ?? null,
            ]);
        });

        return redirect()
            ->route('admin.agencies.show', $agency->id)
            ->with('success', 'Payout processed successfully.');
    }

    /**
     * Update the specified agency.
     */
    public function update(Request $request, $id)
    {
        $agency = Agency::findOrFail($id);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'license_number' => 'nullable|string|max:255|unique:agencies,license_number,' . $agency->id,
            'logo' => 'nullable|file|image|max:2048',
            'phone' => 'nullable|string|max:50',
            'commission_rate' => 'nullable|numeric|min:0|max:100',
            'status' => 'required|in:active,suspended',
        ]);

        $logoPath = $request->file('logo')
            ? $request->file('logo')->store('agency-logos', 'public')
            : $agency->logo;

        $validated['logo'] = $logoPath;

        $agency->update($validated);

        // Update associated users' active status
        $agency->users()->update(['is_active' => $validated['status'] === 'active']);

        return redirect()
            ->route('admin.agencies.index')
            ->with('success', 'Agency updated successfully.');
    }

    /**
     * Remove the specified agency.
     */
    public function destroy($id)
    {
        $agency = Agency::findOrFail($id);

        DB::transaction(function () use ($agency) {
            // Delete associated users
            $agency->users()->delete();
            
            // Delete agency
            $agency->delete();
        });

        return redirect()
            ->route('admin.agencies.index')
            ->with('success', 'Agency deleted successfully.');
    }
}
