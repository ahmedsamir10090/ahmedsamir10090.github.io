<?php

namespace App\Http\Controllers;

use App\Models\Agency;
use App\Models\User;
use App\Models\Flight;
use App\Models\Booking;
use App\Models\CargoService;
use App\Models\SystemSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
class AdminDashboardController extends Controller
{
    /**
     * Display the admin dashboard.
     */
    public function index(Request $request)
    {
        $commissionRate = (float) SystemSetting::getSetting('commission_rate', 0);

        // A. Key KPIs (Counters)
        $totalRevenue = Booking::where('status', 'completed')->sum('total_price');

        $kpis = [
            'total_revenue' => $totalRevenue,
            'total_commission' => $totalRevenue * ($commissionRate / 100),
            'total_bookings' => Booking::count(),
            'pending_bookings' => Booking::where('status', 'pending')->count(),
            'active_agencies' => Agency::where('status', 'active')->count(),
            'total_users' => User::where('role', 'user')->count(),
        ];

        // B. Charts Data
        $statusOrder = ['pending', 'accepted', 'rejected', 'completed'];
        $bookingsByStatusRaw = Booking::select('status', DB::raw('COUNT(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status')
            ->toArray();
        $bookingsByStatus = collect($statusOrder)
            ->mapWithKeys(fn ($status) => [$status => $bookingsByStatusRaw[$status] ?? 0])
            ->toArray();

        $cargoTypes = ['Air', 'Sea', 'Land'];
        $cargoByTypeRaw = CargoService::select('type', DB::raw('COUNT(*) as total'))
            ->groupBy('type')
            ->pluck('total', 'type')
            ->toArray();
        $cargoByType = collect($cargoTypes)
            ->mapWithKeys(function ($type) use ($cargoByTypeRaw) {
                // normalize stored values to title case for consistent chart labels
                $keyMatches = collect($cargoByTypeRaw)
                    ->filter(function ($_, $key) use ($type) {
                        return strtolower($key) === strtolower($type);
                    });

                return [$type => $keyMatches->first() ?? 0];
            })
            ->toArray();

        // Monthly sales (last 6 months) - kept for potential future charting
        $sixMonthsAgo = Carbon::now()->startOfMonth()->subMonths(5);
        $monthlySales = Booking::select(DB::raw('DATE_FORMAT(created_at, "%Y-%m") as month'), DB::raw('SUM(total_price) as total'))
            ->where('status', 'completed')
            ->where('created_at', '>=', $sixMonthsAgo)
            ->groupBy('month')
            ->orderBy('month')
            ->pluck('total', 'month')
            ->toArray();

        // C. Top Lists
        $topAgencies = Agency::withCount([
                'bookings as completed_bookings_count' => function ($query) {
                    $query->where('status', 'completed');
                },
            ])
            ->withSum([
                'bookings as completed_earnings' => function ($query) {
                    $query->where('status', 'completed');
                },
            ], 'total_price')
            ->orderByDesc('completed_bookings_count')
            ->take(5)
            ->get();

        $latestBookings = Booking::with(['user', 'agency'])
            ->latest()
            ->take(5)
            ->get();

        // D. Smart Alerts
        $stuckBookings = Booking::where('status', 'pending')
            ->where('created_at', '<', Carbon::now()->subHours(48))
            ->count();

        $inactiveAgencies = Agency::whereDoesntHave('bookings', function ($query) {
                $query->where('created_at', '>=', Carbon::now()->subDays(30));
            })
            ->count();

        $alerts = [
            'stuck_bookings' => $stuckBookings,
            'inactive_agencies' => $inactiveAgencies,
        ];

        return view('admin.dashboard', compact(
            'kpis',
            'bookingsByStatus',
            'cargoByType',
            'monthlySales',
            'topAgencies',
            'latestBookings',
            'alerts'
        ));
    }
}
