<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    // protected $redirectTo = '/home';
    public function redirectTo()
    {
        $role = auth()->user()->role;

        // 1. لو أدمن -> حوله للوحة الأدمن
        if ($role === 'admin') {
            return route('admin.dashboard');
        }

        // 2. لو وكالة (مدير أو موظف) -> حوله للوحة الوكالة
        if ($role === 'agency_manager' || $role === 'agency_staff') {
            return route('agency.dashboard');
        }

        // 3. أي مستخدم عادي -> حوله للصفحة الرئيسية
        return '/home';
    }
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }
}
