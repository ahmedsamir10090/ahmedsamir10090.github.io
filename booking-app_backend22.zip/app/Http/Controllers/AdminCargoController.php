<?php

namespace App\Http\Controllers;

use App\Models\CargoService;
use App\Models\Agency;
use App\Models\Country;
use Illuminate\Http\Request;

class AdminCargoController extends Controller
{
    /**
     * Display a listing of cargo services.
     */
    public function index(Request $request)
    {
        $services = CargoService::with('agency')
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return view('admin.cargo.index', compact('services'));
    }

    /**
     * Show the form for creating a cargo service.
     */
    public function create()
    {
        $agencies = Agency::orderBy('name')->get();
        $countries = Country::orderBy('name_' . app()->getLocale())->get();

        return view('admin.cargo.create', compact('agencies', 'countries'));
    }

    /**
     * Store a newly created cargo service.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'agency_id' => ['required', 'exists:agencies,id'],
            'type' => ['required', 'in:air,sea,land'],
            'price_per_kg' => ['required', 'numeric', 'min:0'],
            'min_weight' => ['required', 'numeric', 'min:0'],
            'delivery_time_estimate' => ['required', 'string', 'max:255'],
            'route_from' => ['required', 'string', 'max:255'],
            'route_to' => ['required', 'string', 'max:255'],
        ]);

        CargoService::create($validated);

        return redirect()
            ->route('admin.cargo.index')
            ->with('success', 'Cargo service created successfully.');
    }

    /**
     * Show the form for editing a cargo service.
     */
    public function edit($id)
    {
        $service = CargoService::with('agency')->findOrFail($id);
        $agencies = Agency::orderBy('name')->get();
        $countries = Country::orderBy('name_' . app()->getLocale())->get();

        return view('admin.cargo.edit', compact('service', 'agencies', 'countries'));
    }

    /**
     * Update the specified cargo service.
     */
    public function update(Request $request, $id)
    {
        $service = CargoService::findOrFail($id);

        $validated = $request->validate([
            'agency_id' => ['required', 'exists:agencies,id'],
            'type' => ['required', 'in:air,sea,land'],
            'price_per_kg' => ['required', 'numeric', 'min:0'],
            'min_weight' => ['required', 'numeric', 'min:0'],
            'delivery_time_estimate' => ['required', 'string', 'max:255'],
            'route_from' => ['required', 'string', 'max:255'],
            'route_to' => ['required', 'string', 'max:255'],
        ]);

        $service->update($validated);

        return redirect()
            ->route('admin.cargo.index')
            ->with('success', 'Cargo service updated successfully.');
    }

    /**
     * Remove the specified cargo service.
     */
    public function destroy($id)
    {
        $service = CargoService::findOrFail($id);
        $service->delete();

        return redirect()
            ->route('admin.cargo.index')
            ->with('success', 'Cargo service deleted successfully.');
    }
}
