<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\CargoService;
use App\Models\Flight;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class BookingController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'service_type' => ['required', 'string', Rule::in(['flight', 'cargo'])],
            'service_id' => ['required', 'integer'],
            'seats_count' => ['nullable', 'integer', 'min:1'],
            'weight' => ['nullable', 'numeric', 'min:0.01'],
            'total_price' => ['required', 'numeric'],
            'payment_method' => ['required', Rule::in(['wallet', 'stripe', 'manual_receipt', 'cash_on_delivery'])],
            
            // Payment receipt image (required for manual_receipt payment method)
            'payment_proof_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:5120'],
            
            // Passenger details
            'passenger_title' => ['required', 'string', Rule::in(['mr', 'ms', 'mrs', 'dr'])],
            'passenger_first_name' => ['required', 'string', 'max:255'],
            'passenger_middle_name' => ['nullable', 'string', 'max:255'],
            'passenger_last_name' => ['required', 'string', 'max:255'],
            'passenger_date_of_birth' => ['required', 'date', 'before:today'],
            'passenger_nationality' => ['required', 'string', 'max:100'],
            'passenger_type' => ['required', 'string', Rule::in(['adult', 'child', 'infant'])],
            
            // Contact information
            'passenger_phone' => ['required', 'string', 'max:20'],
            'passenger_whatsapp' => ['nullable', 'string', 'max:20'],
            
            // Passport details
            'passport_number' => ['required', 'string', 'max:50'],
            'passport_issuing_country' => ['required', 'string', 'max:100'],
            'passport_expiry_date' => ['required', 'date', 'after:today'],
            'passport_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
            
            // Baggage - can be string or integer
            'selected_baggage_weight' => ['nullable'],
        ]);
        
        // Validate that payment_proof_image is required for manual_receipt
        if ($validated['payment_method'] === 'manual_receipt' && !$request->hasFile('payment_proof_image')) {
            return response()->json([
                'message' => 'Payment receipt image is required for bank transfer payments.',
                'errors' => ['payment_proof_image' => ['يجب رفع صورة إيصال الدفع للتحويل البنكي']]
            ], 422);
        }

        $user = $request->user();

        [$serviceType, $serviceId] = [$validated['service_type'], $validated['service_id']];

        $serviceModel = $serviceType === 'flight' ? Flight::class : CargoService::class;
        $serviceInstance = $serviceModel::findOrFail($serviceId);

        $booking = DB::transaction(function () use ($validated, $serviceInstance, $serviceModel, $user, $request) {
            // Handle passport image upload
            $passportImagePath = null;
            if ($request->hasFile('passport_image')) {
                $passportImagePath = $request->file('passport_image')->store('passport_images', 'public');
            }
            
            // Handle payment receipt image upload
            $paymentProofImagePath = null;
            if ($request->hasFile('payment_proof_image')) {
                $paymentProofImagePath = $request->file('payment_proof_image')->store('payment_receipts', 'public');
            }
            
            $seatsCount = null;
            $totalPrice = 0;
            $baggageWeight = null;
            
            if ($validated['service_type'] === 'flight') {
                $seatsCount = $validated['seats_count'] ?? 1;
                
                $flight = Flight::lockForUpdate()->find($validated['service_id']);
                if ($flight->available_seats < $seatsCount) {
                    abort(400, 'Not enough seats available on this flight.');
                }
                
                // Calculate price based on passenger type (adult/child)
                $basePrice = $validated['passenger_type'] === 'adult' 
                    ? (float) $flight->adult_price 
                    : (float) $flight->child_price;
                
                // Add baggage price if selected
                $baggagePrice = 0;
                if (isset($validated['selected_baggage_weight']) && !empty($validated['selected_baggage_weight'])) {
                    $baggagePrices = $flight->baggage_prices ?? [];
                    $weight = (string) $validated['selected_baggage_weight'];
                    // Extract just the number if it's like "23kg"
                    $weightNum = preg_replace('/[^0-9]/', '', $weight);
                    $baggageWeight = (int) $weightNum;
                    $baggagePrice = (float) ($baggagePrices[$weightNum] ?? $baggagePrices[$weight] ?? 0);
                }
                
                $totalPrice = ($basePrice + $baggagePrice) * $seatsCount;
                
                $flight->decrement('available_seats', $seatsCount);
            } else {
                if (! $validated['weight']) {
                    abort(400, 'Weight is required for cargo bookings.');
                }

                $weight = (float) $validated['weight'];
                $minWeight = (float) $serviceInstance->min_weight;
                if ($weight < $minWeight) {
                    abort(400, "Weight must be at least {$minWeight} kg.");
                }

                $totalPrice = $weight * (float) $serviceInstance->price_per_kg;
            }

            // Determine payment status based on method
            $paymentStatus = 'unpaid';
            if ($validated['payment_method'] === 'cash_on_delivery') {
                $paymentStatus = 'pending_cod'; // Cash on delivery - pending until delivery
            } elseif ($validated['payment_method'] === 'manual_receipt' && $paymentProofImagePath) {
                $paymentStatus = 'pending_verification'; // Receipt uploaded - waiting for admin verification
            }

            $booking = Booking::create([
                'user_id' => $user->id,
                'agency_id' => $serviceInstance->agency_id ?? null,
                'serviceable_type' => $serviceModel,
                'serviceable_id' => $serviceInstance->id,
                'seats_count' => $seatsCount,
                'total_price' => $totalPrice,
                'weight' => $validated['weight'] ?? null,
                'status' => 'pending',
                'payment_status' => $paymentStatus,
                'payment_method' => $validated['payment_method'],
                
                // Passenger details
                'passenger_title' => $validated['passenger_title'],
                'passenger_first_name' => $validated['passenger_first_name'],
                'passenger_middle_name' => $validated['passenger_middle_name'] ?? null,
                'passenger_last_name' => $validated['passenger_last_name'],
                'passenger_date_of_birth' => $validated['passenger_date_of_birth'],
                'passenger_nationality' => $validated['passenger_nationality'],
                'passenger_type' => $validated['passenger_type'],
                
                // Contact information
                'passenger_phone' => $validated['passenger_phone'],
                'passenger_whatsapp' => $validated['passenger_whatsapp'] ?? null,
                
                // Passport details
                'passport_number' => $validated['passport_number'],
                'passport_issuing_country' => $validated['passport_issuing_country'],
                'passport_expiry_date' => $validated['passport_expiry_date'],
                'passport_image' => $passportImagePath,
                
                // Payment receipt image
                'payment_proof_image' => $paymentProofImagePath,
                
                // Baggage
                'selected_baggage_weight' => $baggageWeight,
            ]);

            return $booking;
        });

        $booking->load(['serviceable', 'agency', 'user']);

        return response()->json([
            'message' => 'Booking created successfully',
            'data' => $booking,
        ], 201);
    }

    public function uploadReceipt(Request $request, Booking $booking): JsonResponse
    {
        // Ensure user owns this booking
        if ($booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'payment_proof_image' => ['required', 'image', 'mimes:jpeg,png,jpg', 'max:5120'],
        ]);

        // Upload the receipt image
        $imagePath = $request->file('payment_proof_image')->store('payment_receipts', 'public');

        $booking->update([
            'payment_proof_image' => $imagePath,
            'payment_status' => 'pending_verification', // Waiting for admin verification
        ]);

        // TODO: Send notification to admin about new payment receipt

        return response()->json([
            'message' => 'Receipt uploaded successfully. Waiting for verification.',
            'data' => $booking,
        ]);
    }

    /**
     * Get user's bookings
     */
    public function index(Request $request): JsonResponse
    {
        $bookings = Booking::where('user_id', $request->user()->id)
            ->with(['serviceable', 'agency'])
            ->when($request->get('status'), fn ($q, $status) => $q->where('status', $status))
            ->when($request->get('type'), function ($q, $type) {
                if ($type === 'flight') {
                    $q->where('serviceable_type', Flight::class);
                } elseif ($type === 'cargo') {
                    $q->where('serviceable_type', CargoService::class);
                }
            })
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 20);

        return response()->json($bookings);
    }

    /**
     * Get single booking details
     */
    public function show(Request $request, Booking $booking): JsonResponse
    {
        // Ensure user owns this booking
        if ($booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $booking->load(['serviceable', 'agency', 'user']);

        return response()->json([
            'data' => $booking,
        ]);
    }
}
