<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class WalletController extends Controller
{
    protected PaymentService $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function show(Request $request): JsonResponse
    {
        $wallet = $request->user()->wallet()->firstOrCreate(
            ['user_id' => $request->user()->id],
            ['balance' => 0, 'currency' => 'USD']
        );

        return response()->json([
            'wallet' => $wallet,
        ]);
    }

    public function deposit(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01'],
            'reference_id' => ['nullable', 'string', 'max:255'],
            'method' => ['required', Rule::in(['stripe', 'manual_receipt', 'wallet'])],
        ]);

        $user = $request->user();
        $amount = (float) $validated['amount'];
        $method = $validated['method'];
        $referenceId = $validated['reference_id'] ?? null;

        // For manual receipts, create pending transaction
        // For Stripe, the transaction will be completed via webhook
        $status = $method === 'manual_receipt' ? 'pending' : 'completed';

        try {
            $transaction = $this->paymentService->depositToWallet(
                $user,
                $amount,
                $referenceId,
                $status
            );

            return response()->json([
                'message' => 'Deposit processed successfully',
                'wallet' => $user->wallet->fresh(),
                'transaction' => $transaction,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Deposit failed',
                'error' => $e->getMessage(),
            ], 422);
        }
    }
}
