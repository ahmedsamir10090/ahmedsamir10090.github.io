<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Port;
use Illuminate\Http\JsonResponse;

class PortController extends Controller
{
    /**
     * Get all ports grouped by country.
     */
    public function index(): JsonResponse
    {
        $ports = Port::with('country')
            ->where('is_active', true)
            ->orderBy('country_id')
            ->orderBy('name_en')
            ->get()
            ->groupBy('country.code')
            ->map(function ($countryPorts) {
                return [
                    'country' => [
                        'code' => $countryPorts->first()->country->code,
                        'name_en' => $countryPorts->first()->country->name_en,
                        'name_ar' => $countryPorts->first()->country->name_ar,
                    ],
                    'ports' => $countryPorts->map(function ($port) {
                        return [
                            'id' => $port->id,
                            'code' => $port->code,
                            'name_en' => $port->name_en,
                            'name_ar' => $port->name_ar,
                            'city_en' => $port->city_en,
                            'city_ar' => $port->city_ar,
                        ];
                    })->values(),
                ];
            })
            ->values();

        return response()->json([
            'success' => true,
            'data' => $ports,
        ]);
    }

    /**
     * Get all ports as a flat list.
     */
    public function list(): JsonResponse
    {
        $ports = Port::with('country')
            ->where('is_active', true)
            ->orderBy('name_en')
            ->get()
            ->map(function ($port) {
                return [
                    'id' => $port->id,
                    'code' => $port->code,
                    'name_en' => $port->name_en,
                    'name_ar' => $port->name_ar,
                    'city_en' => $port->city_en,
                    'city_ar' => $port->city_ar,
                    'country_code' => $port->country->code,
                    'country_name_en' => $port->country->name_en,
                    'country_name_ar' => $port->country->name_ar,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $ports,
        ]);
    }
}
