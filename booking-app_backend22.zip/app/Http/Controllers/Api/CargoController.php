<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\CargoService;
use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CargoController extends Controller
{
    /**
     * Get countries for cargo services
     */
    public function getCountries()
    {
        $countries = Country::select('id', 'code', 'name_ar', 'name_en')
            ->orderBy('name_ar')
            ->get()
            ->map(function ($country) {
                return [
                    'id' => $country->id,
                    'code' => $country->code,
                    'name_ar' => $country->name_ar,
                    'name_en' => $country->name_en,
                    'country_key' => strtolower(str_replace(' ', '_', $country->name_en)),
                ];
            });

        return response()->json($countries);
    }

    /**
     * Get all cargo services
     */
    public function index(Request $request)
    {
        $query = CargoService::with('agency')
            ->where('status', 'active');

        // Filter by route (country-based)
        if ($request->has('route_from') && $request->route_from) {
            $query->where('route_from', $request->route_from);
        }

        if ($request->has('route_to') && $request->route_to) {
            $query->where('route_to', $request->route_to);
        }

        // Filter by service type
        if ($request->has('service_type') && $request->service_type) {
            $query->where('type', $request->service_type);
        }

        // Filter by weight range
        // If user wants to ship minimum weight, service must accept that weight
        if ($request->has('min_weight') && $request->min_weight) {
            $query->where('min_weight', '<=', $request->min_weight)
                  ->where('max_weight', '>=', $request->min_weight);
        }

        // If user wants to ship maximum weight, service must accept that weight
        if ($request->has('max_weight') && $request->max_weight) {
            $query->where('min_weight', '<=', $request->max_weight)
                  ->where('max_weight', '>=', $request->max_weight);
        }

        // Filter by price per kg
        if ($request->has('min_price') && $request->min_price) {
            $query->where('price_per_kg', '>=', $request->min_price);
        }

        if ($request->has('max_price') && $request->max_price) {
            $query->where('price_per_kg', '<=', $request->max_price);
        }

        // Filter by delivery time
        if ($request->has('max_delivery_days') && $request->max_delivery_days) {
            $query->where('estimated_days', '<=', $request->max_delivery_days);
        }

        $cargoServices = $query->latest()->paginate($request->per_page ?? 20);

        return response()->json($cargoServices);
    }

    /**
     * Get single cargo service
     */
    public function show(CargoService $cargoService)
    {
        $cargoService->load('agency');

        return response()->json($cargoService);
    }

    /**
     * Calculate price for cargo
     */
    public function calculatePrice(Request $request)
    {
        $request->validate([
            'cargo_service_id' => 'required|exists:cargo_services,id',
            'weight' => 'required|numeric|min:0',
        ]);

        $cargoService = CargoService::findOrFail($request->cargo_service_id);

        // Check if weight is within range
        if ($request->weight < $cargoService->min_weight || $request->weight > $cargoService->max_weight) {
            return response()->json([
                'error' => 'Weight is outside allowed range',
                'min_weight' => $cargoService->min_weight,
                'max_weight' => $cargoService->max_weight,
            ], 422);
        }

        $totalPrice = $cargoService->price_per_kg * $request->weight;

        return response()->json([
            'cargo_service_id' => $cargoService->id,
            'weight' => $request->weight,
            'price_per_kg' => $cargoService->price_per_kg,
            'total_price' => round($totalPrice, 2),
            'estimated_days' => $cargoService->estimated_days,
            'delivery_time_estimate' => $cargoService->delivery_time_estimate,
        ]);
    }

    /**
     * Create cargo booking
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            // Cargo Service
            'cargo_service_id' => 'required|exists:cargo_services,id',
            
            // Sender information
            'sender_name' => 'required|string|max:255',
            'sender_phone' => 'required|string|max:20',
            'sender_whatsapp' => 'nullable|string|max:20',
            'sender_city' => 'required|string|max:255',
            'sender_passport_image' => 'nullable|image|mimes:jpeg,jpg,png|max:5120',
            
            // Receiver information
            'receiver_name' => 'required|string|max:255',
            'receiver_phone' => 'required|string|max:20',
            'receiver_whatsapp' => 'nullable|string|max:20',
            'receiver_city' => 'required|string|max:255',
            
            // Shipment details
            'shipment_type' => 'required|in:documents,parcels,goods,personal_effects',
            'weight' => 'required|numeric|min:0.1',
            'contents_description' => 'required|string|min:5',
            
            // Pricing
            'insurance_fee' => 'nullable|numeric|min:0',
            'customs_fee' => 'nullable|numeric|min:0',
            'total_price' => 'required|numeric|min:0',
        ]);

        $user = $request->user();

        DB::beginTransaction();
        try {
            // Get the selected cargo service
            $cargoService = CargoService::findOrFail($validated['cargo_service_id']);
            
            // Validate weight is within range
            $weight = (float) $validated['weight'];
            if ($weight < $cargoService->min_weight || $weight > $cargoService->max_weight) {
                return response()->json([
                    'message' => 'Weight must be between ' . $cargoService->min_weight . ' - ' . $cargoService->max_weight . ' kg',
                ], 422);
            }

            // Handle passport image upload
            $passportImagePath = null;
            if ($request->hasFile('sender_passport_image')) {
                $passportImagePath = $request->file('sender_passport_image')
                    ->store('cargo_passports', 'public');
            }

            // Update cargo service with sender/receiver info and tracking details
            $cargoService->update([
                'sender_name' => $validated['sender_name'],
                'sender_phone' => $validated['sender_phone'],
                'sender_whatsapp' => $validated['sender_whatsapp'],
                'sender_country' => $cargoService->route_from,
                'sender_city' => $validated['sender_city'],
                'sender_passport_image' => $passportImagePath,
                
                'receiver_name' => $validated['receiver_name'],
                'receiver_phone' => $validated['receiver_phone'],
                'receiver_whatsapp' => $validated['receiver_whatsapp'],
                'receiver_country' => $cargoService->route_to,
                'receiver_city' => $validated['receiver_city'],
                
                'contents_description' => $validated['contents_description'],
                'no_prohibited_items' => true,
                'tracking_status' => 'pending',
                'current_location' => $validated['sender_city'] . ', ' . ucfirst($cargoService->route_from),
                'status_updated_at' => now(),
            ]);

            // Create Booking record
            $booking = Booking::create([
                'user_id' => $user->id,
                'agency_id' => $cargoService->agency_id,
                'serviceable_type' => CargoService::class,
                'serviceable_id' => $cargoService->id,
                'weight' => $weight,
                'total_price' => $validated['total_price'],
                'status' => 'pending',
                'payment_status' => 'unpaid',
                'payment_method' => 'manual_receipt',
                
                // Passenger fields (using sender info for compatibility)
                'passenger_title' => 'mr',
                'passenger_first_name' => explode(' ', $validated['sender_name'])[0],
                'passenger_middle_name' => null,
                'passenger_last_name' => explode(' ', $validated['sender_name'])[1] ?? $validated['sender_name'],
                'passenger_date_of_birth' => now()->subYears(30)->format('Y-m-d'),
                'passenger_nationality' => $cargoService->route_from,
                'passenger_type' => 'adult',
                'passenger_phone' => $validated['sender_phone'],
                'passenger_whatsapp' => $validated['sender_whatsapp'],
                'passport_number' => 'CARGO-' . time(),
                'passport_issuing_country' => $cargoService->route_from,
                'passport_expiry_date' => now()->addYears(5)->format('Y-m-d'),
                'passport_image' => $passportImagePath,
            ]);

            $booking->load(['serviceable', 'agency']);

            DB::commit();

            return response()->json([
                'message' => 'Cargo booking created successfully',
                'data' => $booking,
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Failed to create cargo booking: ' . $e->getMessage(),
            ], 500);
        }
    }
}
