<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth as FirebaseAuth;

class GoogleAuthController extends Controller
{
    protected $firebaseAuth;

    public function __construct()
    {
        // Initialize Firebase Auth
        $serviceAccountPath = base_path('config/firebase_credentials.json');
        
        if (!file_exists($serviceAccountPath)) {
            // If credentials file doesn't exist, we'll handle it in the authenticate method
            $this->firebaseAuth = null;
        } else {
            $factory = (new Factory)->withServiceAccount($serviceAccountPath);
            $this->firebaseAuth = $factory->createAuth();
        }
    }

    public function authenticate(Request $request)
    {
        $request->validate([
            'id_token' => 'required|string',
        ]);

        try {
            // Check if Firebase is configured
            if (!$this->firebaseAuth) {
                return response()->json([
                    'message' => 'Firebase authentication is not configured. Please add firebase_credentials.json to config folder.',
                ], 500);
            }

            // Verify Firebase ID token
            $verifiedIdToken = $this->firebaseAuth->verifyIdToken($request->id_token);
            $firebaseUid = $verifiedIdToken->claims()->get('sub');
            $email = $verifiedIdToken->claims()->get('email');
            $name = $verifiedIdToken->claims()->get('name');

            // Find or create user
            $user = User::where('email', $email)->first();

            if (!$user) {
                // Create new user
                $user = User::create([
                    'name' => $name,
                    'email' => $email,
                    'firebase_uid' => $firebaseUid,
                    'password' => Hash::make(Str::random(32)), // Random password for OAuth users
                    'email_verified_at' => now(), // Google accounts are pre-verified
                    'phone' => null, // Will be added later if needed
                    'role' => 'user', // Default role
                ]);
            } else {
                // Update Firebase UID if not set
                if (!$user->firebase_uid) {
                    $user->firebase_uid = $firebaseUid;
                    $user->save();
                }
            }

            // Generate Sanctum token
            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'role' => $user->role ?? 'user',
                ],
                'token' => $token,
            ]);

        } catch (\Kreait\Firebase\Exception\Auth\FailedToVerifyToken $e) {
            return response()->json([
                'message' => 'Invalid or expired ID token',
                'error' => $e->getMessage(),
            ], 401);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Authentication failed',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
