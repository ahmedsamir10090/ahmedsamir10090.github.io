<?php

namespace App\Http\Controllers\Api\Agency;

use App\Http\Controllers\Controller;
use App\Models\Flight;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AgencyFlightController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $agencyId = $request->user()->agency_id ?? null;

        $flights = Flight::query()
            ->when($agencyId, fn ($q) => $q->where('agency_id', $agencyId))
            ->paginate();

        return response()->json($flights);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'flight_number' => ['required', 'string', 'max:100', 'unique:flights,flight_number'],
            'origin' => ['required', 'string', 'max:100'],
            'destination' => ['required', 'string', 'max:100'],
            'departure_time' => ['required', 'date'],
            'arrival_time' => ['nullable', 'date', 'after:departure_time'],
            'price' => ['required', 'numeric'],
            'available_seats' => ['required', 'integer', 'min:0'],
            'status' => ['required', Rule::in(Flight::STATUSES)],
        ]);

        $validated['agency_id'] = $request->user()->agency_id ?? null;

        $flight = Flight::create($validated);

        return response()->json($flight, 201);
    }

    public function show(Flight $flight): JsonResponse
    {
        return response()->json($flight);
    }

    public function update(Request $request, Flight $flight): JsonResponse
    {
        $validated = $request->validate([
            'flight_number' => ['sometimes', 'string', 'max:100', Rule::unique('flights', 'flight_number')->ignore($flight->id)],
            'origin' => ['sometimes', 'string', 'max:100'],
            'destination' => ['sometimes', 'string', 'max:100'],
            'departure_time' => ['sometimes', 'date'],
            'arrival_time' => ['nullable', 'date', 'after:departure_time'],
            'price' => ['sometimes', 'numeric'],
            'available_seats' => ['sometimes', 'integer', 'min:0'],
            'status' => ['sometimes', Rule::in(Flight::STATUSES)],
        ]);

        $flight->update($validated);

        return response()->json($flight);
    }

    public function destroy(Flight $flight): JsonResponse
    {
        $flight->delete();

        return response()->json(['message' => 'Deleted']);
    }
}
