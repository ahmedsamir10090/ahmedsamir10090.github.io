<?php

namespace App\Http\Controllers\Api\Agency;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AgencyBookingController extends Controller
{



    public function index(Request $request): JsonResponse
    {
        $agencyId = $request->user()->agency_id ?? null;

        $bookings = Booking::query()
            ->when($agencyId, fn ($q) => $q->where('agency_id', $agencyId))
            ->with(['user', 'serviceable'])
            ->paginate();

        return response()->json($bookings);
    }

    public function accept(Booking $booking): JsonResponse
    {
        $booking->update(['status' => 'accepted']);

        return response()->json($booking);
    }

    public function reject(Booking $booking): JsonResponse
    {
        $booking->update(['status' => 'rejected']);

        return response()->json($booking);
    }
}
