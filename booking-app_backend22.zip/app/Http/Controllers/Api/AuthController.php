<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Agency;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    public function register(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
            'phone' => ['nullable', 'string', 'max:50', 'unique:users,phone'],
            'role' => ['nullable', Rule::in(['admin', 'agency_manager', 'agency_staff', 'user'])],

            // Agency fields (required when role = agency_manager)
            'agency_name' => ['nullable', 'string', 'max:255'],
            'license_number' => ['nullable', 'string', 'max:255'],
            'logo' => ['nullable', 'string', 'max:255'],
        ]);

        $role = $validated['role'] ?? 'user';

        if ($role === 'agency_manager') {
            $request->validate([
                'agency_name' => ['required', 'string', 'max:255'],
            ]);
        }

        $user = DB::transaction(function () use ($validated, $role) {
            $agencyId = null;

            if ($role === 'agency_manager') {
                // "pending" agency record (mapped to suspended until approved)
                $agency = Agency::create([
                    'name' => $validated['agency_name'],
                    'license_number' => $validated['license_number'] ?? null,
                    'logo' => $validated['logo'] ?? null,
                    'status' => 'suspended',
                    'commission_rate' => 0,
                    'current_balance' => 0,
                    
                ]);

                $agencyId = $agency->id;
            }

            return User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'phone' => $validated['phone'] ?? null,
                'password' => Hash::make($validated['password']),
                'role' => $role,
                'agency_id' => $agencyId,
                'is_active' => true,
            ]);
        });

        $token = $user->createToken('api')->plainTextToken;

        return response()->json([
            'user' => $user,
            'token' => $token,
        ], 201);
    }

    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $credentials['email'])->first();

        if (! $user || ! Hash::check($credentials['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 422);
        }

        if (! $user->is_active) {
            return response()->json(['message' => 'Account is disabled'], 403);
        }

        $token = $user->createToken('api')->plainTextToken;

        return response()->json([
            'user' => $user,
            'token' => $token,
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();

        if ($user?->currentAccessToken()) {
            $user->currentAccessToken()->delete();
        }

        return response()->json(['message' => 'Logged out']);
    }

    public function profile(Request $request): JsonResponse
    {
        return response()->json([
            'user' => $request->user(),
        ]);
    }

    /**
     * Update user's FCM token for push notifications.
     */
    public function updateFcmToken(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'fcm_token' => ['required', 'string', 'max:500'],
        ]);

        $request->user()->update([
            'fcm_token' => $validated['fcm_token'],
        ]);

        return response()->json(['message' => 'FCM token updated successfully']);
    }
}
