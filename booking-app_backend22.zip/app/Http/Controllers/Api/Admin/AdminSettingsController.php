<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\SystemSetting;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminSettingsController extends Controller
{
    public function getSettings(): JsonResponse
    {
        $settings = SystemSetting::getSettings([
            'online_payment_enabled',
            'commission_rate',
        ]);

        return response()->json($settings);
    }

    public function updateSettings(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'online_payment_enabled' => ['sometimes', 'boolean'],
            'commission_rate' => ['sometimes', 'numeric', 'min:0', 'max:100'],
        ]);

        $updated = [];

        if (isset($validated['online_payment_enabled'])) {
            SystemSetting::setSetting(
                'online_payment_enabled',
                $validated['online_payment_enabled'] ? '1' : '0'
            );
            $updated['online_payment_enabled'] = (bool) $validated['online_payment_enabled'];
        }

        if (isset($validated['commission_rate'])) {
            SystemSetting::setSetting(
                'commission_rate',
                (string) $validated['commission_rate']
            );
            $updated['commission_rate'] = (float) $validated['commission_rate'];
        }

        return response()->json([
            'message' => 'Settings updated successfully',
            'settings' => $updated,
        ]);
    }

    public function index(): JsonResponse
    {
        return $this->getSettings();
    }

    public function togglePayments(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'enabled' => ['required', 'boolean'],
        ]);

        SystemSetting::setSetting(
            'online_payment_enabled',
            $validated['enabled'] ? '1' : '0'
        );

        return response()->json(['online_payment_enabled' => $validated['enabled']]);
    }

    public function stats(): JsonResponse
    {
        return response()->json([
            'bookings_total' => Booking::count(),
            'bookings_pending' => Booking::pending()->count(),
            'transactions_total' => Transaction::count(),
            'transactions_pending' => Transaction::pending()->count(),
        ]);
    }
}
