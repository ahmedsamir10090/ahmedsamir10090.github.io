<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Agency;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AdminAgencyController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(Agency::query()->paginate());
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'license_number' => ['nullable', 'string', 'max:255', 'unique:agencies,license_number'],
            'logo' => ['nullable', 'string', 'max:255'],
            'current_balance' => ['nullable', 'numeric'],
            'commission_rate' => ['nullable', 'numeric'],
            'status' => ['required', Rule::in(['active', 'suspended'])],
        ]);

        $agency = Agency::create($validated);

        return response()->json($agency, 201);
    }

    public function show(Agency $agency): JsonResponse
    {
        return response()->json($agency);
    }

    public function update(Request $request, Agency $agency): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:255'],
            'license_number' => ['nullable', 'string', 'max:255', Rule::unique('agencies', 'license_number')->ignore($agency->id)],
            'logo' => ['nullable', 'string', 'max:255'],
            'current_balance' => ['nullable', 'numeric'],
            'commission_rate' => ['nullable', 'numeric'],
            'status' => ['sometimes', Rule::in(['active', 'suspended'])],
        ]);

        $agency->update($validated);

        return response()->json($agency);
    }

    public function destroy(Agency $agency): JsonResponse
    {
        $agency->delete();

        return response()->json(['message' => 'Deleted']);
    }
}
