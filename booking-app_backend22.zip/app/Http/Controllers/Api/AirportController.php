<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Airport;
use Illuminate\Http\JsonResponse;

class AirportController extends Controller
{
    /**
     * Get all airports grouped by country.
     */
    public function index(): JsonResponse
    {
        $airports = Airport::with('country')
            ->orderBy('country_id')
            ->orderBy('name_en')
            ->get()
            ->groupBy('country.code')
            ->map(function ($countryAirports) {
                return [
                    'country' => [
                        'code' => $countryAirports->first()->country->code,
                        'name_en' => $countryAirports->first()->country->name_en,
                        'name_ar' => $countryAirports->first()->country->name_ar,
                    ],
                    'airports' => $countryAirports->map(function ($airport) {
                        return [
                            'id' => $airport->id,
                            'iata_code' => $airport->iata_code,
                            'type' => $airport->type ?? 'airport',
                            'name_en' => $airport->name_en,
                            'name_ar' => $airport->name_ar,
                            'city_en' => $airport->city_en,
                            'city_ar' => $airport->city_ar,
                        ];
                    })->values(),
                ];
            })
            ->values();

        return response()->json([
            'success' => true,
            'data' => $airports,
        ]);
    }

    /**
     * Get all airports as a flat list.
     */
    public function list(): JsonResponse
    {
        $airports = Airport::with('country')
            ->orderBy('name_en')
            ->get()
            ->map(function ($airport) {
                return [
                    'id' => $airport->id,
                    'iata_code' => $airport->iata_code,
                    'type' => $airport->type ?? 'airport',
                    'name_en' => $airport->name_en,
                    'name_ar' => $airport->name_ar,
                    'city_en' => $airport->city_en,
                    'city_ar' => $airport->city_ar,
                    'country_code' => $airport->country->code,
                    'country_name_en' => $airport->country->name_en,
                    'country_name_ar' => $airport->country->name_ar,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $airports,
        ]);
    }
}
