<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Flight;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FlightController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $flights = Flight::query()
            ->with(['originAirport', 'destinationAirport', 'originPort', 'destinationPort'])
            ->active()
            // Filter by flight type (air or sea) - support both 'type' and 'flight_type' params
            ->when($request->get('flight_type'), fn ($q, $type) => $q->where('type', $type))
            ->when($request->get('type'), fn ($q, $type) => $q->where('type', $type))
            // Filter by origin airport
            ->when($request->get('origin_airport_id'), fn ($q, $id) => $q->where('origin_airport_id', $id))
            ->when($request->get('origin'), fn ($q, $origin) => $q->where('origin', $origin))
            // Filter by destination airport
            ->when($request->get('destination_airport_id'), fn ($q, $id) => $q->where('destination_airport_id', $id))
            ->when($request->get('destination'), fn ($q, $destination) => $q->where('destination', $destination))
            // Filter by origin port (for sea flights)
            ->when($request->get('origin_port_id'), fn ($q, $id) => $q->where('origin_port_id', $id))
            // Filter by destination port
            ->when($request->get('destination_port_id'), fn ($q, $id) => $q->where('destination_port_id', $id))
            // Filter by date
            ->when($request->get('departure_date'), fn ($q, $date) => $q->whereDate('departure_time', $date))
            ->when($request->get('date'), fn ($q, $date) => $q->whereDate('departure_time', $date))
            // Filter by price (adult or child)
            ->when($request->get('min_adult_price'), fn ($q, $price) => $q->where('adult_price', '>=', $price))
            ->when($request->get('max_adult_price'), fn ($q, $price) => $q->where('adult_price', '<=', $price))
            ->when($request->get('min_child_price'), fn ($q, $price) => $q->where('child_price', '>=', $price))
            ->when($request->get('max_child_price'), fn ($q, $price) => $q->where('child_price', '<=', $price))
            ->when($request->get('min_price'), fn ($q, $price) => $q->where('price', '>=', $price))
            ->when($request->get('max_price'), fn ($q, $price) => $q->where('price', '<=', $price))
            ->orderBy('departure_time', 'asc')
            ->paginate($request->per_page ?? 20);

        return response()->json($flights);
    }

    public function show(Flight $flight): JsonResponse
    {
        $flight->load(['originAirport', 'destinationAirport', 'originPort', 'destinationPort']);
        return response()->json($flight);
    }
}
