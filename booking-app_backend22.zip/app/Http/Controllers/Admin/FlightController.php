<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Flight;
use App\Models\Country;
use App\Models\Agency;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class FlightController extends Controller
{
    /**
     * Display a listing of the flights.
     */
    public function index()
    {
        $flights = Flight::with(['agency', 'originAirport.country', 'destinationAirport.country'])
            ->latest()
            ->paginate(20);
        
        return view('admin.flights.index', compact('flights'));
    }

    /**
     * Show the form for creating a new flight.
     */
    public function create()
    {
        $countries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'airport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        // Get seaports from airports table
        $seaportCountries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'seaport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        $agencies = Agency::where('status', 'active')->orderBy('name')->get();
        return view('admin.flights.form', compact('countries', 'seaportCountries', 'agencies'));
    }

    /**
     * Store a newly created flight in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'flight_number' => ['required', 'string', 'max:50', 'unique:flights,flight_number'],
            'flight_type' => ['required', 'in:air,sea'],
            'agency_id' => ['nullable', 'exists:agencies,id'],
            'origin_airport_id' => ['required', 'exists:airports,id'],
            'destination_airport_id' => ['required', 'exists:airports,id', 'different:origin_airport_id'],
            'departure_time' => ['required', 'date'],
            'arrival_time' => ['required', 'date', 'after:departure_time'],
            'available_seats' => ['required', 'integer', 'min:1'],
            'price' => ['required', 'numeric', 'min:0'],
            'adult_price' => ['required', 'numeric', 'min:0'],
            'child_price' => ['required', 'numeric', 'min:0'],
            'status' => ['required', 'string', Rule::in(['active', 'pending', 'cancelled'])],
            'baggage_weights' => ['nullable', 'array'],
            'baggage_weights.*' => ['nullable', 'integer', 'min:1'],
            'baggage_weight_prices' => ['nullable', 'array'],
            'baggage_weight_prices.*' => ['nullable', 'numeric', 'min:0'],
        ]);
        
        // Process baggage prices
        $baggagePrices = [];
        if (isset($validated['baggage_weights']) && isset($validated['baggage_weight_prices'])) {
            $weights = $validated['baggage_weights'];
            $prices = $validated['baggage_weight_prices'];
            
            foreach ($weights as $index => $weight) {
                if (!empty($weight) && isset($prices[$index]) && !empty($prices[$index])) {
                    $baggagePrices[(string)$weight] = (float)$prices[$index];
                }
            }
        }
        
        $flight = Flight::create([
            'flight_number' => $validated['flight_number'],
            'flight_type' => $validated['flight_type'],
            'agency_id' => $validated['agency_id'] ?? null,
            'origin_airport_id' => $validated['origin_airport_id'] ?? null,
            'type' => $validated['flight_type'], // Sync with type field
            'agency_id' => $validated['agency_id'] ?? null,
            'origin_airport_id' => $validated['origin_airport_id'],
            'destination_airport_id' => $validated['destination_airport_id'],
            'available_seats' => $validated['available_seats'],
            'price' => $validated['price'],
            'adult_price' => $validated['adult_price'],
            'child_price' => $validated['child_price'],
            'status' => $validated['status'],
            'baggage_prices' => $baggagePrices,
        ]);
        
        return redirect()->route('admin.flights.index')
            ->with('success', 'تم إضافة الرحلة بنجاح');
    }

    /**
     * Display the specified flight.
     */
    public function show(Flight $flight)
    {
        $flight->load('agency', 'bookings');
        
        return view('admin.flights.show', compact('flight'));
    }

    /**
     * Show the form for editing the specified flight.
     */
    public function edit(Flight $flight)
    {
        $countries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'airport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        // Get seaports from airports table
        $seaportCountries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'seaport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        $agencies = Agency::where('status', 'active')->orderBy('name')->get();
        return view('admin.flights.form', compact('flight', 'countries', 'seaportCountries', 'agencies'));
    }

    /**
     * Update the specified flight in storage.
     */
    public function update(Request $request, Flight $flight)
    {
        $validated = $request->validate([
            'flight_number' => ['required', 'string', 'max:50', Rule::unique('flights', 'flight_number')->ignore($flight->id)],
            'flight_type' => ['required', 'in:air,sea'],
            'agency_id' => ['nullable', 'exists:agencies,id'],
            'origin_airport_id' => ['nullable', 'required_if:flight_type,air', 'exists:airports,id'],
            'destination_airport_id' => ['nullable', 'required_if:flight_type,air', 'exists:airports,id'],
            'arrival_time' => ['required', 'date', 'after:departure_time'],
            'available_seats' => ['required', 'integer', 'min:1'],
            'price' => ['required', 'numeric', 'min:0'],
            'adult_price' => ['required', 'numeric', 'min:0'],
            'child_price' => ['required', 'numeric', 'min:0'],
            'status' => ['required', 'string', Rule::in(['active', 'pending', 'cancelled'])],
            'baggage_weights' => ['nullable', 'array'],
            'baggage_weights.*' => ['nullable', 'integer', 'min:1'],
            'baggage_weight_prices' => ['nullable', 'array'],
            'baggage_weight_prices.*' => ['nullable', 'numeric', 'min:0'],
        ]);
        
        // Process baggage prices
        $baggagePrices = [];
        if (isset($validated['baggage_weights']) && isset($validated['baggage_weight_prices'])) {
            $weights = $validated['baggage_weights'];
            $prices = $validated['baggage_weight_prices'];
            
            foreach ($weights as $index => $weight) {
                if (!empty($weight) && isset($prices[$index]) && !empty($prices[$index])) {
                    $baggagePrices[(string)$weight] = (float)$prices[$index];
                }
            }
        }
        
        $flight->update([
            'flight_number' => $validated['flight_number'],
            'flight_type' => $validated['flight_type'],
            'agency_id' => $validated['agency_id'] ?? null,
            'origin_airport_id' => $validated['origin_airport_id'] ?? null,
            'destination_airport_id' => $validated['destination_airport_id'] ?? null,
            'type' => $validated['flight_type'], // Sync with type field
            'agency_id' => $validated['agency_id'] ?? null,
            'origin_airport_id' => $validated['origin_airport_id'],
            'destination_airport_id' => $validated['destination_airport_id'],
            'price' => $validated['price'],
            'adult_price' => $validated['adult_price'],
            'child_price' => $validated['child_price'],
            'status' => $validated['status'],
            'baggage_prices' => $baggagePrices,
        ]);
        
        return redirect()->route('admin.flights.index')
            ->with('success', 'تم تحديث الرحلة بنجاح');
    }

    /**
     * Remove the specified flight from storage.
     */
    public function destroy(Flight $flight)
    {
        // Check if flight has bookings
        if ($flight->bookings()->exists()) {
            return redirect()->route('admin.flights.index')
                ->with('error', 'لا يمكن حذف هذه الرحلة لأنها تحتوي على حجوزات');
        }
        
        $flight->delete();
        
        return redirect()->route('admin.flights.index')
            ->with('success', 'تم حذف الرحلة بنجاح');
    }
}
