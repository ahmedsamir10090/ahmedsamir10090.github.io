<?php

namespace App\Http\Controllers;

use App\Models\AgencyTransaction;
use App\Models\Booking;
use App\Models\CargoService;
use App\Models\Flight;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AdminBookingController extends Controller
{
    /**
     * Display a listing of bookings.
     */
    public function index(Request $request)
    {
        $bookings = Booking::with(['user', 'agency', 'serviceable'])
            ->whereIn('serviceable_type', [
                Flight::class,
                CargoService::class,
                'flight',
                'cargo',
            ])
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return view('admin.bookings.index', compact('bookings'));
    }

    /**
     * Show the form for creating a booking.
     */
    public function create()
    {
        $users = User::orderBy('name')->get();
        $agencies = \App\Models\Agency::orderBy('name')->get();
        $flights = Flight::where('status', 'active')
            ->where('available_seats', '>', 0)
            ->orderBy('departure_time')
            ->get();

        return view('admin.bookings.create', compact('users', 'agencies', 'flights'));
    }

    /**
     * Show the form for editing a booking.
     */
    public function edit($id)
    {
        $booking = Booking::with(['user', 'agency', 'serviceable'])->findOrFail($id);
        $users = User::orderBy('name')->get();
        $agencies = \App\Models\Agency::orderBy('name')->get();

        return view('admin.bookings.edit', compact('booking', 'users', 'agencies'));
    }

    /**
     * Store a newly created booking.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => ['required', 'exists:users,id'],
            'service_type' => ['required', 'in:flight,cargo'],
            'service_id' => ['required', 'integer'],
            'seats_count' => ['nullable', 'integer', 'min:1'],
            'weight' => ['nullable', 'numeric', 'min:0.01'],
            'status' => ['required', 'in:pending,accepted,rejected,completed,cancelled'],
            'payment_method' => ['required', 'in:wallet,stripe,manual_receipt'],
            
            // Passenger details
            'passenger_title' => ['required', 'string', 'in:mr,ms,mrs'],
            'passenger_first_name' => ['required', 'string', 'max:255'],
            'passenger_middle_name' => ['nullable', 'string', 'max:255'],
            'passenger_last_name' => ['required', 'string', 'max:255'],
            'passenger_date_of_birth' => ['required', 'date', 'before:today'],
            'passenger_nationality' => ['required', 'string', 'max:100'],
            'passenger_type' => ['required', 'string', 'in:adult,child'],
            
            // Contact information
            'passenger_phone' => ['required', 'string', 'max:20'],
            'passenger_whatsapp' => ['nullable', 'string', 'max:20'],
            
            // Passport details
            'passport_number' => ['required', 'string', 'max:50'],
            'passport_issuing_country' => ['required', 'string', 'max:100'],
            'passport_expiry_date' => ['required', 'date', 'after:today'],
            'passport_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
            
            // Baggage
            'selected_baggage_weight' => ['nullable', 'integer', 'min:0'],
        ]);

        $serviceModel = $validated['service_type'] === 'flight' ? Flight::class : CargoService::class;
        $serviceInstance = $serviceModel::findOrFail($validated['service_id']);

        DB::transaction(function () use ($validated, $serviceInstance, $serviceModel, $request) {
            // Handle passport image upload
            $passportImagePath = null;
            if ($request->hasFile('passport_image')) {
                $passportImagePath = $request->file('passport_image')->store('passport_images', 'public');
            }
            
            if ($validated['service_type'] === 'flight') {
                $seatsCount = $validated['seats_count'] ?? 1;
                
                $flight = Flight::lockForUpdate()->find($validated['service_id']);
                if ($flight->available_seats < $seatsCount) {
                    abort(400, 'Not enough seats available on this flight.');
                }
                
                // Calculate price based on passenger type (adult/child)
                $basePrice = $validated['passenger_type'] === 'adult' 
                    ? (float) $flight->adult_price 
                    : (float) $flight->child_price;
                
                // Add baggage price if selected
                $baggagePrice = 0;
                if (isset($validated['selected_baggage_weight']) && $validated['selected_baggage_weight'] > 0) {
                    $baggagePrices = $flight->baggage_prices ?? [];
                    $weight = (string) $validated['selected_baggage_weight'];
                    $baggagePrice = (float) ($baggagePrices[$weight] ?? 0);
                }
                
                $totalPrice = ($basePrice + $baggagePrice) * $seatsCount;
            } else {
                if (! isset($validated['weight'])) {
                    return back()
                        ->withErrors(['weight' => 'Weight is required for cargo bookings.'])
                        ->withInput();
                }

                $weight = (float) $validated['weight'];
                $minWeight = (float) $serviceInstance->min_weight;
                if ($weight < $minWeight) {
                    return back()
                        ->withErrors(['weight' => "Weight must be at least {$minWeight} kg."])
                        ->withInput();
                }

                $totalPrice = $weight * (float) $serviceInstance->price_per_kg;
                $seatsCount = null;
            }

            $booking = Booking::create([
                'user_id' => $validated['user_id'],
                'agency_id' => $serviceInstance->agency_id ?? null,
                'serviceable_type' => $serviceModel,
                'serviceable_id' => $serviceInstance->id,
                'seats_count' => $seatsCount,
                'total_price' => $totalPrice,
                'weight' => $validated['weight'] ?? null,
                'status' => $validated['status'],
                'payment_status' => $validated['status'] === 'completed' ? 'paid' : 'pending',
                'payment_method' => $validated['payment_method'],
                
                // Passenger details
                'passenger_title' => $validated['passenger_title'],
                'passenger_first_name' => $validated['passenger_first_name'],
                'passenger_middle_name' => $validated['passenger_middle_name'] ?? null,
                'passenger_last_name' => $validated['passenger_last_name'],
                'passenger_date_of_birth' => $validated['passenger_date_of_birth'],
                'passenger_nationality' => $validated['passenger_nationality'],
                'passenger_type' => $validated['passenger_type'],
                
                // Contact information
                'passenger_phone' => $validated['passenger_phone'],
                'passenger_whatsapp' => $validated['passenger_whatsapp'] ?? null,
                
                // Passport details
                'passport_number' => $validated['passport_number'],
                'passport_issuing_country' => $validated['passport_issuing_country'],
                'passport_expiry_date' => $validated['passport_expiry_date'],
                'passport_image' => $passportImagePath,
                
                // Baggage
                'selected_baggage_weight' => $validated['selected_baggage_weight'] ?? null,
            ]);

            if ($booking->status === 'completed') {
                $this->recordAgencyEarning($booking);
            }

            if ($validated['service_type'] === 'flight') {
                $flight->decrement('available_seats', $seatsCount);
            }
        });

        return redirect()
            ->route('admin.bookings.index')
            ->with('success', 'تم إضافة الحجز بنجاح');
    }

    /**
     * Return services by agency and type.
     */
    public function getServicesByAgency(Request $request, $agencyId, $type)
    {
        $request->validate([
            'type' => ['nullable', 'in:flight,cargo'],
        ]);

        if ($type === 'flight') {
            $services = Flight::where('agency_id', $agencyId)
                ->orderBy('departure_time')
                ->get()
                ->map(function (Flight $flight) {
                    return [
                        'id' => $flight->id,
                        'label' => sprintf(
                            '%s → %s | %s',
                            $flight->origin,
                            $flight->destination,
                            optional($flight->departure_time)->format('M d, Y H:i')
                        ),
                        'price' => $flight->price,
                    ];
                });
        } else {
            $services = CargoService::where('agency_id', $agencyId)
                ->orderBy('type')
                ->get()
                ->map(function (CargoService $service) {
                    return [
                        'id' => $service->id,
                        'label' => sprintf(
                            '%s | %s → %s | Min %s kg',
                            ucfirst($service->type),
                            $service->route_from,
                            $service->route_to,
                            $service->min_weight,
                            $service->delivery_time_estimate
                        ),
                        'price' => $service->price_per_kg,
                        'price_per_kg' => $service->price_per_kg,
                        'min_weight' => $service->min_weight,
                    ];
                });
        }

        return response()->json($services);
    }

    /**
     * Update a booking.
     */
    public function update(Request $request, $id)
    {
        $booking = Booking::findOrFail($id);

        $validated = $request->validate([
            'status' => ['required', 'in:pending,accepted,rejected,completed,cancelled'],
            'payment_method' => ['sometimes', 'in:wallet,stripe,manual_receipt'],
        ]);

        $oldStatus = $booking->status;
        $newStatus = $validated['status'];

        DB::transaction(function () use ($booking, $validated, $oldStatus, $newStatus) {
            // Handle seat restoration for flight bookings when status changes to cancelled
            if ($oldStatus !== 'cancelled' && $newStatus === 'cancelled' && $booking->serviceable_type === Flight::class) {
                $flight = $booking->serviceable;
                if ($flight) {
                    $seatsToRestore = $booking->seats_count ?? 1;
                    $flight->increment('available_seats', $seatsToRestore);
                }
            }

            $booking->update([
                'status' => $newStatus,
                'payment_status' => $newStatus === 'completed' ? 'paid' : $booking->payment_status,
                'payment_method' => $validated['payment_method'] ?? $booking->payment_method,
            ]);

            if ($oldStatus !== 'completed' && $newStatus === 'completed') {
                $this->recordAgencyEarning($booking);
            }
        });

        return redirect()
            ->route('admin.bookings.index')
            ->with('success', 'Booking updated successfully.');
    }

    /**
     * Accept a booking.
     */
    public function accept(Request $request, $id)
    {
        $booking = Booking::findOrFail($id);
        
        if ($booking->status !== 'pending') {
            return redirect()
                ->back()
                ->with('error', 'Only pending bookings can be accepted.');
        }

        $booking->update([
            'status' => 'accepted',
            'payment_status' => 'paid',
        ]);

        // Send notification to user
        $this->sendBookingStatusNotification($booking, 'accepted');

        return redirect()
            ->back()
            ->with('success', 'Booking accepted successfully.');
    }

    /**
     * Reject a booking with rejection reason.
     */
    public function reject(Request $request, $id)
    {
        $request->validate([
            'rejection_reason' => 'required|string|max:500'
        ], [
            'rejection_reason.required' => 'Please provide a reason for rejection.'
        ]);

        $booking = Booking::findOrFail($id);
        
        if ($booking->status !== 'pending') {
            return redirect()
                ->back()
                ->with('error', 'Only pending bookings can be rejected.');
        }

        DB::transaction(function () use ($booking, $request) {
            // Restore seats for flight bookings
            if ($booking->serviceable_type === Flight::class) {
                $flight = $booking->serviceable;
                if ($flight) {
                    $seatsToRestore = $booking->seats_count ?? 1;
                    $flight->increment('available_seats', $seatsToRestore);
                }
            }

            $booking->update([
                'status' => 'cancelled',
                'rejection_reason' => $request->rejection_reason
            ]);

            // Send notification to user
            $this->sendBookingStatusNotification($booking, 'rejected', $request->rejection_reason);
        });

        return redirect()
            ->back()
            ->with('success', 'Booking rejected successfully.');
    }

    /**
     * Display the specified booking.
     */
    public function show($id)
    {
        $booking = Booking::with(['user', 'agency', 'serviceable'])
            ->whereIn('serviceable_type', [
                Flight::class,
                CargoService::class,
                'flight',
                'cargo',
            ])
            ->findOrFail($id);

        return view('admin.bookings.show', compact('booking'));
    }

    /**
     * Remove the specified booking.
     */
    public function destroy($id)
    {
        $booking = Booking::findOrFail($id);
        
        if ($booking->status === 'paid' || $booking->status === 'completed') {
            return redirect()
                ->back()
                ->with('error', 'Cannot delete paid or completed bookings.');
        }

        $booking->delete();

        return redirect()
            ->route('admin.bookings.index')
            ->with('success', 'Booking deleted successfully.');
    }

    private function recordAgencyEarning(Booking $booking): void
    {
        if (! $booking->agency_id) {
            return;
        }

        $alreadyRecorded = AgencyTransaction::where('booking_id', $booking->id)
            ->where('type', 'earning')
            ->exists();

        if ($alreadyRecorded) {
            return;
        }

        $commissionRate = (float) SystemSetting::getSetting('commission_rate', 5);
        $commissionAmount = $booking->total_price * ($commissionRate / 100);
        $agencyShare = $booking->total_price - $commissionAmount;

        if ($agencyShare <= 0) {
            return;
        }

        DB::transaction(function () use ($booking, $agencyShare) {
            $booking->agency()->increment('current_balance', $agencyShare);
            $booking->agency()->increment('total_lifetime_earnings', $agencyShare);

            AgencyTransaction::create([
                'agency_id' => $booking->agency_id,
                'booking_id' => $booking->id,
                'type' => 'earning',
                'amount' => $agencyShare,
                'description' => 'Booking completed earnings',
            ]);
        });
    }

    /**
     * Show the form for creating a cargo booking.
     */
    public function createCargoBooking()
    {
        return view('admin.cargo.create-booking');
    }

    /**
     * Get available cargo services for selected route.
     */
    public function getCargoServices(Request $request)
    {
        $from = $request->get('from');
        $to = $request->get('to');

        $services = CargoService::with('agency')
            ->where('route_from', $from)
            ->where('route_to', $to)
            ->where('status', 'active')
            ->get()
            ->map(function ($service) {
                return [
                    'id' => $service->id,
                    'agency_id' => $service->agency_id,
                    'agency_name' => $service->agency->name ?? __('N/A'),
                    'type' => $service->type,
                    'type_label' => __(ucfirst($service->type)),
                    'price_per_kg' => $service->price_per_kg,
                    'min_weight' => $service->min_weight,
                    'max_weight' => $service->max_weight,
                    'estimated_days' => $service->estimated_days,
                    'route_from' => $service->route_from,
                    'route_to' => $service->route_to,
                    'route_from_label' => __(ucfirst($service->route_from)),
                    'route_to_label' => __(ucfirst($service->route_to)),
                ];
            });

        return response()->json([
            'services' => $services
        ]);
    }

    /**
     * Store a newly created cargo booking.
     */
    public function storeCargoBooking(Request $request)
    {
        $validated = $request->validate([
            // Cargo Service
            'cargo_service_id' => 'required|exists:cargo_services,id',
            
            // Sender information
            'sender_name' => 'required|string|max:255',
            'sender_phone' => 'required|string|max:20',
            'sender_whatsapp' => 'nullable|string|max:20',
            'sender_city' => 'required|string|max:255',
            'sender_passport_image' => 'required|image|mimes:jpeg,jpg,png,pdf|max:5120',
            
            // Receiver information
            'receiver_name' => 'required|string|max:255',
            'receiver_phone' => 'required|string|max:20',
            'receiver_whatsapp' => 'nullable|string|max:20',
            'receiver_city' => 'required|string|max:255',
            
            // Shipment details
            'shipment_type' => 'required|in:documents,parcels,goods,personal_effects',
            'weight' => 'required|numeric|min:0.1',
            'contents_description' => 'required|string|min:10',
            'no_prohibited_items' => 'required|accepted',
            
            // Pricing
            'insurance_fee' => 'nullable|numeric|min:0',
            'customs_fee' => 'nullable|numeric|min:0',
            'total_price' => 'required|numeric|min:0',
        ]);

        DB::beginTransaction();
        try {
            // Get the selected cargo service
            $cargoService = CargoService::findOrFail($validated['cargo_service_id']);
            
            // Validate weight is within range
            $weight = (float) $validated['weight'];
            if ($weight < $cargoService->min_weight || $weight > $cargoService->max_weight) {
                return back()
                    ->withErrors(['weight' => __('Weight must be between') . " {$cargoService->min_weight} - {$cargoService->max_weight} " . __('kg')])
                    ->withInput();
            }

            // Handle passport image upload
            $passportImagePath = null;
            if ($request->hasFile('sender_passport_image')) {
                $passportImagePath = $request->file('sender_passport_image')
                    ->store('cargo_passports', 'public');
            }

            // Update cargo service with sender/receiver info and tracking details
            $cargoService->update([
                'sender_name' => $validated['sender_name'],
                'sender_phone' => $validated['sender_phone'],
                'sender_whatsapp' => $validated['sender_whatsapp'],
                'sender_country' => $cargoService->route_from,
                'sender_city' => $validated['sender_city'],
                'sender_passport_image' => $passportImagePath,
                
                'receiver_name' => $validated['receiver_name'],
                'receiver_phone' => $validated['receiver_phone'],
                'receiver_whatsapp' => $validated['receiver_whatsapp'],
                'receiver_country' => $cargoService->route_to,
                'receiver_city' => $validated['receiver_city'],
                
                'contents_description' => $validated['contents_description'],
                'no_prohibited_items' => true,
                'tracking_status' => 'pending',
                'current_location' => $validated['sender_city'] . ', ' . __(ucfirst($cargoService->route_from)),
                'status_updated_at' => now(),
            ]);

            // Create Booking record
            $booking = Booking::create([
                'user_id' => Auth::id(),
                'agency_id' => $cargoService->agency_id,
                'serviceable_type' => CargoService::class,
                'serviceable_id' => $cargoService->id,
                'weight' => $weight,
                'total_price' => $validated['total_price'],
                'status' => 'pending',
                'payment_status' => 'pending',
                'payment_method' => 'manual_receipt',
                
                // Passenger fields (using sender info for compatibility)
                'passenger_title' => 'mr',
                'passenger_first_name' => explode(' ', $validated['sender_name'])[0],
                'passenger_middle_name' => null,
                'passenger_last_name' => explode(' ', $validated['sender_name'])[1] ?? '',
                'passenger_date_of_birth' => now()->subYears(30),
                'passenger_nationality' => $cargoService->route_from,
                'passenger_type' => 'adult',
                'passenger_phone' => $validated['sender_phone'],
                'passenger_whatsapp' => $validated['sender_whatsapp'],
                'passport_number' => 'N/A',
                'passport_issuing_country' => $cargoService->route_from,
                'passport_expiry_date' => now()->addYears(5),
                'passport_image' => $passportImagePath,
            ]);

            DB::commit();

            return redirect()
                ->route('admin.bookings.index')
                ->with('success', __('cargo booking created successfully'));
        } catch (\Exception $e) {
            DB::rollBack();
            return back()
                ->withErrors(['error' => __('failed to create cargo booking') . ': ' . $e->getMessage()])
                ->withInput();
        }
    }

    /**
     * Show cargo tracking details.
     */
    public function showCargoTracking($id)
    {
        $booking = Booking::with(['serviceable', 'agency', 'user'])
            ->where('serviceable_type', CargoService::class)
            ->findOrFail($id);

        return view('admin.cargo.tracking', compact('booking'));
    }

    /**
     * Update cargo tracking status.
     */
    public function updateCargoStatus(Request $request, $id)
    {
        $validated = $request->validate([
            'tracking_status' => 'required|in:pending,picked_up,in_transit_origin,customs_origin,in_flight,arrived_destination,customs_destination,out_for_delivery,delivered',
            'current_location' => 'required|string|max:255',
        ]);

        $booking = Booking::where('serviceable_type', CargoService::class)
            ->findOrFail($id);

        $cargoService = $booking->serviceable;
        
        $cargoService->update([
            'tracking_status' => $validated['tracking_status'],
            'current_location' => $validated['current_location'],
            'status_updated_at' => now(),
        ]);

        // Auto-complete booking if delivered
        if ($validated['tracking_status'] === 'delivered') {
            $booking->update([
                'status' => 'completed',
                'payment_status' => 'paid',
            ]);

            // Record agency earning
            $this->recordAgencyEarning($booking);
        }

        // Send notification to user about shipment status update
        $this->sendShipmentStatusNotification($booking, $validated['tracking_status'], $validated['current_location']);

        return redirect()
            ->route('admin.cargo.bookings.tracking', $id)
            ->with('success', __('tracking status updated successfully'));
    }

    /**
     * Send shipment status notification to user.
     */
    protected function sendShipmentStatusNotification(Booking $booking, string $status, string $location)
    {
        $user = $booking->user;
        
        if (!$user) {
            return;
        }

        // Get status labels in Arabic
        $statusLabels = [
            'pending' => 'قيد الانتظار',
            'picked_up' => 'تم الاستلام',
            'in_transit_origin' => 'في الطريق من بلد المنشأ',
            'customs_origin' => 'في الجمارك - بلد المنشأ',
            'in_flight' => 'في الشحن الجوي/البحري',
            'arrived_destination' => 'وصلت الوجهة',
            'customs_destination' => 'في الجمارك - بلد الوجهة',
            'out_for_delivery' => 'قيد التوصيل',
            'delivered' => 'تم التوصيل',
        ];

        $statusLabel = $statusLabels[$status] ?? $status;
        
        $title = 'تحديث حالة الشحنة';
        $body = "الشحنة رقم #{$booking->id} الآن: {$statusLabel}\nالموقع الحالي: {$location}";

        // Send Firebase notification if user has FCM token
        \Log::info('Attempting to send FCM notification', [
            'user_id' => $user->id,
            'has_token' => !empty($user->fcm_token),
            'booking_id' => $booking->id,
        ]);
        
        if ($user->fcm_token) {
            try {
                \Log::info('Sending FCM notification', ['fcm_token' => substr($user->fcm_token, 0, 20) . '...']);
                $this->sendFirebaseNotification(
                    $user->fcm_token,
                    $title,
                    $body,
                    [
                        'type' => 'shipment_status_update',
                        'booking_id' => (string) $booking->id,
                        'tracking_status' => $status,
                        'location' => $location,
                    ]
                );
                \Log::info('FCM notification sent successfully');
            } catch (\Exception $e) {
                \Log::error('Failed to send FCM notification: ' . $e->getMessage());
            }
        } else {
            \Log::warning('User has no FCM token', ['user_id' => $user->id]);
        }

        // Create in-app notification
        if (class_exists(\App\Models\Notification::class)) {
            \App\Models\Notification::create([
                'user_id' => $user->id,
                'title' => $title,
                'body' => $body,
                'type' => 'shipment_' . $status,
                'data' => json_encode([
                    'booking_id' => $booking->id,
                    'tracking_status' => $status,
                    'location' => $location,
                ]),
                'read_at' => null,
            ]);
        }
    }

    /**
     * Display bookings pending payment verification.
     */
    public function pendingPayments(Request $request)
    {
        $bookings = Booking::with(['user', 'agency', 'serviceable'])
            ->where('payment_status', 'pending_verification')
            ->whereNotNull('payment_proof_image')
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return view('admin.bookings.pending-payments', compact('bookings'));
    }

    /**
     * Approve payment receipt and confirm booking.
     */
    public function approvePayment(Request $request, $id)
    {
        $booking = Booking::with(['user'])->findOrFail($id);

        if ($booking->payment_status !== 'pending_verification') {
            return redirect()->back()->with('error', __('This booking is not pending payment verification'));
        }

        DB::transaction(function () use ($booking) {
            $booking->update([
                'payment_status' => 'paid',
                'status' => 'accepted',
                'payment_verified_at' => now(),
                'payment_verified_by' => Auth::id(),
            ]);

            // Send notification to user
            $this->sendPaymentNotification($booking, 'approved');

            // Record agency earning if applicable
            if ($booking->agency_id) {
                $this->recordAgencyEarning($booking);
            }
        });

        return redirect()->back()->with('success', __('Payment approved and booking confirmed'));
    }

    /**
     * Reject payment receipt.
     */
    public function rejectPayment(Request $request, $id)
    {
        $validated = $request->validate([
            'rejection_reason' => 'required|string|max:500',
        ]);

        $booking = Booking::with(['user'])->findOrFail($id);

        if ($booking->payment_status !== 'pending_verification') {
            return redirect()->back()->with('error', __('This booking is not pending payment verification'));
        }

        $booking->update([
            'payment_status' => 'rejected',
            'payment_rejection_reason' => $validated['rejection_reason'],
            'payment_verified_at' => now(),
            'payment_verified_by' => Auth::id(),
        ]);

        // Send notification to user
        $this->sendPaymentNotification($booking, 'rejected', $validated['rejection_reason']);

        return redirect()->back()->with('success', __('Payment rejected and user notified'));
    }

    /**
     * Send payment notification to user.
     */
    protected function sendPaymentNotification(Booking $booking, string $status, ?string $reason = null)
    {
        $user = $booking->user;
        
        if (!$user) {
            return;
        }

        // Prepare notification data
        $title = $status === 'approved' 
            ? 'تم تأكيد الدفع' 
            : 'تم رفض إيصال الدفع';
        
        $body = $status === 'approved'
            ? "تم التحقق من إيصال الدفع وتأكيد حجزك رقم #{$booking->id}"
            : "تم رفض إيصال الدفع للحجز رقم #{$booking->id}. السبب: {$reason}";

        // Send Firebase notification if user has FCM token
        if ($user->fcm_token) {
            try {
                $this->sendFirebaseNotification(
                    $user->fcm_token,
                    $title,
                    $body,
                    [
                        'type' => 'payment_' . $status,
                        'booking_id' => (string) $booking->id,
                    ]
                );
            } catch (\Exception $e) {
                \Log::error('Failed to send FCM notification: ' . $e->getMessage());
            }
        }

        // Create in-app notification
        if (class_exists(\App\Models\Notification::class)) {
            \App\Models\Notification::create([
                'user_id' => $user->id,
                'title' => $title,
                'body' => $body,
                'type' => 'payment_' . $status,
                'data' => json_encode(['booking_id' => $booking->id]),
                'read_at' => null,
            ]);
        }
    }

    /**
     * Send Firebase Cloud Messaging notification.
     */
    protected function sendFirebaseNotification(string $token, string $title, string $body, array $data = [])
    {
        \Log::info('sendFirebaseNotification called', ['title' => $title]);
        
        $credentialsPath = config_path('firebase_credentials.json');
        
        if (!file_exists($credentialsPath)) {
            \Log::warning('Firebase credentials not found at: ' . $credentialsPath);
            return;
        }

        $credentials = json_decode(file_get_contents($credentialsPath), true);
        \Log::info('Firebase credentials loaded', ['project_id' => $credentials['project_id'] ?? 'unknown']);
        
        // Get access token using service account
        $accessToken = $this->getFirebaseAccessToken($credentials);
        
        if (!$accessToken) {
            \Log::error('Failed to get Firebase access token');
            return;
        }

        \Log::info('Firebase access token obtained');
        $projectId = $credentials['project_id'];
        $url = "https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send";

        $message = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
                'data' => $data,
                'android' => [
                    'priority' => 'high',
                    'notification' => [
                        'sound' => 'default',
                        'channel_id' => 'booking_channel',
                    ],
                ],
                'apns' => [
                    'payload' => [
                        'aps' => [
                            'sound' => 'default',
                            'badge' => 1,
                        ],
                    ],
                ],
            ],
        ];

        \Log::info('Sending FCM request to: ' . $url);
        $response = \Http::withToken($accessToken)
            ->post($url, $message);

        if (!$response->successful()) {
            \Log::error('FCM send failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
        } else {
            \Log::info('FCM notification sent successfully', ['response' => $response->json()]);
        }
    }

    /**
     * Get Firebase access token using service account.
     */
    protected function getFirebaseAccessToken(array $credentials): ?string
    {
        $now = time();
        $expiry = $now + 3600;

        $header = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
        
        $payload = base64_encode(json_encode([
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $expiry,
        ]));

        $unsignedToken = $header . '.' . $payload;
        
        openssl_sign($unsignedToken, $signature, $credentials['private_key'], 'SHA256');
        $jwt = $unsignedToken . '.' . base64_encode($signature);

        $response = \Http::asForm()->post('https://oauth2.googleapis.com/token', [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ]);

        if ($response->successful()) {
            return $response->json('access_token');
        }

        \Log::error('Failed to get Firebase access token: ' . $response->body());
        return null;
    }

    /**
     * Upload payment receipt manually by admin.
     */
    public function uploadReceipt(Request $request, $id)
    {
        $request->validate([
            'payment_proof_image' => 'required|image|mimes:jpeg,png,jpg|max:5120',
        ]);

        $booking = Booking::findOrFail($id);

        // Upload the receipt image
        $imagePath = $request->file('payment_proof_image')->store('payment_receipts', 'public');

        $booking->update([
            'payment_proof_image' => $imagePath,
            'payment_status' => 'pending_verification',
        ]);

        return redirect()
            ->route('admin.bookings.show', $id)
            ->with('success', __('Receipt uploaded successfully. Ready for verification.'));
    }

    /**
     * Send booking status notification (accepted/rejected).
     */
    protected function sendBookingStatusNotification(Booking $booking, string $status, ?string $rejectionReason = null)
    {
        $user = $booking->user;
        if (!$user) {
            return;
        }

        // Determine booking type
        $bookingType = 'حجز';
        if ($booking->serviceable_type === \App\Models\Flight::class) {
            $bookingType = 'حجز الرحلة';
        } elseif ($booking->serviceable_type === \App\Models\CargoService::class) {
            $bookingType = 'حجز الشحن';
        }

        // Build notification title and body
        if ($status === 'accepted') {
            $title = '✅ تم قبول الحجز';
            $body = "تم قبول {$bookingType} رقم #{$booking->id}";
            $notificationType = 'booking_accepted';
        } else {
            $title = '❌ تم رفض الحجز';
            $body = "تم رفض {$bookingType} رقم #{$booking->id}";
            if ($rejectionReason) {
                $body .= "\nالسبب: {$rejectionReason}";
            }
            $notificationType = 'booking_rejected';
        }

        // Send Firebase notification if user has FCM token
        \Log::info('Attempting to send booking status notification', [
            'user_id' => $user->id,
            'has_token' => !empty($user->fcm_token),
            'booking_id' => $booking->id,
            'status' => $status,
        ]);

        if ($user->fcm_token) {
            try {
                \Log::info('Sending FCM notification', ['fcm_token' => substr($user->fcm_token, 0, 20) . '...']);
                $this->sendFirebaseNotification(
                    $user->fcm_token,
                    $title,
                    $body,
                    [
                        'type' => $notificationType,
                        'booking_id' => (string) $booking->id,
                        'status' => $status,
                        'rejection_reason' => $rejectionReason ?? '',
                    ]
                );
                \Log::info('FCM notification sent successfully');
            } catch (\Exception $e) {
                \Log::error('Failed to send FCM notification: ' . $e->getMessage());
            }
        } else {
            \Log::warning('User has no FCM token', ['user_id' => $user->id]);
        }

        // Create in-app notification
        if (class_exists(\App\Models\Notification::class)) {
            \App\Models\Notification::create([
                'user_id' => $user->id,
                'title' => $title,
                'body' => $body,
                'type' => $notificationType,
                'data' => json_encode([
                    'booking_id' => $booking->id,
                    'status' => $status,
                    'rejection_reason' => $rejectionReason,
                ]),
                'read_at' => null,
            ]);
        }
    }
}
