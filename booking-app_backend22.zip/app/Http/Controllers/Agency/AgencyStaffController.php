<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;

class AgencyStaffController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('manage-agency-staff');

            return $next($request);
        });
    }

    public function index()
    {
        $agencyId = Auth::user()->agency_id;

        $staff = User::where('agency_id', $agencyId)
            ->where('role', 'agency_staff')
            ->latest()
            ->paginate(15);

        return view('agency.staff.index', compact('staff'));
    }

    public function create()
    {
        return view('agency.staff.create');
    }

    public function store(Request $request)
    {
        $agencyId = Auth::user()->agency_id;

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'role' => 'agency_staff',
            'agency_id' => $agencyId,
            'is_active' => true,
        ]);

        return redirect()->route('agency.staff.index')->with('success', 'Staff member created.');
    }

    public function edit(User $staff)
    {
        $this->authorizeStaff($staff);

        return view('agency.staff.edit', compact('staff'));
    }

    public function update(Request $request, User $staff)
    {
        $this->authorizeStaff($staff);

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $staff->id],
            'password' => ['nullable', 'string', 'min:8'],
        ]);

        $staff->name = $data['name'];
        $staff->email = $data['email'];
        if (! empty($data['password'])) {
            $staff->password = Hash::make($data['password']);
        }
        $staff->save();

        return redirect()->route('agency.staff.index')->with('success', 'Staff member updated.');
    }

    public function destroy(User $staff)
    {
        $this->authorizeStaff($staff);

        $staff->delete();

        return redirect()->route('agency.staff.index')->with('success', 'Staff member removed.');
    }

    private function authorizeStaff(User $staff): void
    {
        if ($staff->agency_id !== Auth::user()->agency_id || $staff->role !== 'agency_staff') {
            abort(403);
        }
    }
}
