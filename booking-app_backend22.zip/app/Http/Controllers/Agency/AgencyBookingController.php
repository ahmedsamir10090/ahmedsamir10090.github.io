<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Flight;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AgencyBookingController extends Controller
{
    public function index()
    {
        $agencyId = Auth::user()->agency_id;

        $bookings = Booking::with(['user', 'serviceable'])
            ->where('agency_id', $agencyId)
            ->latest()
            ->paginate(15);

        return view('agency.bookings.index', compact('bookings'));
    }

    public function create()
    {
        $agencyId = Auth::user()->agency_id;
        
        $users = User::orderBy('name')->get();
        $flights = Flight::where('agency_id', $agencyId)
            ->where('status', 'active')
            ->where('available_seats', '>', 0)
            ->orderBy('departure_time')
            ->get();

        return view('agency.bookings.create', compact('users', 'flights'));
    }

    public function store(Request $request)
    {
        $agencyId = Auth::user()->agency_id;
        
        $validated = $request->validate([
            'user_id' => ['required', 'exists:users,id'],
            'service_id' => ['required', 'integer'],
            'seats_count' => ['nullable', 'integer', 'min:1'],
            'status' => ['required', 'in:pending,accepted,rejected,completed,cancelled'],
            'payment_method' => ['required', 'in:wallet,stripe,manual_receipt'],
            
            // Passenger details
            'passenger_title' => ['required', 'string', 'in:mr,ms,mrs'],
            'passenger_first_name' => ['required', 'string', 'max:255'],
            'passenger_middle_name' => ['nullable', 'string', 'max:255'],
            'passenger_last_name' => ['required', 'string', 'max:255'],
            'passenger_date_of_birth' => ['required', 'date', 'before:today'],
            'passenger_nationality' => ['required', 'string', 'max:100'],
            'passenger_type' => ['required', 'string', 'in:adult,child'],
            
            // Contact information
            'passenger_phone' => ['required', 'string', 'max:20'],
            'passenger_whatsapp' => ['nullable', 'string', 'max:20'],
            
            // Passport details
            'passport_number' => ['required', 'string', 'max:50'],
            'passport_issuing_country' => ['required', 'string', 'max:100'],
            'passport_expiry_date' => ['required', 'date', 'after:today'],
            'passport_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
            
            // Baggage
            'selected_baggage_weight' => ['nullable', 'integer', 'min:0'],
        ]);

        $flight = Flight::where('agency_id', $agencyId)->findOrFail($validated['service_id']);

        DB::transaction(function () use ($validated, $flight, $agencyId, $request) {
            // Handle passport image upload
            $passportImagePath = null;
            if ($request->hasFile('passport_image')) {
                $passportImagePath = $request->file('passport_image')->store('passport_images', 'public');
            }
            
            $seatsCount = $validated['seats_count'] ?? 1;
            
            $flightLocked = Flight::lockForUpdate()->find($flight->id);
            if ($flightLocked->available_seats < $seatsCount) {
                abort(400, 'Not enough seats available on this flight.');
            }
            
            // Calculate price based on passenger type (adult/child)
            $basePrice = $validated['passenger_type'] === 'adult' 
                ? (float) $flight->adult_price 
                : (float) $flight->child_price;
            
            // Add baggage price if selected
            $baggagePrice = 0;
            if (isset($validated['selected_baggage_weight']) && $validated['selected_baggage_weight'] > 0) {
                $baggagePrices = $flight->baggage_prices ?? [];
                $weight = (string) $validated['selected_baggage_weight'];
                $baggagePrice = (float) ($baggagePrices[$weight] ?? 0);
            }
            
            $totalPrice = ($basePrice + $baggagePrice) * $seatsCount;

            $booking = Booking::create([
                'user_id' => $validated['user_id'],
                'agency_id' => $agencyId,
                'serviceable_type' => Flight::class,
                'serviceable_id' => $flight->id,
                'seats_count' => $seatsCount,
                'total_price' => $totalPrice,
                'status' => $validated['status'],
                'payment_status' => $validated['status'] === 'completed' ? 'paid' : 'pending',
                'payment_method' => $validated['payment_method'],
                
                // Passenger details
                'passenger_title' => $validated['passenger_title'],
                'passenger_first_name' => $validated['passenger_first_name'],
                'passenger_middle_name' => $validated['passenger_middle_name'] ?? null,
                'passenger_last_name' => $validated['passenger_last_name'],
                'passenger_date_of_birth' => $validated['passenger_date_of_birth'],
                'passenger_nationality' => $validated['passenger_nationality'],
                'passenger_type' => $validated['passenger_type'],
                
                // Contact information
                'passenger_phone' => $validated['passenger_phone'],
                'passenger_whatsapp' => $validated['passenger_whatsapp'] ?? null,
                
                // Passport details
                'passport_number' => $validated['passport_number'],
                'passport_issuing_country' => $validated['passport_issuing_country'],
                'passport_expiry_date' => $validated['passport_expiry_date'],
                'passport_image' => $passportImagePath,
                
                // Baggage
                'selected_baggage_weight' => $validated['selected_baggage_weight'] ?? null,
            ]);

            $flightLocked->decrement('available_seats', $seatsCount);
        });

        return redirect()
            ->route('agency.bookings.index')
            ->with('success', 'تم إضافة الحجز بنجاح');
    }

  public function show($bookingId) // لن نستخدم Route Model Binding هنا
    {
        // الخطوة 1: احصل على المستخدم الحالي
        $currentUser = auth()->user();
        
        // الخطوة 2: احصل على الوكالة الخاصة به
        $userAgencyId = $currentUser->agency_id;

        // الخطوة 3: ابحث عن الحجز المطلوب يدوياً من قاعدة البيانات
        $booking = \App\Models\Booking::find($bookingId);

        // الخطوة 4: إذا لم يتم العثور على الحجز، أرسل خطأ 404
        if (!$booking) {
            abort(404);
        }

        // الخطوة 5: قم بالمقارنة المباشرة
        if ($userAgencyId != $booking->agency_id) {
            abort(403, 'This action is unauthorized.');
        }

        // --- إذا وصلنا إلى هنا، فكل شيء سليم ---

        // قم بتحميل العلاقات لعرضها في الصفحة
        $booking->load(['user', 'serviceable', 'agency']);

        // اعرض الصفحة
        return view('agency.bookings.show', compact('booking'));
    }

        public function updateStatus(Request $request, $bookingId) // غيرنا Booking $booking إلى $bookingId
    {
        // الخطوة 1: ابحث عن الحجز يدوياً
        $booking = \App\Models\Booking::find($bookingId);
        if (!$booking) {
            abort(404); // إذا لم يتم العثور على الحجز
        }

        // الخطوة 2: التحقق من الملكية (الذي كان يسبب الخطأ)
        if (auth()->user()->agency_id != $booking->agency_id) {
            abort(403, 'This action is unauthorized.');
        }

        // الخطوة 3: التحقق من البيانات
        $data = $request->validate([
            'status' => 'required|in:accepted,rejected',
            'reason' => 'nullable|string|max:255',
        ]);

        // الخطوة 4: تحديث وحفظ
        $booking->status = $data['status'];
        if ($data['status'] === 'rejected') {
            $booking->rejection_reason = $data['reason'] ?? null;
        }
        $booking->save();

        // Send notification to user
        $this->sendBookingStatusNotification($booking, $data['status'], $data['reason'] ?? null);

        // الخطوة 5: إعادة التوجيه
        return redirect()->route('agency.bookings.index')->with('success', 'Booking status updated.');
    }

    /**
     * Send booking status notification (accepted/rejected).
     */
    protected function sendBookingStatusNotification(Booking $booking, string $status, ?string $rejectionReason = null)
    {
        $user = $booking->user;
        if (!$user) {
            return;
        }

        // Determine booking type
        $bookingType = 'حجز';
        if ($booking->serviceable_type === \App\Models\Flight::class) {
            $bookingType = 'حجز الرحلة';
        } elseif ($booking->serviceable_type === \App\Models\CargoService::class) {
            $bookingType = 'حجز الشحن';
        }

        // Build notification title and body
        if ($status === 'accepted') {
            $title = '✅ تم قبول الحجز';
            $body = "تم قبول {$bookingType} رقم #{$booking->id}";
            $notificationType = 'booking_accepted';
        } else {
            $title = '❌ تم رفض الحجز';
            $body = "تم رفض {$bookingType} رقم #{$booking->id}";
            if ($rejectionReason) {
                $body .= "\nالسبب: {$rejectionReason}";
            }
            $notificationType = 'booking_rejected';
        }

        // Send Firebase notification if user has FCM token
        if ($user->fcm_token) {
            try {
                $this->sendFirebaseNotification(
                    $user->fcm_token,
                    $title,
                    $body,
                    [
                        'type' => $notificationType,
                        'booking_id' => (string) $booking->id,
                        'status' => $status,
                        'rejection_reason' => $rejectionReason ?? '',
                    ]
                );
            } catch (\Exception $e) {
                \Log::error('Failed to send FCM notification: ' . $e->getMessage());
            }
        }

        // Create in-app notification
        if (class_exists(\App\Models\Notification::class)) {
            \App\Models\Notification::create([
                'user_id' => $user->id,
                'title' => $title,
                'body' => $body,
                'type' => $notificationType,
                'data' => json_encode([
                    'booking_id' => $booking->id,
                    'status' => $status,
                    'rejection_reason' => $rejectionReason,
                ]),
                'read_at' => null,
            ]);
        }
    }

    /**
     * Send Firebase Cloud Messaging notification.
     */
    protected function sendFirebaseNotification(string $token, string $title, string $body, array $data = [])
    {
        $credentialsPath = config_path('firebase_credentials.json');
        
        if (!file_exists($credentialsPath)) {
            \Log::warning('Firebase credentials not found');
            return;
        }

        $credentials = json_decode(file_get_contents($credentialsPath), true);
        
        // Get access token using service account
        $accessToken = $this->getFirebaseAccessToken($credentials);
        
        if (!$accessToken) {
            return;
        }

        $projectId = $credentials['project_id'];
        $url = "https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send";

        $message = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
                'data' => $data,
                'android' => [
                    'priority' => 'high',
                    'notification' => [
                        'sound' => 'default',
                        'channel_id' => 'booking_channel',
                    ],
                ],
                'apns' => [
                    'payload' => [
                        'aps' => [
                            'sound' => 'default',
                            'badge' => 1,
                        ],
                    ],
                ],
            ],
        ];

        $response = \Http::withToken($accessToken)->post($url, $message);

        if (!$response->successful()) {
            \Log::error('FCM send failed', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
        }
    }

    /**
     * Get Firebase access token using service account.
     */
    protected function getFirebaseAccessToken(array $credentials): ?string
    {
        $now = time();
        $expiry = $now + 3600;

        $header = base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
        
        $payload = base64_encode(json_encode([
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $expiry,
        ]));

        $unsignedToken = $header . '.' . $payload;
        
        openssl_sign($unsignedToken, $signature, $credentials['private_key'], 'SHA256');
        $jwt = $unsignedToken . '.' . base64_encode($signature);

        $response = \Http::asForm()->post('https://oauth2.googleapis.com/token', [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ]);

        if ($response->successful()) {
            return $response->json('access_token');
        }

        \Log::error('Failed to get Firebase access token: ' . $response->body());
        return null;
    }

   
}
