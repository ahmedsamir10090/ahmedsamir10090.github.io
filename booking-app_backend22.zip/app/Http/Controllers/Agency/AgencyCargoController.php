<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use App\Models\CargoService;
use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AgencyCargoController extends Controller
{
    public function index()
    {
        $agencyId = Auth::user()->agency_id;

        $services = CargoService::where('agency_id', $agencyId)
            ->latest()
            ->paginate(15);

        return view('agency.cargo.index', compact('services'));
    }

    public function create()
    {
        $countries = Country::orderBy('name_' . app()->getLocale())->get();
        return view('agency.cargo.create', compact('countries'));
    }

    public function store(Request $request)
    {
        $agencyId = Auth::user()->agency_id;

        $data = $request->validate([
            'type' => 'required|string|max:50',
            'price_per_kg' => 'required|numeric|min:0',
            'min_weight' => 'required|numeric|min:0',
            'delivery_time_estimate' => 'nullable|string|max:100',
            'route_from' => 'required|string|max:100',
            'route_to' => 'required|string|max:100',
        ]);

        $data['agency_id'] = $agencyId;

        CargoService::create($data);

        return redirect()->route('agency.cargo.index')->with('success', 'Cargo service created successfully.');
    }

    public function edit(CargoService $cargo)
    {
        $this->authorizeCargo($cargo);

        $countries = Country::orderBy('name_' . app()->getLocale())->get();
        return view('agency.cargo.edit', ['service' => $cargo, 'countries' => $countries]);
    }

    public function update(Request $request, CargoService $cargo)
    {
        $this->authorizeCargo($cargo);

        $data = $request->validate([
            'type' => 'required|string|max:50',
            'price_per_kg' => 'required|numeric|min:0',
            'min_weight' => 'required|numeric|min:0',
            'delivery_time_estimate' => 'nullable|string|max:100',
            'route_from' => 'required|string|max:100',
            'route_to' => 'required|string|max:100',
        ]);

        $cargo->update($data);

        return redirect()->route('agency.cargo.index')->with('success', 'Cargo service updated successfully.');
    }

    public function destroy(CargoService $cargo)
    {
        $this->authorizeCargo($cargo);

        $cargo->delete();

        return redirect()->route('agency.cargo.index')->with('success', 'Cargo service deleted successfully.');
    }

    private function authorizeCargo(CargoService $cargo): void
    {
        if ($cargo->agency_id !== Auth::user()->agency_id) {
            abort(403);
        }
    }
}
