<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use App\Models\Agency;
use App\Models\Booking;
use App\Models\Flight;
use Illuminate\Support\Facades\Auth;

class AgencyDashboardController extends Controller
{
    /**
     * Display the agency dashboard for the authenticated manager.
     */
    public function index()
    {
        $user = Auth::user();
        $agency = $user?->agency;

        if (! $agency) {
            abort(404, 'Agency not found for this user.');
        }

        $stats = [
            'my_total_revenue' => $agency->current_balance ?? 0,
            'my_pending_bookings' => Booking::where('agency_id', $agency->id)
                ->where('status', 'pending')
                ->count(),
            'my_completed_bookings' => Booking::where('agency_id', $agency->id)
                ->where('status', 'completed')
                ->count(),
            'my_active_flights' => Flight::where('agency_id', $agency->id)
                ->where('status', 'active')
                ->count(),
        ];

        $latestBookings = Booking::with(['user'])
            ->where('agency_id', $agency->id)
            ->latest()
            ->take(5)
            ->get();

        return view('agency.dashboard', compact('stats', 'latestBookings'));
    }
}
