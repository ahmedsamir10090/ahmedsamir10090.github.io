<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use App\Models\Flight;
use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AgencyFlightController extends Controller
{
    public function index()
    {
        $agencyId = Auth::user()->agency_id;

        $flights = Flight::with(['originAirport.country', 'destinationAirport.country'])
            ->where('agency_id', $agencyId)
            ->latest()
            ->paginate(15);

        return view('agency.flights.index', compact('flights'));
    }

    public function create()
    {
        $countries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'airport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        // Get seaports from airports table
        $seaportCountries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'seaport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        return view('agency.flights.create', compact('countries', 'seaportCountries'));
    }

    public function store(Request $request)
    {
        $agencyId = auth()->user()->agency_id;

        $data = $request->validate([
            'flight_number' => 'required|string|max:50',
            'flight_type' => 'required|in:air,sea',
            'origin_airport_id' => 'required|exists:airports,id',
            'destination_airport_id' => 'required|exists:airports,id|different:origin_airport_id',
            'departure_time' => 'required|date',
            'arrival_time' => 'required|date|after:departure_time',
            'price' => 'required|numeric|min:0',
            'available_seats' => 'required|integer|min:0',
            'status' => 'required|in:pending,active,cancelled',
        ]);

        $data['agency_id'] = $agencyId;
        $data['type'] = $data['flight_type']; // Sync with type field

        \App\Models\Flight::create($data);

        return redirect()->route('agency.flights.index')->with('success', 'Flight created successfully.');
    }

    public function edit(Flight $flight)
    {
        $this->authorizeFlight($flight);

        $countries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'airport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        // Get seaports from airports table
        $seaportCountries = Country::with([
            'airports' => function($query) {
                $query->where('type', 'seaport');
            }
        ])->orderBy('name_' . app()->getLocale())->get();
        
        return view('agency.flights.edit', compact('flight', 'countries', 'seaportCountries'));
    }

    public function update(Request $request, Flight $flight)
    {
        $this->authorizeFlight($flight);

        $data = $request->validate([
            'flight_number' => 'required|string|max:50',
            'flight_type' => 'required|in:air,sea',
            'origin_airport_id' => 'required|exists:airports,id',
            'destination_airport_id' => 'required|exists:airports,id|different:origin_airport_id',
            'departure_time' => 'required|date',
            'arrival_time' => 'required|date|after:departure_time',
            'price' => 'required|numeric|min:0',
            'available_seats' => 'required|integer|min:0',
            'status' => 'required|in:pending,active,cancelled',
        ]);
        
        $data['type'] = $data['flight_type']; // Sync with type field

        $flight->update($data);

        return redirect()->route('agency.flights.index')->with('success', 'Flight updated successfully.');
    }

    public function destroy(Flight $flight)
    {
        $this->authorizeFlight($flight);

        $flight->delete();

        return redirect()->route('agency.flights.index')->with('success', 'Flight deleted successfully.');
    }

    private function authorizeFlight(Flight $flight): void
    {
        if ($flight->agency_id !== Auth::user()->agency_id) {
            abort(403);
        }
    }
}
