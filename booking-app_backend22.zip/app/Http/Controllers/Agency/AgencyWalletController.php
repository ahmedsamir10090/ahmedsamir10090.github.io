<?php

namespace App\Http\Controllers\Agency;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class AgencyWalletController extends Controller
{
    /**
     * Create a new controller instance.
     * The authorize method is called here to protect all methods in this controller.
     */

    
    public function __construct()
    {
            // نقطة التفتيش الأولى: هل نصل إلى هنا؟
        // dd('Controller constructor reached!'); 
        // This line checks the 'manage-agency-finances' Gate before any method is executed.
        // This is the line that was likely missing or incorrect.
        // $this->authorize('manage-agency-finances');
    }

    /**
     * Display the agency's wallet, earnings, and transaction history.
     */
    public function index()
    {
        // Get the agency associated with the currently authenticated manager
        $agency = Auth::user()->agency;

        // Eager load the transactions to avoid N+1 query problems
        $transactions = $agency->agencyTransactions()->latest()->paginate(15);

        // Pass the agency and its transactions to the view
        return view('agency.wallet.index', [
            'agency' => $agency,
            'transactions' => $transactions
        ]);
    }

        public function payoutRequest(Request $request)
    {
        // مستقبلاً: يمكنك هنا إرسال إشعار للأدمن بأن الوكالة تطلب سحب أرباحها.
        
        // حالياً: سنقوم فقط بإعادة التوجيه مع رسالة نجاح.
        return back()->with('success', 'Your payout request has been sent to the administration.');
    }
}
