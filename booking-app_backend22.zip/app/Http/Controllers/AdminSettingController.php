<?php

namespace App\Http\Controllers;

use App\Models\SystemSetting;
use Illuminate\Http\Request;

class AdminSettingController extends Controller
{
    /**
     * Display system settings page.
     */
    public function index()
    {
        $settings = [
            'online_payment_enabled' => SystemSetting::getSetting('online_payment_enabled', false),
            'commission_rate' => SystemSetting::getSetting('commission_rate', 0),
        ];

        return view('admin.settings.index', compact('settings'));
    }

    /**
     * Update system settings.
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'online_payment_enabled' => 'required|boolean',
            'commission_rate' => 'required|numeric|min:0|max:100',
        ], [
            'commission_rate.min' => 'Commission rate must be at least 0%.',
            'commission_rate.max' => 'Commission rate cannot exceed 100%.',
        ]);

        // Update settings in database
        SystemSetting::setSetting('online_payment_enabled', $validated['online_payment_enabled'] ? '1' : '0');
        SystemSetting::setSetting('commission_rate', (string) $validated['commission_rate']);

        return redirect()
            ->route('admin.settings.index')
            ->with('success', 'System settings updated successfully.');
    }

    /**
     * Reset all settings to default values.
     */
    public function reset()
    {
        SystemSetting::setSetting('online_payment_enabled', '0');
        SystemSetting::setSetting('commission_rate', '0');

        return redirect()
            ->route('admin.settings.index')
            ->with('success', 'Settings reset to default values.');
    }
}
