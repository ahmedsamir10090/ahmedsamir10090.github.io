<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class EnsureUserIsAgency
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // أولاً، تأكد أن المستخدم مسجل دخوله
         if (!Auth::check()) {
        return redirect('login');
    }

      
            if (Auth::user()->role === 'agency_manager' || Auth::user()->role === 'agency_staff') {
        return $next($request);
    }

        // إذا لم يكن أياً منهما، امنعه
    abort(403, 'Access restricted to Agency personnel only.');
    }

    
}
