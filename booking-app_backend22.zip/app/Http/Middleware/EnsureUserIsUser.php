<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsUser
{
    /**
     * Handle an incoming request.
     * Allows regular users (role = 'user') to access routes.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        // Allow users with 'user' role
        if ($user->role === 'user') {
            return $next($request);
        }

        return response()->json([
            'message' => 'Access denied. User role required.',
        ], 403);
    }
}
