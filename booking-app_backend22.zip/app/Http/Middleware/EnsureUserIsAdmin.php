<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class EnsureUserIsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
public function handle(Request $request, Closure $next): Response
{
    if (!Auth::check()) {
        return redirect('login');
    }

    // السماح فقط للأدمن
    // (الوكالة لن تمر من هنا)
    if (Auth::user()->role === 'admin') {
        return $next($request);
    }

    abort(403, 'Access restricted to Administrators only.');
}

}
