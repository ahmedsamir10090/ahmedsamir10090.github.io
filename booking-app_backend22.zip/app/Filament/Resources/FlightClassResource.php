<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FlightClassResource\Pages;
use App\Models\Flight;
use App\Models\FlightClass;
use Filament\Forms;
use Filament\Schemas\Schema;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class FlightClassResource extends Resource
{
    protected static ?string $model = FlightClass::class;

    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-queue-list';

    protected static ?string $navigationLabel = 'Flight Classes';

    protected static string | \UnitEnum | null $navigationGroup = 'Flight Management';

    protected static ?int $navigationSort = 2;

public static function form(Schema $schema): Schema
    {
        return $schema
            ->schema([
                Forms\Components\Section::make('Class Information')
                    ->schema([
                        Forms\Components\Select::make('flight_id')
                            ->label('Flight')
                            ->relationship('flight', 'flight_number')
                            ->searchable()
                            ->preload()
                            ->required()
                            ->reactive()
                            ->afterStateUpdated(function ($state, callable $set) {
                                // Auto-fill flight details if needed
                                if ($state) {
                                    $flight = Flight::find($state);
                                    if ($flight) {
                                        $set('price', $flight->price);
                                    }
                                }
                            }),

                        Forms\Components\Select::make('class_type')
                            ->label('Class Type')
                            ->options([
                                'economy' => 'Economy',
                                'business' => 'Business',
                                'first' => 'First Class',
                            ])
                            ->required()
                            ->reactive()
                            ->afterStateUpdated(function ($state, callable $set, $get) {
                                // Auto-generate class name
                                $flightId = $get('flight_id');
                                if ($flightId && $state) {
                                    $flight = Flight::find($flightId);
                                    $className = ucfirst($state);
                                    $set('class_name', "{$className} - {$flight->flight_number}");
                                }
                            }),

                        Forms\Components\TextInput::make('class_name')
                            ->label('Class Name')
                            ->required()
                            ->maxLength(100)
                            ->placeholder('e.g., Economy Standard, Business Plus')
                            ->helperText('A descriptive name for this class'),

                        Forms\Components\Toggle::make('is_active')
                            ->label('Active')
                            ->default(true)
                            ->helperText('Enable/disable this class for booking'),
                    ])
                    ->columns(2),

                Forms\Components\Section::make('Pricing & Capacity')
                    ->schema([
                        Forms\Components\TextInput::make('price')
                            ->label('Price per Seat')
                            ->numeric()
                            ->prefix('$')
                            ->required()
                            ->minValue(0)
                            ->step(0.01),

                        Forms\Components\TextInput::make('total_seats')
                            ->label('Total Seats')
                            ->numeric()
                            ->required()
                            ->minValue(1)
                            ->reactive()
                            ->afterStateUpdated(function ($state, callable $set, $get) {
                                // Set available_seats equal to total_seats on create
                                if (!$get('id')) {
                                    $set('available_seats', $state);
                                }
                            }),

                        Forms\Components\TextInput::make('available_seats')
                            ->label('Available Seats')
                            ->numeric()
                            ->required()
                            ->minValue(0)
                            ->helperText('Currently available for booking')
                            ->disabled(fn ($record) => $record !== null), // Only editable on create

                        Forms\Components\TextInput::make('baggage_allowance')
                            ->label('Baggage Allowance (KG)')
                            ->numeric()
                            ->default(20)
                            ->required()
                            ->minValue(0)
                            ->suffix('KG'),
                    ])
                    ->columns(2),

                Forms\Components\Section::make('Policies & Amenities')
                    ->schema([
                        Forms\Components\Textarea::make('refund_policy')
                            ->label('Refund Policy')
                            ->rows(3)
                            ->placeholder('e.g., Full refund up to 24 hours before departure')
                            ->helperText('Explain the refund terms for this class'),

                        Forms\Components\Textarea::make('change_policy')
                            ->label('Change Policy')
                            ->rows(3)
                            ->placeholder('e.g., Changes allowed with $50 fee')
                            ->helperText('Explain the change/modification terms'),

                        Forms\Components\Textarea::make('amenities')
                            ->label('Amenities & Perks')
                            ->rows(3)
                            ->placeholder('e.g., Priority boarding, In-flight meal, Extra legroom')
                            ->helperText('List additional benefits included'),
                    ])
                    ->collapsible(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('flight.flight_number')
                    ->label('Flight')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('flight.origin')
                    ->label('Route')
                    ->formatStateUsing(fn ($record) => "{$record->flight->origin} → {$record->flight->destination}")
                    ->searchable(['origin', 'destination']),

                Tables\Columns\BadgeColumn::make('class_type')
                    ->label('Type')
                    ->colors([
                        'secondary' => 'economy',
                        'warning' => 'business',
                        'success' => 'first',
                    ])
                    ->formatStateUsing(fn ($state) => ucfirst($state)),

                Tables\Columns\TextColumn::make('class_name')
                    ->label('Class Name')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('price')
                    ->label('Price')
                    ->money('usd')
                    ->sortable(),

                Tables\Columns\TextColumn::make('available_seats')
                    ->label('Available')
                    ->formatStateUsing(fn ($record) => "{$record->available_seats} / {$record->total_seats}")
                    ->badge()
                    ->color(fn ($record) => $record->getStatusColor()),

                Tables\Columns\TextColumn::make('baggage_allowance')
                    ->label('Baggage')
                    ->suffix(' KG')
                    ->alignCenter(),

                Tables\Columns\IconColumn::make('is_active')
                    ->label('Active')
                    ->boolean()
                    ->sortable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('class_type')
                    ->options([
                        'economy' => 'Economy',
                        'business' => 'Business',
                        'first' => 'First Class',
                    ]),

                Tables\Filters\TernaryFilter::make('is_active')
                    ->label('Active Status')
                    ->placeholder('All classes')
                    ->trueLabel('Active only')
                    ->falseLabel('Inactive only'),

                Tables\Filters\Filter::make('available')
                    ->label('Has Available Seats')
                    ->query(fn ($query) => $query->where('available_seats', '>', 0)),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                
                Tables\Actions\Action::make('toggle_active')
                    ->label(fn ($record) => $record->is_active ? 'Deactivate' : 'Activate')
                    ->icon(fn ($record) => $record->is_active ? 'heroicon-o-x-circle' : 'heroicon-o-check-circle')
                    ->color(fn ($record) => $record->is_active ? 'danger' : 'success')
                    ->requiresConfirmation()
                    ->action(fn ($record) => $record->toggleActive())
                    ->successNotificationTitle(fn ($record) => "Class " . ($record->is_active ? 'activated' : 'deactivated')),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    
                    Tables\Actions\BulkAction::make('activate')
                        ->label('Activate Selected')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->requiresConfirmation()
                        ->action(fn ($records) => $records->each->update(['is_active' => true])),
                    
                    Tables\Actions\BulkAction::make('deactivate')
                        ->label('Deactivate Selected')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->requiresConfirmation()
                        ->action(fn ($records) => $records->each->update(['is_active' => false])),
                ]),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListFlightClasses::route('/'),
            'create' => Pages\CreateFlightClass::route('/create'),
            'edit' => Pages\EditFlightClass::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::where('is_active', true)->count();
    }

    public static function getNavigationBadgeColor(): string
    {
        return 'success';
    }
}
