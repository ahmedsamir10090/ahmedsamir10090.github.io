<?php

namespace App\Filament\Resources\Agencies\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class AgencyForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->required(),
                TextInput::make('license_number'),
                TextInput::make('logo'),
                TextInput::make('current_balance')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                TextInput::make('commission_rate')
                    ->required()
                    ->numeric()
                    ->default(0.0),
                Select::make('status')
                    ->options(['active' => 'Active', 'suspended' => 'Suspended'])
                    ->default('active')
                    ->required(),
            ]);
    }
}
