<?php

namespace App\Filament\Resources\FlightClassResource\Pages;

use App\Filament\Resources\FlightClassResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Actions;

class ListFlightClasses extends ListRecords
{
    protected static string $resource = FlightClassResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
