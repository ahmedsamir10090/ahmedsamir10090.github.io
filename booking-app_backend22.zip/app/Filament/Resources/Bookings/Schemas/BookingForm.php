<?php

namespace App\Filament\Resources\Bookings\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class BookingForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->required(),
                Select::make('agency_id')
                    ->relationship('agency', 'name'),
                TextInput::make('serviceable_type')
                    ->required(),
                TextInput::make('serviceable_id')
                    ->required()
                    ->numeric(),
                TextInput::make('total_price')
                    ->required()
                    ->numeric()
                    ->prefix('$'),
                Select::make('status')
                    ->options([
            'pending' => 'Pending',
            'accepted' => 'Accepted',
            'rejected' => 'Rejected',
            'completed' => 'Completed',
        ])
                    ->default('pending')
                    ->required(),
                Select::make('payment_status')
                    ->options([
            'unpaid' => 'Unpaid',
            'pending' => 'Pending',
            'paid' => 'Paid',
            'failed' => 'Failed',
            'refunded' => 'Refunded',
        ])
                    ->default('unpaid')
                    ->required(),
                Select::make('payment_method')
                    ->options(['wallet' => 'Wallet', 'stripe' => 'Stripe', 'manual_receipt' => 'Manual receipt'])
                    ->required(),
                FileUpload::make('payment_proof_image')
                    ->image(),
            ]);
    }
}
