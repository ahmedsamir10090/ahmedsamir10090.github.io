<?php

namespace App\Filament\Resources\SystemSettingResource\Pages;

use App\Filament\Resources\SystemSettingResource;
use Filament\Actions;
use Filament\Resources\Pages\ManageRecords;

class ManageSystemSettings extends ManageRecords
{
    protected static string $resource = SystemSettingResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('settings')
                ->label('Edit Settings')
                ->icon('heroicon-o-cog-6-tooth')
                ->url(fn (): string => static::getResource()::getUrl('edit'))
                ->color('primary'),
        ];
    }
}
