<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Helper function for translating status values
        if (!function_exists('trans_choice')) {
            function trans_status($status) {
                return __(strtolower($status));
            }
        }
        
    //    Gate::define('manage-agency-finances', function ($user) {
    //     // هذا هو الاختبار النهائي الذي سيكشف كل شيء
    //     dd(
    //         'The Gate "manage-agency-finances" was successfully called!',
    //         'User Role from inside the Gate:', $user->role,
    //         'The result of the check is:', $user->role === 'agency_manager'
    //     );
    // });

        Gate::define('manage-agency-staff', function ($user) {
        return $user->role === 'agency_manager';
    });
    }
}
