<?php

require 'vendor/autoload.php';
$app = require 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

$booking = App\Models\Booking::find(8);
$booking->update(['status' => 'pending']);
echo "Booking 8 set to pending" . PHP_EOL;
