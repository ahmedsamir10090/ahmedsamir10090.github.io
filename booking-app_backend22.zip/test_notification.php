<?php

use App\Models\User;
use App\Models\Notification;

$user = User::find(4);

if (!$user) {
    echo "User not found\n";
    return;
}

$notification = Notification::create([
    'user_id' => $user->id,
    'title' => 'تحديث حالة الشحنة',
    'body' => 'الشحنة رقم #1 الآن: تم الاستلام من الموقع الحالي',
    'type' => 'shipment_picked_up',
    'data' => json_encode([
        'booking_id' => 1,
        'tracking_status' => 'picked_up',
        'location' => 'بورتسودان',
    ]),
    'read_at' => null,
]);

echo "✅ تم إنشاء الإشعار رقم: {$notification->id}\n";
echo "المستخدم: {$user->name} (ID: {$user->id})\n";
echo "العنوان: {$notification->title}\n";
echo "الرسالة: {$notification->body}\n";
