<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'user' => \App\Http\Middleware\EnsureUserIsUser::class,
            'agency' => \App\Http\Middleware\EnsureUserIsAgency::class,
            'admin' => \App\Http\Middleware\EnsureUserIsAdmin::class,

        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
      $exceptions->renderable(function (\Illuminate\Auth\Access\AuthorizationException $e, $request) {
            dd($e->getTrace()[0]);
        });
    })->create();
